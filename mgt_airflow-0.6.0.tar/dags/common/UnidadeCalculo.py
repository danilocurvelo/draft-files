from common.UnidadeEngenharia import *

class UnidadeCalculo :

    class PSV :
        PRESSAO = UnidadeEngenharia.KPA
        TEMPERATURA = UnidadeEngenharia.KELVIN
        AREA = UnidadeEngenharia.MM_2

    class ValvulaControle :
        PRESSAO = UnidadeEngenharia.PA
        TEMPERATURA = UnidadeEngenharia.KELVIN

    class ElementoPrimarioVazao :
        PRESSAO = UnidadeEngenharia.PA
        TEMPERATURA = UnidadeEngenharia.KELVIN

class UnidadeValorConstante :
    UNIDADE_PRESSAO_CONSTANTE = UnidadeEngenharia.KGF_CM_2
    UNIDADE_TEMPERATURA_CONSTANTE = UnidadeEngenharia.KELVIN