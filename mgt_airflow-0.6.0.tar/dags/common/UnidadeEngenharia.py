class UnidadeEngenharia :
    ### PRESSÃO ###
    PA = "PA"
    KPA = "KPA"
    KGF_CM_2 = "KGF_CM_2"
    LBF_POL_2 = "LBF_POL_2"
    BAR = "BAR"
    POL_HG = "POL_HG" # POL_HG @ 0 graus C
    POL_H2O = "POL_H2O" # POL_H2O @ 4 graus C
    ATM = "ATM"
    MM_HG = "MM_HG" # mm_HG @ 0 graus C
    MM_H2O = "MM_H2O" # mm_H2O @ 4 graus C
    
    ### TEMPERATURA ###
    KELVIN = "KELVIN"
    FAHRENHEIT = "FAHRENHEIT"
    CELSIUS = "CELSIUS"
    RANKINE = "RANKINE"

    ### ÁREA ###
    MM_2 = "MM_2"
    IN_2 = "IN_2"
