AIRFLOW_PATH = "/opt/airflow/"

import glob, os, yaml, random
from shutil import copyfile

from common.PlantExpert import PlantExpert

from airflow.decorators import dag, task
from airflow.utils.dates import days_ago
from airflow.models import Variable

class FilenameAtivo():
    VALVULA_CONTROLE = "valvula_controle"
    PSV = "psv"
    ELEMENTO_VAZAO = "elemento_primario_vazao"

default_args = {
    'owner': 'lii'
}

@dag("Orquestrador_MGT", default_args=default_args, schedule_interval="*/5 * * * *", start_date=days_ago(0), tags=['mgt'], catchup=False)
def orquestrador_mgt():
    """
    ### Orquestrador MGT
    DAG principal para criação de novos DAGs dinamicamente de acordo com sua configuração no BR-PlantExpert.
    O padrão de criação do arquivo é `<ID>_<ATIVO>_mgt_dag.py`
    """

    @task()
    def inicializacao_configuracoes_airflow():
        """
        #### Tarefa: Ler os dados de configuração do arquivo de configuração.
        """

        return load_configuration_file()

    @task()
    def leitura_inferencias_cadastradas(status):
        """
        #### Tarefa: Obtenção de todas as inferências cadastradas no BR-PlantExpert.
        """

        return extract_data_from_plant()

    @task()
    def criacao_novos_dags(plant_inference_list):
        """
        #### Tarefa: Criação de novos dags dinamicamente.
        """
        create_new_inference_dags(plant_inference_list)


    status = inicializacao_configuracoes_airflow()
    dados = leitura_inferencias_cadastradas(status)
    criacao_novos_dags(dados)

mgt  = orquestrador_mgt()

## AUXILIAR

def load_configuration_file() :
    with open(AIRFLOW_PATH + "config.yml", "r") as yamlfile: 
        config_parameters = yaml.load(yamlfile, Loader=yaml.FullLoader)

    # Parâmetros do Airflow
    Variable.set("AIRFLOW_PATH", config_parameters['airflow']['main_path'])

    # Parâmetros das DAGs
    Variable.set("JANELA_EXECUCAO_DAG", config_parameters['dags']['janela_execucao_dag_minutos'])
    Variable.set("DELAY_EXECUCAO_DAG", config_parameters['dags']['delay_execucao_dag_minutos'])
    Variable.set("RETENTATIVAS", config_parameters['dags']['retentativas_apos_erro'])
    Variable.set("DELAY_RETENTATIVAS", config_parameters['dags']['delay_entre_retentativas_minutos'])

    # Parâmetros de notificação por e-mail
    Variable.set("NOTIFICACAO_HABILITADA", config_parameters['notificacao']['habilitado'])
    Variable.set("EMAIL", config_parameters['notificacao']['email'])
    
    # Parâmetros do Plant Expert
    Variable.set("PLANTEXPERT_HOST", config_parameters['plantexpert']['host'])
    Variable.set("PLANTEXPERT_USER", config_parameters['plantexpert']['user'])
    Variable.set("PLANTEXPERT_PASSWD", config_parameters['plantexpert']['passwd'])

    # Parâmetros do Plant Historian
    Variable.set("PLANTHISTORIAN_HOST", config_parameters['historian']['host'])
    Variable.set("PLANTHISTORIAN_PORT", config_parameters['historian']['port'])
    Variable.set("PLANTHISTORIAN_USER", config_parameters['historian']['user'])
    Variable.set("PLANTHISTORIAN_PASSWD", config_parameters['historian']['passwd'])

    return True

def extract_data_from_plant():
    pe = PlantExpert(Variable.get("PLANTEXPERT_HOST"), Variable.get("PLANTEXPERT_USER"), Variable.get("PLANTEXPERT_PASSWD"))
    return pe.get_flow_inference_data()

def get_current_dags():
    files = [f for f in os.listdir(AIRFLOW_PATH + 'dags') if os.path.isfile(os.path.join(AIRFLOW_PATH + "dags", f))]
    dag_ids = []
    for file in files :
        id = file.split('_')[0]
        if (id.isnumeric()) : dag_ids.append(id)
    return dag_ids

def create_new_inference_dags(plant_inference_list):
    files = get_current_dags()
    dags = []
    for inference in plant_inference_list:
        if (inference['habilitado']): # Se o monitoramento da inferência está habilitada no PlantExpert.
            dags.append(str(inference['id']))
            if not str(inference['id']) in files :
                create_dag(inference["id"], get_tipo_ativo(inference))
                files.append(str(inference["id"]))
    remove_deleted_dags(list(set(files) - set(dags)))

def remove_deleted_dags(deleted_dags):
    for dag_id in deleted_dags :
        for file_to_delete in glob.glob(AIRFLOW_PATH + "dags/" + str(dag_id)+ "_*"):
            os.remove(file_to_delete)

def get_tipo_ativo(ativo_json) :
    if (ativo_json['tipoAtivo'] == PlantExpert.Ativo.VALVULA_CONTROLE) :
        return FilenameAtivo.VALVULA_CONTROLE
    elif (ativo_json['tipoAtivo'] == PlantExpert.Ativo.PSV) :
        return FilenameAtivo.PSV
    elif (ativo_json['tipoAtivo'] == PlantExpert.Ativo.ELEMENTO_VAZAO) :
        return FilenameAtivo.ELEMENTO_VAZAO
    else :
        raise Exception('Ativo não suportado.')

def create_dag(id, type):
    src = AIRFLOW_PATH + "templates/template_" + type + "_dag.py"
    dst = AIRFLOW_PATH + "dags/" + str(id)+ "_" + type + "_mgt_dag.py"
    if not os.path.exists(dst):
        copyfile(src, dst)
        
        # Email de notificação
        line_prepender(dst, "EMAIL=\""+str(Variable.get("EMAIL"))+"\"")
        # Notificação habilitada?
        line_prepender(dst, "NOTIFICACAO_HABILITADA="+str(Variable.get("NOTIFICACAO_HABILITADA")))
        # Delay entre as retentativas em minutos
        line_prepender(dst, "DELAY_RETENTATIVAS="+str(Variable.get("DELAY_RETENTATIVAS")))
        # Quantidade de retentativas após erro
        line_prepender(dst, "RETENTATIVAS="+str(Variable.get("RETENTATIVAS")))
        # Balanceamento de carga na janela.
        minuto_alvo = int(Variable.get("DELAY_EXECUCAO_DAG"))
        if (int(Variable.get("JANELA_EXECUCAO_DAG"))) > 0 :
            minuto_alvo += random.randrange(1, int(Variable.get("JANELA_EXECUCAO_DAG"))+1)
        line_prepender(dst, "MINUTO_ALVO_EXECUCAO="+str(minuto_alvo))
        # ID da inferência cadastrada no BR-PlantExpert.
        line_prepender(dst, "PLANT_EXPERT_INFERENCE_ID="+str(id))

def line_prepender(filename, line):
    with open(filename, 'r+') as f:
        content = f.read()
        f.seek(0, 0)
        f.write(line.rstrip('\r\n') + '\n' + content)