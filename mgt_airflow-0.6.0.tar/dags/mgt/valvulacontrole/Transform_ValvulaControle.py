import math, logging

from mgt.valvulacontrole.ParametrosValvulaControle import CaracteristicaVazao, ConstantesValvulaControle
from common.UnidadeCalculo import UnidadeCalculo
from common.EstadoFluido import EstadoFluido
from common.ConversaoUnidades import *
from common.DataInterpolation import *
from common import Constante


def calcular_vazoes_valvulacontrole(aberturas, pressoes_montante, pressoes_jusante, temperaturas, unidades_transmissores, estado_fluido, caracteristica_vazao, cv_especificado, xt, cpcv, peso_molecular, fator_compressibilidade, offset_posicao, preco_fluido_usd_por_mmbtu, d_valvula, d1, d2) :

    vazoes_massicas_instantaneas = []
    vazoes_volumetricas_instantaneas = []
    registros_vazao_massica = []
    registros_vazao_volumetrica = []

    sk, ki = coeficientes_valvula(d_valvula, d1, d2)

    for (abertura, p_montante, p_jusante, t) in zip(aberturas, pressoes_montante, pressoes_jusante, temperaturas) :

        if (cpcv == 0 or xt == 0 or fator_compressibilidade == 0 or peso_molecular == 0) : continue # Condições para evitar divisão por zero

        ## Conversão de unidades dos transmissores
        pressao_montante = p_montante['value']
        pressao_montante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_montante'])(pressao_montante)
        pressao_montante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UnidadeCalculo.ValvulaControle.PRESSAO)(pressao_montante)
        pressao_montante_abs = pressao_montante + Constante.PRESSAO_ATMOSFERICA
        if (pressao_montante_abs <= 0) : continue # Caso a pressão a montante absoluta seja zero ou negativa.

        pressao_jusante = p_jusante['value']
        pressao_jusante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_jusante'])(pressao_jusante)
        pressao_jusante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UnidadeCalculo.ValvulaControle.PRESSAO)(pressao_jusante)
        pressao_jusante_abs = pressao_jusante + Constante.PRESSAO_ATMOSFERICA
        if (pressao_jusante_abs <= 0) : continue # Caso a pressão a jusante absoluta seja zero ou negativa.

        temperatura = t['value']
        temperatura = ConversaoUnidades.TEMPERATURA_PARA_KELVIN_DE.get(unidades_transmissores['temperatura'])(temperatura)
        temperatura = ConversaoUnidades.TEMPERATURA_DE_KELVIN_PARA.get(UnidadeCalculo.ValvulaControle.TEMPERATURA)(temperatura)
        # Caso a temperatura absoluta (K) seja menor ou igual a zero, ignora a amostra (erro de leitura do sensor)
        if (UnidadeCalculo.ValvulaControle.TEMPERATURA == UnidadeEngenharia.KELVIN and temperatura <= 0) : continue 

        abertura_real = abertura['value'] - offset_posicao
        abertura_real = abertura_real if abertura_real >= ConstantesValvulaControle.TOLERANCIA_ABERTURA else 0
        abertura_real = abertura_real if abertura_real <= 1.0 else 1.0

        vazao_instantanea = calcular_vazao_instantanea(estado_fluido, caracteristica_vazao, abertura_real, pressao_montante_abs, pressao_jusante_abs, temperatura, cv_especificado, xt, cpcv, peso_molecular, fator_compressibilidade, d_valvula, sk, ki)

        # Conversão de vazão por segundo para vazão por hora
        vazao_instantanea['vazaoMassica'] = ConversaoUnidades.VAZAO_POR_SEGUNDO_PARA_VAZAO_POR_HORA(vazao_instantanea['vazaoMassica'])
        vazao_instantanea['vazaoVolumetrica'] = ConversaoUnidades.VAZAO_POR_SEGUNDO_PARA_VAZAO_POR_HORA(vazao_instantanea['vazaoVolumetrica'])

        vazoes_massicas_instantaneas.append(vazao_instantanea['vazaoMassica'])
        registros_vazao_massica.append({'timestamp' : abertura['timestamp'], 'value' : vazao_instantanea['vazaoMassica']})
        
        vazoes_volumetricas_instantaneas.append(vazao_instantanea['vazaoVolumetrica'])
        registros_vazao_volumetrica.append({'timestamp' : abertura['timestamp'], 'value' : vazao_instantanea['vazaoVolumetrica']})

    vazao_massica_media = (sum(vazoes_massicas_instantaneas)/len(vazoes_massicas_instantaneas)) if (len(vazoes_massicas_instantaneas) > 0) else 0
    vazao_volumetrica_media = (sum(vazoes_volumetricas_instantaneas)/len(vazoes_volumetricas_instantaneas)) if (len(vazoes_volumetricas_instantaneas) > 0) else 0

    custo_por_hora = ConversaoUnidades.M3_PARA_MMBTU(vazao_volumetrica_media) * preco_fluido_usd_por_mmbtu
    custo_por_hora = custo_por_hora if custo_por_hora > 0 else 0

    return {'vazoes_massica': registros_vazao_massica, 'vazao_massica_media' : vazao_massica_media,
            'vazoes_volumetrica': registros_vazao_volumetrica, 'vazao_volumetrica_media' : vazao_volumetrica_media,
            'custo_por_hora' : custo_por_hora }

def calcular_vazao_instantanea(estado_fluido, caracteristica_vazao, abertura, p_montante_abs, p_jusante_abs, temperatura, cv_especificado, xt, cpcv, peso_molecular, fator_compressibilidade, d_valvula, sk, ki) :
    ''' Retorna vazão instantanea massica e volumetrica em kg/s e m3/s '''

    vazao_massica = calcular_vazao_massica_gas(caracteristica_vazao, abertura, p_montante_abs, p_jusante_abs, temperatura, cv_especificado, xt, cpcv, peso_molecular, fator_compressibilidade, d_valvula, sk, ki)
    vazao_volumetrica = calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade)

    vazao_massica = vazao_massica if vazao_massica >= 0 else 0
    vazao_volumetrica = vazao_volumetrica if vazao_volumetrica >= 0 else 0

    return {'vazaoMassica' : vazao_massica, 'vazaoVolumetrica' : vazao_volumetrica}

def _cv_atual(caracteristica_vazao : CaracteristicaVazao, abertura, cv_especificado) :
    r = 0.0
    if (abertura > 0) :
        r = calcular_r.get(caracteristica_vazao)(abertura)
    
    return r * cv_especificado

def calcular_vazao_massica_gas(caracteristica_vazao, abertura, p_montante_abs, p_jusante_abs, temperatura, cv_especificado, xt, cpcv, peso_molecular, fator_compressibilidade, d_valvula, sk, ki) :
    diferenca_pressao = p_montante_abs - p_jusante_abs
    diferenca_pressao = diferenca_pressao if (diferenca_pressao >= 0) else 0

    cv = _cv_atual(caracteristica_vazao, abertura, cv_especificado)

    fp = 1 / (math.sqrt(1 + (sk / 890) * (cv / (d_valvula ** 2)) ** 2))
    xtp = xt / ((fp ** 2) * ((xt * ki / 1000) * (cv / (d_valvula ** 2)) ** 2) + 1)

    x = diferenca_pressao / p_montante_abs

    fk = cpcv / 1.4
    if (x > fk * xtp):
        x = fk * xtp
    fator_y = 1 - (x / (3 * fk * xtp))
    
    massa_especifica = (p_montante_abs * peso_molecular) / (Constante.R * fator_compressibilidade * temperatura)

    w_massica = cv * 0.000024 * fator_y * fp * math.sqrt(x * p_montante_abs * massa_especifica)    

    return w_massica

def calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade) :
    rho = _calcular_rho(peso_molecular, Constante.PRESSAO_EM_CONDICAO_NORMAL, 1.0, Constante.R, Constante.TEMPERATURA_EM_CONDICAO_NORMAL)
    return vazao_massica / rho

def _calcular_rho(peso_molecular, pressao, fator_compressibilidade, r, temperatura) :
    return (peso_molecular * pressao) / (fator_compressibilidade * r * temperatura)

calcular_r = {
    CaracteristicaVazao.LINEAR : lambda abertura : abertura,
    CaracteristicaVazao.PARABOLICA : lambda abertura : 0.6029 * abertura - 3.6510 * math.pow(abertura, 2) + 16.3684 * math.pow(abertura, 3) - 25.7186 * math.pow(abertura, 4) + 19.0930 * math.pow(abertura, 5) - 5.6947 * math.pow(abertura, 6),
    CaracteristicaVazao.PORCENTAGEM : lambda abertura : math.pow(((abertura) / (3.6923 - 2.6923 * abertura)), (1 / 0.79)),
    CaracteristicaVazao.RAPIDA : lambda abertura : 1.8681 * abertura - 5.5011 * math.pow(abertura, 2) + 24.1737 * math.pow(abertura, 3) - 46.9522 * math.pow(abertura, 4) + 39.8108 * math.pow(abertura, 5) - 12.3993 * math.pow(abertura, 6),
    CaracteristicaVazao.BORBOLETA : lambda abertura : (0.2402 * abertura) / (1.0 - 0.4734 * abertura - 1.4412 * math.pow(abertura, 2) + 1.1548 * math.pow(abertura, 3))
}

def coeficientes_valvula(d_valvula, d1, d2):
    '''
    k1 e k2 : coeficientes de resistência a montante e a jusante. 
    k3 e k4 : coeficientes de Bernoulli para entrada e saída da válvula com redutores.

    Retorna:
        sk = k1 + k2 + k3 - k4
        ki = k1 + k3
    '''
    d1 = d_valvula if (d1 is None) else d1
    d2 = d_valvula if (d2 is None) else d2
    k1 = 0.5 * (1 - (d_valvula / d1) ** 2) ** 2
    k2 = (1 - (d_valvula / d2) ** 2) ** 2
    k3 = 1 - (d_valvula / d1) ** 4
    k4 = 1 - (d_valvula / d2) ** 4
    sk = k1 + k2 + k3 - k4
    ki = k1 + k3
    return sk, ki

def transform(parametros, id):

    logging.warn(">>> INFERÊNCIA DO ATIVO VALVULA DE CONTROLE: {}".format(parametros['tag_ativo']))

    aberturas = parametros['abertura']
    pressoes_montante = parametros['pressao_montante']
    pressoes_jusante = parametros['pressao_jusante']
    temperaturas = parametros['temperatura']

    tags_escrita = {'custoPorHora': parametros['custoPorHora'], 
                    'vazaoMassica': parametros['vazaoMassica'], 
                    'vazaoMassicaPorHora': parametros['vazaoMassicaPorHora'], 
                    'vazaoVolumetrica': parametros['vazaoVolumetrica'], 
                    'vazaoVolumetricaPorHora': parametros['vazaoVolumetricaPorHora']}

    reference_length = len(aberturas)

    if ( isinstance(pressoes_montante, list) ) :
        pressoes_montante = resize_records(pressoes_montante, reference_length, ['value', 'timestamp'])
    else :
        pressoes_montante = [{"value" : pressoes_montante}] * reference_length

    if ( isinstance(pressoes_jusante, list) ) :
        pressoes_jusante = resize_records(pressoes_jusante, reference_length, ['value', 'timestamp'])
    else :
        pressoes_jusante = [{"value" : pressoes_jusante}] * reference_length

    if ( isinstance(temperaturas, list) ) :
        temperaturas = resize_records(temperaturas, reference_length, ['value', 'timestamp'])
    else :
        temperaturas = [{"value" : temperaturas}] * reference_length

    unidades_transmissores = {
        'pressao_montante' : parametros['pressao_montante_unidade'],
        'pressao_jusante' : parametros['pressao_jusante_unidade'],
        'temperatura' : parametros['temperatura_unidade']
    }

    resultado = calcular_vazoes_valvulacontrole(aberturas=aberturas,
                                                pressoes_montante=pressoes_montante,
                                                pressoes_jusante=pressoes_jusante,
                                                temperaturas=temperaturas,
                                                unidades_transmissores=unidades_transmissores,
                                                estado_fluido=parametros['estado'],
                                                caracteristica_vazao=parametros['caracteristica_vazao'],
                                                cv_especificado=parametros['cv'],
                                                xt=parametros['xt'],
                                                cpcv=parametros['cpcv'],
                                                peso_molecular=parametros['mw'],
                                                fator_compressibilidade=parametros['z'],
                                                offset_posicao=parametros['offset_posicao'],
                                                preco_fluido_usd_por_mmbtu=parametros['preco_fluido_usd_por_mmbtu'], 
                                                d_valvula=parametros['d_valvula'],
                                                d1=parametros['d1'],
                                                d2=parametros['d2'])

    resultado['tags_escrita'] = tags_escrita
    resultado['timestamp_media'] = parametros['timestamp_media']
    resultado['tag_ativo'] = parametros['tag_ativo']

    return resultado

