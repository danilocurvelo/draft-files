from common.UnidadeCalculo import UnidadeValorConstante
from common.PlantHistorian import *
import logging

from airflow.models import Variable

def extract_data_from_planthistorian(inference_metadata):
    logging.warn(">>> INFERÊNCIA DO ATIVO VÁLVULA DE CONTROLE: {}".format(inference_metadata["valvulaControle"]["tag"]))
    client = connect_to_historian(Variable.get("PLANTHISTORIAN_HOST"), Variable.get("PLANTHISTORIAN_PORT"))
    parameters = get_constant_data(inference_metadata)
    data = get_variable_data_from_historian(client, inference_metadata)
    parameters.update(data) # merge data.
    return parameters

def get_constant_data(inference_metadata):

    parameters = {'id_ativo' : inference_metadata["valvulaControle"]["id"],
                  'tag_ativo' : inference_metadata["valvulaControle"]["tag"],
                  'caracteristica_vazao' : inference_metadata["valvulaControle"]["caracteristicaVazao"],
                  'estado' : inference_metadata["fluido"]["tipoFluido"],
                  'cv' : inference_metadata["valvulaControle"].get("cv", 1),
                  'fl' : inference_metadata["valvulaControle"].get("fl", 1),
                  'xt' : inference_metadata["valvulaControle"].get("xt", 1),
                  'rho' : inference_metadata.get('massaEspecifica', 1),
                  'p_vap' : inference_metadata.get('pressaoVapor', 1),
                  'p_crit' : inference_metadata.get('pressaoCritica', 1),
                  'cpcv' : inference_metadata.get('cpcv', 1),
                  'z' : inference_metadata.get('fatorCompressibilidade', 1),
                  'mw' : inference_metadata.get('pesoMolecular', 18.016),
                  'offset_posicao' : inference_metadata['valvulaControle'].get('offsetPosicao', 0),
                  'd_valvula' : inference_metadata['valvulaControle'].get('diametro', 1),
                  'd1' : inference_metadata['valvulaControle'].get('diametroMontante', None),
                  'd2' : inference_metadata['valvulaControle'].get('diametroJusante', None),
                  #'preco_fluido_usd_por_mmbtu' : _get_fluid_price(inference_metadata['fluido']),

                  'custoPorHora' : inference_metadata["custoPorHora"], 
                  'vazaoMassica' : inference_metadata["vazaoMassica"],
                  'vazaoMassicaPorHora' : inference_metadata["vazaoMassicaPorHora"],
                  'vazaoVolumetrica' : inference_metadata["vazaoVolumetrica"],
                  'vazaoVolumetricaPorHora' : inference_metadata["vazaoVolumetricaPorHora"]
                
    }

    return parameters


def get_variable_data_from_historian(client, inference_metadata):

    # Timezone
    tz_utc_minus_3 = timedelta(hours=3) 
    
    # Janela de tempo = 1h
    now = datetime.now() + tz_utc_minus_3 # Transformando em UTC

    # Confere se é reprocessamento:
    if 'timestamp_alvo' in inference_metadata :
        now = pd.to_datetime(pd.Timestamp(inference_metadata['timestamp_alvo'])) + tz_utc_minus_3 + tz_utc_minus_3

    # Início da janela com hora inteira (Ex: 16:03 => 16:00)
    window_end = now.replace(minute=0, second=0, microsecond=0)

    timestamp_fim = Timestamp()
    timestamp_fim.FromDatetime(window_end)
    timestamp_inicio = Timestamp()
    timestamp_inicio.FromDatetime(window_end - timedelta(hours=1))  

    # Timestamps para logging (DD/MM/AA HH:MM:SS)
    formatted_timestamp_fim = (datetime.fromtimestamp(timestamp_fim.seconds + timestamp_fim.nanos/1e9)).strftime("%d/%m/%Y %H:%M:%S")
    formatted_timestamp_inicio = (datetime.fromtimestamp(timestamp_inicio.seconds + timestamp_inicio.nanos/1e9)).strftime("%d/%m/%Y %H:%M:%S")

    # abertura da válvula de controle
    tag_abertura = inference_metadata["valvulaControle"]["tagAberturaHistorica"]["tag"]
    abertura = get_data_from_historian(client, tag_abertura, timestamp_inicio, timestamp_fim)
    if (len(abertura) == 0) : raise ValueError('Não existem registros de abertura (' + str(tag_abertura) + ') no período avaliado: ' + str(formatted_timestamp_inicio) + " - " + str(formatted_timestamp_fim))

    # valores dos transmissores e suas unidades
    pressao_montante = None
    pressao_montante_unidade = UnidadeValorConstante.UNIDADE_PRESSAO_CONSTANTE
    pressao_jusante = None
    pressao_jusante_unidade = UnidadeValorConstante.UNIDADE_PRESSAO_CONSTANTE
    temperatura = None
    temperatura_unidade = UnidadeValorConstante.UNIDADE_TEMPERATURA_CONSTANTE

    # pressaoMontante
    if (_is_property_constant(inference_metadata, "pressaoMontante")):
        pressao_montante = inference_metadata["pressaoMontante"]["constante"]
        pressao_montante_unidade = inference_metadata["pressaoMontante"].get("unidadeEngenharia", pressao_montante_unidade)
    else :
        tag_pressao_montante = inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["tag"]
        pressao_montante = get_data_from_historian(client, tag_pressao_montante, timestamp_inicio, timestamp_fim)
        pressao_montante_unidade = inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]
        if (len(pressao_montante) == 0) : raise ValueError('Não existem registros de pressão a montante (' + str(tag_pressao_montante) + ') no período avaliado: ' + str(formatted_timestamp_inicio) + " - " + str(formatted_timestamp_fim))

    # pressaoJusante
    if (_is_property_constant(inference_metadata, "pressaoJusante")):
        pressao_jusante = inference_metadata["pressaoJusante"]["constante"]
        pressao_jusante_unidade = inference_metadata["pressaoJusante"].get("unidadeEngenharia", pressao_jusante_unidade)
    else :
        tag_pressao_jusante = inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["tag"]
        pressao_jusante = get_data_from_historian(client, tag_pressao_jusante, timestamp_inicio, timestamp_fim)
        pressao_jusante_unidade = inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]
        if (len(pressao_jusante) == 0) : raise ValueError('Não existem registros de pressão a jusante (' + str(tag_pressao_jusante) + ') no período avaliado: ' + str(formatted_timestamp_inicio) + " - " + str(formatted_timestamp_fim))

    # temperaturaMontante
    if (_is_property_constant(inference_metadata, "temperaturaMontante")):
        temperatura = inference_metadata["temperaturaMontante"]["constante"]
        temperatura_unidade = inference_metadata["temperaturaMontante"].get("unidadeEngenharia", temperatura_unidade)
    else :
        tag_temperatura = inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["tag"]
        temperatura = get_data_from_historian(client, tag_temperatura, timestamp_inicio, timestamp_fim)
        temperatura_unidade = inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]
        if (len(temperatura) == 0) : raise ValueError('Não existem registros de temperatura a montante (' + str(tag_temperatura) + ') no período avaliado: ' + str(formatted_timestamp_inicio) + " - " + str(formatted_timestamp_fim))

    # preço do fluido USD por MMBTU
    if (not inference_metadata['fluido']['calculoHabilitado']) : # Totalização monetária desativada
        preco_fluido_usd_por_mmbtu = 0
    else :    
        preco_fluido_usd_por_mmbtu = _get_fluid_price(inference_metadata['fluido'], client)

    # Timestamp em segundos com GMT-3 para inserir na média.
    window_end = window_end - timedelta(hours=3)
    timestamp_media = int(window_end.timestamp())
    
    data = {'abertura' : abertura,
            'pressao_montante' : pressao_montante,
            'pressao_montante_unidade' : pressao_montante_unidade,
            'pressao_jusante' : pressao_jusante,
            'pressao_jusante_unidade' : pressao_jusante_unidade,
            'temperatura' : temperatura,
            'temperatura_unidade' : temperatura_unidade,
            'timestamp_media' : timestamp_media,
            'preco_fluido_usd_por_mmbtu' : preco_fluido_usd_por_mmbtu
    } 

    return data

def _is_property_constant(inference_metadata, property):
    if (inference_metadata[property]["tipoLeitura"] == "CONSTANTE"):
        return True

def _get_fluid_price(fluido, historiador) :
    if (fluido['leituraFluido']['tipoLeitura'] == "FATOR") : # Fator
        return fluido['leituraFluido']['fator'] * _get_fluid_price(fluido['leituraFluido']['fluido'], historiador)
    elif (fluido['leituraFluido']['tipoLeitura'] == "LEITURA_VALOR") :
        if (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "CONSTANTE") : # Constante
            return float(fluido['leituraFluido']['leituraValor']['valor'])
        elif (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "TAG_OPC") : # Tag historiada
            preco_fluido_usd_por_mmbtu = get_snapshot_from_historian(historiador, fluido['leituraFluido']['leituraValor']['tag'])
            preco_fluido_usd_por_mmbtu = 0 if (len(preco_fluido_usd_por_mmbtu) == 0) else preco_fluido_usd_por_mmbtu[0]['value']
            return preco_fluido_usd_por_mmbtu
    else :
        return 0
