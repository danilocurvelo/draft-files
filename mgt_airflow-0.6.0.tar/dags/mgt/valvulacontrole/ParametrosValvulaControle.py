# Característica de Vazão de Válvula de Controle
class CaracteristicaVazao():
    LINEAR = "LINEAR"
    PORCENTAGEM = "PORCENTAGEM"
    PARABOLICA = "PARABOLICA"
    RAPIDA = "RAPIDA"
    BORBOLETA = "BORBOLETA"

class ConstantesValvulaControle():
    TOLERANCIA_ABERTURA = 0 # A partir de quanto é para considerar parcialmente aberta.