# Tipo de válvula de segurança
class TipoPSV():
    BALANCEADA = "Balanceada"
    CONVENCIONAL = "Convencional"
    PILOTO_OPERADA = "Piloto operada"

class PosicaoPSV():
    ABERTO = 1.0
    FECHADO = 0.0

class ConstantesPSV():
    K_DEFAULT_API = 1.0