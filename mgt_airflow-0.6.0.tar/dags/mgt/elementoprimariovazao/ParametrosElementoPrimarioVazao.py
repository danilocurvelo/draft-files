# Tipo de elemento primário de vazão
class TipoElementoPrimarioVazao():
    PLACA_ORIFICIO = "PLACA_ORIFICIO" #"Placa de orifício"
    BOCAL_VENTURI_TOROIDAL = "BOCAL_VENTURI_TOROIDAL" #"Bocal Venturi de garganta toroidal"
    BOCAL_VENTURI_CILINDRICA = "BOCAL_VENTURI_CILINDRICA" #"Bocal Venturi de garganta cilíndrica"
    BOCAL_ASME = "BOCAL_ASME_RAIO_LONGO" #"Bocal ASME de raio longo"

class ConstantesElementoPrimarioVazao():
    NUMERO_MACH_INICIAL = 0.5