# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

## [Unreleased]


## [0.6.0] - 20-01-2022
### Added
- Uso das equações usando diâmetro da linha a montante, jusante e da PV para melhoria da inferência [Kaku Saito].
- Uso de Fp e Xtp para inferência de válvulas de controle
- Mudança no algoritmo de inferência para elemento primário: estratégia iterativa.
- Mudança na inferência para fluido do tipo vapor d'água: utiliza-se parâmetros provenientes do BR-PlantExpert.

## [0.5.2] - 13-01-2022
### Fixed
- Correção no estado anterior da PSV carregado do Airflow (TypeError: can't multiply sequence by non-int of type 'float').
- Correção na execução das DAGs iniciadas as 21h (start_date incorreto).

## [0.5.1] - 10-01-2022
### Fixed
- Correção do fator de compressibilidade para cálculo de rho em PV e EPV.

## [0.5.0] - 17-12-2021
### Added
- Correção na fórmula de conversão de POL_HG e POL_H2O
- Mudança estrutural da organização do modelo de PSV, EPV e PV, com remoção dos Modelos_*
- Remoção dos coeficientes Kc e Kb nas equações de PSV
- Inclusão da verificação de fluxo crítico em fluido do tipo vapo dágua
- Revaliação da fórmula de obtenção do Ksh
- Erros de historiador agora aparecem no Airflow
- Inclusão da tag do ativo no log do airflow
- Inclusão da quantidade de pontos salvos no historiador no log do airflow
- Mudança de nomenclatura para evitar interpretação errada sobre pressão manométrica e absoluta.
- Criação da constante `Constante.PRESSAO_ATMOSFERICA` para inferências sem leitura dessa informação.
- Validação do algoritmo de cálculo do coeficiente Ksh.


## [0.4.0] - 08-12-2021
### Added
- Fix da unidade de saída das inferências de PV e EPV: de kg/s para kg/h.
- Reprocessamento de períodos anteriores.
- Ajuste na biblioteca do Historiador para retornar dataframes.
- Inclusão do arquivo CHANGELOG.md para monitorar as alterações em cada versão do projeto.
- Alteração o termo BASE para CALCULO nas unidades de engenharia.
- Uniformização nos valores de PRESSAO_EM_CONDICAO_NORMAL e TEMPERATURA_EM_CONDICAO_NORMAL para todas as inferências
- Uniformização o valor de R para todas as inferências
- Reformulação nas dependências de constantes e unidades.
- Alteração nos nomes das rotinas de vapor d'água


## [0.3.0] - 03-11-2021
### Added
- Adicionado válvula XV para inferência de elemento primário de vazão.
- Adicionado script de instalação facilitada para PETROBRAS/REFAP.
- Novas equações para as curvas de abertura das PVs (Daniel/PETROBRAS).
### Fixed
- Fix no tratamento do comprimento dos vetores de entrada.
- Fix na fórmula de interpolação dos vetores de entrada.
- Fix no cálculo monetário com uso do parâmetro FATOR.


## [0.2.0] - 26-10-2021
### Added
- Pipeline automático de deploy na nuvem do IMD (CI/CD).
- Inclusão da lógica de retentativa e notificação por e-mail.
- Inclusão de notebooks atualizados com a lógica de negócio das inferências.
- Tratamento de erros em operações (divisão por zero, sqrt negativa) e variáveis nulas.
### Fixed
- Atualização na fórmula de conversão de M3 para MMBTU.


## [0.1.0] - 20-10-2021
### Added
- Release inicial do módulo Airflow-MGT.

[Unreleased]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.6.0...main
[0.6.0]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.5.2...v0.6.0
[0.5.2]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.5.1...v0.5.2
[0.5.1]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.5.0...v0.5.1
[0.5.0]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.4.0...v0.5.0
[0.4.0]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.3.0...v0.4.0
[0.3.0]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.2.0...v0.3.0
[0.2.0]: https://gitlab.com/ufrn-lii/airflow-mgt/-/compare/v0.1.0...v0.2.0
[0.1.0]: https://gitlab.com/ufrn-lii/airflow-mgt/-/tags/v0.1.0