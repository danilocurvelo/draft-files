# Implantação Apache Airflow - Petrobras


## 1. Criação de usuário Linux `airflow`

Criar usuário `airflow`, definir a senha e incluir no grupo `docker`

```bash 
useradd -m airflow
passwd airflow
usermod -a -G docker airflow
```

Adicionar no grupo `admin` ou `wheel` dependendo da distribuição.

```bash 
usermod -a -G wheel airflow
```

Definição login/senha REFAP:

```bash 
airflow:qwe123
```

[Opcional] Liberar acesso SSH para o usuário `airflow`

```bash 
sudo vi /etc/ssh/sshd.users.allow
echo airflow >> /etc/ssh/sshd.users.allow
systemctl restart sshd
```

## 2. Configurar proxy internet da Petrobras

As primeiras observações relacionadas às configurações que foram realizadas no servidor referem-se às definições de PROXY a partir das variáveis de ambiente.

Segue abaixo o comando e o resultado esperado para essas variáveis:

```bash
$ set | grep -i proxy

HTTPS_PROXY=https://<usuário>:<senha>@inet-sys.gnet.petrobras.com.br:804
HTTP_PROXY=http://<usuário>:<senha>@inet-sys.gnet.petrobras.com.br:8080
MY_HTTPS_PROXY_URL= https://<usuário>:<senha>@inet-sys.gnet.petrobras.com.br:804
MY_PROXY_URL= http://<usuário>:<senha>@inet-sys.gnet.petrobras.com.br:8080
http_proxy= http://<usuário>:<senha>@inet-sys.gnet.petrobras.com.br:8080
https_proxy= https://<usuário>:<senha>@inet-sys.gnet.petrobras.com.br:804
```

Podemos validar essa configuração a partir do seguinte comando:

```bash
[ast3ht@s6006as2391 ~]$ curl -sSL http://www.google.com
```

Para configurar o proxy para o **Docker**:

Editar o arquivo `/etc/systemd/system/docker.service.d/https-proxy.conf`, e o protocolo de conexão do servidor proxy que servirá de ponte a sites seguros deve ser apontado como HTTP, e não mais HTTPS.

```bash
Environment="HTTPS_PROXY=http://<usuario>:<senha>@inet-sys.gnet.petrobras.com.br:804"
```

A validação pode ser efetuada a partir do seguinte comando:

```bash
$ docker pull hello-world
```

**Observação:** Para configuração de proxy deve ser usada a chave de usuário (sem AS) e a configuração deve ser desfeita após a instalação (como a chave e senha fica em arquivo texto, deve-se usar essa solução, instalar/atualizar o pacote e remover a configuração de proxy. O servidor não tem acesso permanente a internet, mas apenas para a instalação/atualização.


## 3. Instalação do Docker

Instalação via gerenciador de pacotes yum (CentOS/RHEL):
```bash 
sudo yum install -y yum-utils

sudo yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo

sudo yum install docker-ce docker-ce-cli containerd.io
```

Reiniciar o serviço:

```bash 
sudo systemctl start docker
```

Testar o docker: 
```bash 
sudo docker run hello-world
```


## 4. Instalação do Docker Compose

Verificar a última versão disponível. Atualmente, 1.29.2.

```bash 
sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

sudo chmod +x /usr/local/bin/docker-compose

sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose

docker-compose --version
```

## 5. Copiar arquivos do módulo MGT: `mgt_airflow.tar` 

[Link direto para o arquivo](https://raw.githubusercontent.com/danilocurvelo/draft-files/master/mgt_airflow.tar)

Criação do diretório base do Airflow:

```bash
mkdir airflow
cd airflow
```

Download e descompactação dos arquivos base:

```bash
curl https://raw.githubusercontent.com/danilocurvelo/draft-files/master/mgt_airflow.tar --output mgt_airflow.tar

tar -xf mgt_airflow.tar
```

Arquivos baixados:

```bash
Dockerfile
docker-compose.yaml
config.yml
airflow.cfg
dags/
templates/
```

## 6. Inicializando o ambiente:

```bash
mkdir -p ./logs ./plugins
echo -e "AIRFLOW_UID=$(id -u)\nAIRFLOW_GID=0" > .env
echo -e "AIRFLOW_IMAGE_NAME=danilocurvelo/airflow-docker-lii:latest" >> .env
```

Diretório `~/airflow/`:

```bash
Dockerfile
docker-compose.yaml
config.yml
airflow.cfg
dags/
logs/
plugins/
templates/
```

## 7. Configurando o arquivo de configuração `config.yml`

- Configurar dados do servidor **PlantExpert**
- Configurar dados do servidor **PlantHistorian**
- Verificar que a inferência do BR-PlantExpert está **desligada**!


## 8. Subindo os serviços com o docker-compose:

```bash
sudo docker-compose up -D
```

```bash
IP:8080 airflow/airflow
```

## 9. Teste pela CLI e pela web

```bash
sudo docker exec -it airflow_airflow-scheduler_1 /bin/bash
airflow dags list
```

## 10. Depois dos testes
Derrubar os serviços:

```bash
sudo docker-compose down
```

Desativar os *Examples* e o *Pause at Creation* no `docker-compose.yaml`

## Outros

### Redimensionamento de partições com LVM

```bash
lsblk
df -h
sudo lvextend L+10G dev/mapper
```

### Desbloquear porta 8080 do centOS

```bash
firewall-cmd --zone=public --permanent --add-port=8080/tcp
firewall-cmd --reload
```

