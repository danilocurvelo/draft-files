import requests
import json

class PlantExpert() :

    class Ativo():
        VALVULA_CONTROLE = "VALVULA_CONTROLE"
        PSV = "PSV"
        ELEMENTO_VAZAO = "EPV"

    def __init__(self, url, username, password, connect_now=True):
        self.url = url
        self.session = None
        self.login = username
        self.senha = password

        if connect_now:
            self.connect()
    
    def connect(self):
        api_url = "https://"+self.url+"/rest/login/entrar/"
        payload = {"usuario.login": self.login,"usuario.senha": self.senha}
        self.session = requests.Session()
        self.session.post(api_url, headers={}, data=payload)

    def get_flow_inference_data(self):
        req = "https://"+self.url+"/rest/inferencia-vazao/"
        resp = self.session.get(req)
        parsed = json.loads(resp.text)
        return parsed

    def get_flow_inference_data_from_tag(self, tag):
        all_data = self.get_flow_inference_data()
        for ativo in all_data :
            for key in ativo :
                if ((type(ativo[key])) is dict) and ("tag" in ativo[key]) and (ativo[key]["tag"] == tag): return ativo
        return None

    def get_flow_inference_data_from_id(self, id):
        req = "https://"+self.url+"/rest/inferencia-vazao/"+str(id)
        resp = self.session.get(req)
        parsed = json.loads(resp.text)
        return parsed