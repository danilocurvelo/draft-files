from google.protobuf.timestamp_pb2 import Timestamp
from datetime import datetime, timedelta

from historian_grpc_client.generated.api_pb2 import ListData, Data, Metadata, Record, TagRegex, DataRequest, ListMetadata
from historian_grpc_client.api import HistorianGrpcClient, HistorianError

def connect_to_historian(host, port):
    return HistorianGrpcClient(host, port)

def print_tag_meta(historian, tag) :
    if historian.client is not None:
        tag_regex = TagRegex(valor=tag)
        tags_metadata = historian.client.find_tags(tag_regex).listMetadata
        print(tags_metadata)

def get_data_from_historian(historian, tag, data_inicio, data_fim):
    tag_regex = TagRegex(valor=tag)
    tags_metadata = historian.find_tags(tag_regex).listMetadata

    timestamp_fim = data_fim
    timestamp_inicio = data_inicio

    data_request = DataRequest(listMetaData=tags_metadata,
                                startDate=timestamp_inicio,
                                finalDate=timestamp_fim)
    retrieved_data = historian.find(data_request).listData

    return _single_var_protobuf_to_list(retrieved_data)

def get_snapshot_from_historian(historian, tag):
    tag_regex = TagRegex(valor=tag)
    tags_metadata = historian.find_tags(tag_regex).listMetadata

    retrieved_data = historian.find_snapshot(ListMetadata(listMetadata=tags_metadata)).listData

    return _single_var_protobuf_to_list(retrieved_data)

def _single_var_protobuf_to_list(protobuf_obj,
                                timestamp_col: str = "timestamp",
                                value_col: str = "value",
                                tag_col: str = "tag"):

    data_list = []
    for data_tag in protobuf_obj:
        metadata = data_tag.metadata
        tag_name = metadata.name
        records = data_tag.records

        for r in records:
            record = {tag_col: tag_name,
                        timestamp_col: r.timestamp.seconds,
                        value_col: float(r.value)}
            data_list.append(record)
    return data_list