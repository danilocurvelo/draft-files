from google.protobuf.timestamp_pb2 import Timestamp
from historian_grpc_client.api import HistorianGrpcClient, HistorianError
from historian_grpc_client.generated.api_pb2 import TagRegex, DataRequest, Status
import pandas as pd
from datetime import datetime, timedelta

class PlantHistorian() :
    
    def __init__(self, host, port, connect_now=True):
        self.host = host
        self.port = port
        self.timeout = 99999999
        self.client = None
        self.maximum_receive_size = 2147483647

        if connect_now:
            self.connect()
    
    def connect(self):
        self.client = HistorianGrpcClient(self.host, self.port, self.timeout)
        
    def print_tag_meta(self, tag: str) :
        if self.client is not None:
            tag_regex = TagRegex(valor=tag)
            tags_metadata = self.client.find_tags(tag_regex).listMetadata
            print(tags_metadata)
    
    def get_var_by_period(self,
                          tag: str,
                          start: str,
                          end: str,
                          timestamp_col: str = "timestamp",
                          variable_col: str = "value",
                          tag_col: str = "tag") -> pd.DataFrame:
        """
        Parameters: 
        tag : tag da variável
        start : data de inicio
        end : data de fim
        timestamp_co: nome da coluna de timestamp (default: timestamp)
        variable_col: nome da coluna de valor (default: value)
        tag_col: nome da coluna de tag (default: tag)


        Retorna DataFrame com os dados do período requisitado.
        """

        if self.client is not None:
            tag_regex = TagRegex(valor=tag)
            tags_metadata = self.client.find_tags(tag_regex).listMetadata

            timestamp_inicio = Timestamp()
            timestamp_inicio.FromDatetime(pd.to_datetime(pd.Timestamp(start)))

            timestamp_fim = Timestamp()
            timestamp_fim.FromDatetime(pd.to_datetime(pd.Timestamp(end)))

            data_request = DataRequest(listMetaData=tags_metadata,
                                       startDate=timestamp_inicio,
                                       finalDate=timestamp_fim)
            retrieved_data = self.client.find(data_request).listData
            return self._single_var_protobuf_to_df(retrieved_data,
                                                   timestamp_col,
                                                   variable_col)
        else:
            raise Exception("Historian client not connected")
            
    
    def get_var_by_window(self,
                          tag: str,
                          window_in_hours: int = 1,
                          timestamp_col: str = "timestamp",
                          variable_col: str = "value",
                          tag_col: str = "tag") -> pd.DataFrame:

        """
        Parameters: 
        tag : tag da variável
        window_in_hours : intervalo requisitado em horas
        timestamp_co: nome da coluna de timestamp (default: timestamp)
        variable_col: nome da coluna de valor (default: value)
        tag_col: nome da coluna de tag (default: tag)


        Retorna DataFrame com os dados do intervalo requisitado.
        """
        
        if self.client is not None:
            tag_regex = TagRegex(valor=tag)
            tags_metadata = self.client.find_tags(tag_regex).listMetadata

            timestamp_fim = Timestamp()
            timestamp_fim.FromDatetime(datetime.now())

            timestamp_inicio = Timestamp()
            timestamp_inicio.FromDatetime(datetime.today() - timedelta(hours=window_in_hours))  

            data_request = DataRequest(listMetaData=tags_metadata,
                                       startDate=timestamp_inicio,
                                       finalDate=timestamp_fim)
            retrieved_data = self.client.find(data_request).listData
            return self._single_var_protobuf_to_df(retrieved_data,
                                                   timestamp_col,
                                                   variable_col)
        else:
            raise Exception("Historian client not connected")
            
    
    def _single_var_protobuf_to_df(self,
                                   protobuf_obj,
                                   timestamp_col: str,
                                   value_col: str,
                                   tag_col: str = "tag"):

        data_list = []
        for data_tag in protobuf_obj:
            metadata = data_tag.metadata
            tag_name = metadata.name
            records = data_tag.records
            for r in records:
                record = {tag_col: tag_name,
                          timestamp_col: pd.Timestamp(r.timestamp.seconds, unit="s"),
                          value_col: float(r.value)}
                data_list.append(record)
        result_df = pd.DataFrame(data_list)
        if result_df.empty:
            return pd.DataFrame([], columns=[tag_col, timestamp_col, value_col])
        return result_df

