class UnidadeEngenharia :
    ### PRESSÃO ###
    PA = "PA"
    KPA = "KPA"
    KGF_CM_2 = "KGF_CM_2"
    LBF_POL_2 = "LBF_POL_2"
    BAR = "BAR"
    POL_HG = "POL_HG"
    POL_H2O = "POL_H2O"
    ATM = "ATM"
    MM_HG = "MM_HG"
    MM_H2O = "MM_H2O"
    
    ### TEMPERATURA ###
    KELVIN = "KELVIN"
    FAHRENHEIT = "FAHRENHEIT"
    CELSIUS = "CELSIUS"
    RANKINE = "RANKINE"

    ### ÁREA ###
    MM_2 = "MM_2"
    IN_2 = "IN_2"
