from common.UnidadeEngenharia import *

class ConversaoUnidades :

    ### PRESSÃO ###

    PRESSAO_PARA_PA_DE = {
        UnidadeEngenharia.PA : lambda x : x, 
        UnidadeEngenharia.KPA : lambda x : (x * 1000),
        UnidadeEngenharia.KGF_CM_2 : lambda x : (x * 98.0665 * 1000),
        UnidadeEngenharia.LBF_POL_2 : lambda x : (x * 6.895 * 1000),
        UnidadeEngenharia.BAR : lambda x : (x * 100000),
        UnidadeEngenharia.POL_HG : lambda x : (x  * 3.386389  * 1000),
        UnidadeEngenharia.POL_H2O : lambda x : (x * 0.24884 * 1000),
        UnidadeEngenharia.ATM : lambda x : (x  * 101.325 * 1000),
        UnidadeEngenharia.MM_HG : lambda x : (x  * 0.13332 * 1000),
        UnidadeEngenharia.MM_H2O : lambda x : (x * 0.0098 * 1000)
    }

    PRESSAO_DE_PA_PARA = {
        UnidadeEngenharia.PA : lambda x : x, 
        UnidadeEngenharia.KPA : lambda x : (x / 1000),
        UnidadeEngenharia.KGF_CM_2 : lambda x : (x / (98.0665 * 1000)),
        UnidadeEngenharia.LBF_POL_2 : lambda x : (x / (6.895 * 1000)),
        UnidadeEngenharia.BAR : lambda x : (x / 100000),
        UnidadeEngenharia.POL_HG : lambda x : (x / (3.386389  * 1000)),
        UnidadeEngenharia.POL_H2O : lambda x : (x / (0.24884 * 1000)),
        UnidadeEngenharia.ATM : lambda x : (x / (101.325 * 1000)),
        UnidadeEngenharia.MM_HG : lambda x : (x / (0.13332 * 1000)),
        UnidadeEngenharia.MM_H2O : lambda x : (x / (0.0098 * 1000))
    }

    ### TEMPERATURA ###

    TEMPERATURA_PARA_KELVIN_DE = {
        UnidadeEngenharia.KELVIN : lambda x : x, 
        UnidadeEngenharia.FAHRENHEIT : lambda x : ((x-32.0) * 5/9 + 273.15), 
        UnidadeEngenharia.CELSIUS : lambda x : (x + 273.15), 
        UnidadeEngenharia.RANKINE : lambda x : (x * 5/9)
    }

    TEMPERATURA_DE_KELVIN_PARA = {
        UnidadeEngenharia.KELVIN : lambda x : x, 
        UnidadeEngenharia.FAHRENHEIT : lambda x : ((x-273.15) * 9/5 + 32), 
        UnidadeEngenharia.CELSIUS : lambda x : (x - 273.15), 
        UnidadeEngenharia.RANKINE : lambda x : (x * 9/5)
    }

    ### ÁREA ###

    AREA_PARA_MM2_DE = {
        UnidadeEngenharia.MM_2 : lambda x : x, 
        UnidadeEngenharia.IN_2 : lambda x : (x * 645.16)
    }

    AREA_DE_MM2_PARA = {
        UnidadeEngenharia.MM_2 : lambda x : x, 
        UnidadeEngenharia.IN_2 : lambda x : (x * 0.00155)
    }

    ###  VOLUME / ENERGIA

    M3_PARA_MMBTU = lambda x : (x / 28.263682)

    ### VISCOSIDADE

    CP_PARA_NS_M2 = lambda x : (x / 1000) # centiPoise para N*S/M^2

#print(ConversaoUnidades.PRESSAO_PARA_PA.get(UnidadeEngenharia.KPA)((1)))