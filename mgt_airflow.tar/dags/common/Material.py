class Material :

    ACO_CARBONO = "ACO_CARBONO" #"Aço Carbono (SAE 1020)"
    ACO_5_CR = "ACO_5_CR" #"Aço 5% Cr" 
    ACO_2_CR_MO = "ACO_2_CRMO" #"Aço 2% Cr Mo" 
    INOX_301 = "ACO_INOX_AISI_301" #"Aço Inox AISI 301" 
    INOX_302 = "ACO_INOX_AISI_302" #"Aço Inox AISI 302" 
    INOX_304 = "ACO_INOX_AISI_304" #"Aço Inox AISI 304" 
    INOX_310 = "ACO_INOX_AISI_310" #"Aço Inox AISI 310" 
    INOX_316 = "ACO_INOX_AISI_316" #"Aço Inox AISI 316" 
    INOX_330 = "ACO_INOX_AISI_330" #"Aço Inox AISI 330" 
    INOX_347 = "ACO_INOX_AISI_347" #"Aço Inox AISI 347" 
    INOX_410 = "ACO_INOX_AISI_410" #"Aço Inox AISI 410" 
    MONEL = "MONEL" #"Monel"
    COBRE = "COBRE" #"Cobre"
    BRONZE_ALUMINIO = "BRONZE_ALUMINIO" #"Bronze Alumínio" 


COEFICIENTES_DILATACAO = {Material.ACO_CARBONO : lambda t : 0.000012,
                          Material.ACO_5_CR : lambda t : 0.000013,
                          Material.ACO_2_CR_MO : lambda t : 0.000014,
                          Material.INOX_301 : lambda t : (0.0000137) if t < 294.15 else 0.0000175,
                          Material.INOX_302 : lambda t : 0.0000185,
                          Material.INOX_304 : lambda t : (0.0000133) if t < 294.15 else 0.0000171,
                          Material.INOX_310 : lambda t : (0.0000126) if t < 294.15 else 0.0000165,
                          Material.INOX_316 : lambda t : (0.0000128) if t < 294.15 else 0.0000173,
                          Material.INOX_330 : lambda t : (0.0000104) if t < 294.15 else 0.0000160,
                          Material.INOX_347 : lambda t : (0.0000135) if t < 294.15 else 0.0000175,
                          Material.INOX_410 : lambda t : 0.000011,
                          Material.MONEL : lambda t : 0.000015,
                          Material.COBRE : lambda t : 0.0000167,
                          Material.BRONZE_ALUMINIO : lambda t : 0.0000166
                          }