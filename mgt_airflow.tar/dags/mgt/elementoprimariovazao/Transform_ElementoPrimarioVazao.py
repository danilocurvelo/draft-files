import math

from mgt.elementoprimariovazao.Modelo_ElementoPrimarioVazao import *
from common.UnidadeBase import *
from common.Material import *
from common.ConversaoUnidades import *
from common.DataInterpolation import *
from common.VaporAgua import *

NUMERO_MACH_INICIAL = 0.5
R = 8314.41 # Constante universal dos gases.
PRESSAO_EM_CONDICAO_NORMAL = 101325

def calcular_vazoes_elementoprimariovazao(pressoes_montante, pressoes_jusante, pressoes_atmosferica, temperaturas, unidades_transmissores, estado_fluido, tipo_elemento, beta, material_tubulacao, material_elemento, diametro_interno, coef_isentropico, peso_molecular, fator_compressibilidade, viscosidade, preco_fluido_usd_por_mmbtu) :

    vazoes_massicas_instantaneas = []
    vazoes_volumetricas_instantaneas = []
    registros_vazao_massica = []
    registros_vazao_volumetrica = []

    vazao_instantanea_anterior = None
    for (p_montante, p_jusante, p_atmosferica, t) in zip(pressoes_montante, pressoes_jusante, pressoes_atmosferica, temperaturas) :

        if (coef_isentropico == 0 or coef_isentropico == 1 or fator_compressibilidade == 0 or peso_molecular == 0 or viscosidade == 0) : continue # Condições para evitar divisão por zero
        
        ## Conversão de unidades dos transmissores
        pressao_montante = p_montante['value']
        pressao_montante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_montante'])(pressao_montante)
        pressao_montante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_ELEMENTOPRIMARIOVAZAO_BASE)(pressao_montante)
        if (pressao_montante <= 0) : continue # Caso a pressão a montante seja zero ou negativa.

        pressao_jusante = p_jusante['value']
        pressao_jusante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_jusante'])(pressao_jusante)
        pressao_jusante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_ELEMENTOPRIMARIOVAZAO_BASE)(pressao_jusante)
        if (pressao_jusante <= 0) : continue # Caso a pressão a jusante seja zero ou negativa.

        pressao_atmosferica = p_atmosferica['value']
        pressao_atmosferica = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_atmosferica'])(pressao_atmosferica)
        pressao_atmosferica = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_ELEMENTOPRIMARIOVAZAO_BASE)(pressao_atmosferica)

        temperatura = t['value']
        temperatura = ConversaoUnidades.TEMPERATURA_PARA_KELVIN_DE.get(unidades_transmissores['temperatura'])(temperatura)
        temperatura = ConversaoUnidades.TEMPERATURA_DE_KELVIN_PARA.get(UNIDADE_TEMPERATURA_ELEMENTOPRIMARIOVAZAO_BASE)(temperatura)
        # Caso a temperatura absoluta (K) seja menor ou igual a zero, ignora a amostra (erro de leitura do sensor)
        if (UNIDADE_TEMPERATURA_ELEMENTOPRIMARIOVAZAO_BASE == UnidadeEngenharia.KELVIN and temperatura <= 0) : continue 

        pressao_montante_absoluto = pressao_montante + pressao_atmosferica
        # Caso a pressão absoluta seja menor que 0, arredonda para 0.
        pressao_montante_absoluto = pressao_montante_absoluto if (pressao_montante_absoluto >= 0) else 0

        ## Verificação se o fluxo é crítico, caso contrário não realiza inferência de vazão.
        escoamento_critico = (pressao_montante - pressao_jusante) >= diferencial_pressao_critico(coef_isentropico, pressao_montante_absoluto)

        if (not escoamento_critico) : # Caso sub-crítico, a vazão é zero, pula para a próxima iteração.
            vazoes_massicas_instantaneas.append(0.0)
            registros_vazao_massica.append({'timestamp' : p_montante['timestamp'], 'value' : 0.0})
            vazoes_volumetricas_instantaneas.append(0.0)
            registros_vazao_volumetrica.append({'timestamp' : p_montante['timestamp'], 'value' : 0.0})
            continue 

        ## Cálculo dos diâmetros do orifício, tubulação e beta na temperatura de operação, considerando a dilatação térmica
        diametro_orificio = diametro_interno * beta
        if (diametro_orificio == 0) : continue # Tubulação ou orifício com diâmeotro zero
        diametro_tubulacao_t_operacao = calcular_dilatacao_termica_linear(diametro_interno, COEFICIENTES_DILATACAO[material_tubulacao](temperatura), temperatura)
        diametro_orificio_t_operacao = calcular_dilatacao_termica_linear(diametro_orificio, COEFICIENTES_DILATACAO[material_elemento](temperatura), temperatura)
        beta_t_operacao = diametro_orificio_t_operacao / diametro_tubulacao_t_operacao

        ## Cálculo das vazões instantâneas
        vazao_instantanea = calcular_vazao_instantanea(estado_fluido, tipo_elemento, beta_t_operacao, diametro_tubulacao_t_operacao, coef_isentropico, pressao_montante_absoluto, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_instantanea_anterior) 
        vazao_instantanea_anterior = vazao_instantanea['vazaoMassica']

        vazoes_massicas_instantaneas.append(vazao_instantanea['vazaoMassica'])
        registros_vazao_massica.append({'timestamp' : p_montante['timestamp'], 'value' : vazao_instantanea['vazaoMassica']})
        
        vazoes_volumetricas_instantaneas.append(vazao_instantanea['vazaoVolumetrica'])
        registros_vazao_volumetrica.append({'timestamp' : p_montante['timestamp'], 'value' : vazao_instantanea['vazaoVolumetrica']})

    vazao_massica_media = (sum(vazoes_massicas_instantaneas)/len(vazoes_massicas_instantaneas)) if (len(vazoes_massicas_instantaneas) > 0) else 0
    vazao_volumetrica_media = (sum(vazoes_volumetricas_instantaneas)/len(vazoes_volumetricas_instantaneas)) if (len(vazoes_volumetricas_instantaneas) > 0) else 0

    custo_por_hora = ConversaoUnidades.M3_PARA_MMBTU(vazao_volumetrica_media) * preco_fluido_usd_por_mmbtu

    return {'vazoes_massica': registros_vazao_massica, 'vazao_massica_media' : vazao_massica_media,
            'vazoes_volumetrica': registros_vazao_volumetrica, 'vazao_volumetrica_media' : vazao_volumetrica_media,
            'custo_por_hora' : custo_por_hora }

def calcular_vazao_instantanea(estado_fluido, tipo_elemento, beta, diametro_interno, coef_isentropico, pressao_montante, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_instantanea_anterior=None) :
    vazao_massica = 0
    vazao_volumetrica = 0

    if Estado.GAS.lower() == estado_fluido.lower() :
        vazao_massica = calcular_vazao_massica_gas(tipo_elemento, beta, diametro_interno, coef_isentropico, pressao_montante, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_instantanea_anterior)
        vazao_volumetrica = calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade, temperatura)
    
    elif Estado.VAPOR.lower() == estado_fluido.lower() :
        vazao_massica = calcular_vazao_massica_gas(tipo_elemento, beta, diametro_interno, CPCV_VAPOR, pressao_montante, PESO_MOLECULAR_VAPOR, FATOR_COMPRESSIBILIDADE_VAPOR, VISCOSIDADE_VAPOR, temperatura, vazao_instantanea_anterior)
        vazao_volumetrica = calcular_vazao_volumetrica_gas(vazao_massica, PESO_MOLECULAR_VAPOR, FATOR_COMPRESSIBILIDADE_VAPOR, temperatura)

    return {'vazaoMassica' : vazao_massica, 'vazaoVolumetrica' : vazao_volumetrica}

def calcular_vazao_massica_gas(tipo_elemento, beta, diametro_interno, coef_isentropico, pressao_montante, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_instantanea_anterior=None) :
    """
    Params:
    tipo_elemento -> Tipo do elemento primário
    beta -> Beta do orifício a temperatura de operação
    diametro_interno -> diâmetro interno da tubulação
    coef_isentropico -> Coeficiente isentrópico do gás
    pressao_montante -> Pressão a montante do orifício [Pa], em absoluto
    peso_molecular -> Peso molecular do gás [kg/kmol]
    fator_compressibilidade -> Fator de compressibilidade do gás
    viscosidade -> Viscosidade do fluido em cP
    temperatura -> Temperatura do gás a montante do orifício [K]
    w_0 -> Valor da anterior usado no cálculo de v1. Inicial = 0.5 (Número de Mach)
    vazao_instantanea_anterior -> Valor da vazão instantanea no instante anterior

    Retorna a vazão mássica, em [kg/s] calculada com os parâmetros
    """

    diametro_interno_em_m = diametro_interno / 1000

    c = coeficiente_de_descarga(tipo_elemento, vazao_instantanea_anterior, viscosidade, diametro_interno_em_m)
    m = NUMERO_MACH_INICIAL

    if vazao_instantanea_anterior is not None: # Verificando se é a primeira iteração...
        v1 = velocidade_do_gas_a_montante(vazao_instantanea_anterior, fator_compressibilidade, temperatura, diametro_interno_em_m, pressao_montante, peso_molecular)
        vs = velocidade_do_som_no_gas_a_montante(coef_isentropico, temperatura, peso_molecular)
        m = numero_de_mach(v1, vs)

    y = coeficiente_de_escoamento_critico_isentropico(coef_isentropico) 
    p1_t = pressao_total_de_estagnacao_a_montante(pressao_montante, m, coef_isentropico)

    return c * math.pow(beta, 2) * ((math.pi * math.pow(diametro_interno_em_m, 2)) / 4) * y * p1_t * math.sqrt(peso_molecular / (R * fator_compressibilidade * temperatura))

def calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade, temperatura) :
    rho = calcular_rho(peso_molecular, PRESSAO_EM_CONDICAO_NORMAL, fator_compressibilidade, R, temperatura);
    return vazao_massica / rho

def calcular_rho(peso_molecular, pressao, fator_compressibilidade, r, temperatura) :
    """
    Determina a massa específica.
    """
    return (peso_molecular * pressao) / (fator_compressibilidade * r * temperatura)

def coeficiente_de_descarga_para_reynolds_infinito(tipo_elemento) :
    if (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_TOROIDAL) :
        return 0.9935
    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_CILINDRICA) :
        return 1.0
    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_ASME) :
        return 1.0
    else : # Placa de orifício de bordo reto
        return 0.83932

def coeficiente_de_descarga(tipo_elemento, vazao_anterior, viscosidade, diametro_interno) :
    c_inf = coeficiente_de_descarga_para_reynolds_infinito(tipo_elemento)

    if (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_TOROIDAL) :
        reynolds = calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno)
        return c_inf - 1.525 * math.pow(reynolds, -0.5)

    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_CILINDRICA) :
        reynolds = calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno)
        if (reynolds < (3.5e+5)) : # Re fora da faixa
            return 0.9887
        if (reynolds < (2.5e+7)) :
            return 0.9887
        elif (reynolds <= (2.0e+7)) :
            return c_inf - 0.2165 * math.pow(reynolds, -0.2)
        else :
            return c_inf - 0.2165 * math.pow(reynolds, -0.2) # Re fora da faixa

    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_ASME) :
        reynolds = calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno)
        if (reynolds < (1.0e+4)) : # Re fora da faixa
            return c_inf - 7.21 * math.pow(reynolds, -0.5)
        elif (reynolds < (4.0e+5)) : 
            return c_inf - 7.21 * math.pow(reynolds, -0.5)
        elif (reynolds <= (2.8e+6)) : 
            return 0.9886
        elif (reynolds <= (2.0e+7)) : 
            return c_inf - 0.222 * math.pow(reynolds, -0.2)
        else :
            return c_inf - 0.222 * math.pow(reynolds, -0.2) # Re fora da faixa
    
    else : # Placa de orifício de bordo reto
        return c_inf

def calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno) :
    if (vazao_anterior is None) : return 1e100 # Reynolds infinito

    viscosidade_em_ns_m2 = ConversaoUnidades.CP_PARA_NS_M2(viscosidade)

    return (4 * vazao_anterior) / (math.pi * viscosidade_em_ns_m2 * diametro_interno)

def calcular_area_interna_tubulacao(diametro) :
    """
    Param: diametro -> diametro interno da tubulação

    Determina a área interna da tubulação.
    """
    return math.pi * (math.pow(diametro, 2.0) / 4.0)

def calcular_dilatacao_termica_linear(comprimento, coef_dilatacao, temperatura) :
    """
    Param: comprimento -> comprimento em 20C
    Param: coef_dilatacao -> coeficiente de dilatação térmica
    Param: temperatura -> temperatura de operação em K

    Determina dilatação térmica linear (20C para T de operação).
    """
    return comprimento * (1 + coef_dilatacao * (temperatura - 293.15))

def diferencial_pressao_critico(k, p1) :
    """
    Param: k -> coeficiente isentrópico do gás
    Param: p1 -> pressão a montante absoluta (p + patm)

    Identifica se o fluxo é crítico ou sub-crítico.
    """
    return p1 * (1 - math.pow((2 / (k + 1)), (k / (k - 1))))

def coeficiente_de_escoamento_critico_isentropico(k) :
    """
    Param: k -> coeficiente isentrópico do gás
    Param: z -> fator de compressilidade do gás

    Recebe k e retorna coeficiente de escoamento crítico isentrópico (Y).
    """
    return math.sqrt(k * math.pow( 2 / (k + 1), (k + 1) / (k - 1)))

def pressao_total_de_estagnacao_a_montante(p1, m, k):
    """
    Params: 
    k -> coeficiente isentrópico do gás
    p1 -> pressão a montante do orifício [Pa] em absoluto.
    m -> Número de Mach

    Retorna a pressão total de estagnação a montante do oríficio.
    """
    return p1 * math.pow(1 + ((k - 1) / 2) * math.pow(m, 2), k / (k - 1))

def numero_de_mach(v1, vs):
    """
    Params: 
    v1 -> velocidade do gás na linha a montante do orifício (m/s)
    vs -> velocidade do som no gás a montante do orifício (m/s)

    Retorna o cálculo do número de Mach.
    """
    return v1 / vs 

def velocidade_do_gas_a_montante(w, z, t, d, p1, pm):
    """
    Params:
    w -> vazão mássica (kg/s)
    z -> fator de compressibilidade do gás
    t -> temperatura do gás a montante do orifício (K)
    d -> diâmetro interno da tubulação (m)
    p1 -> pressão a montante do orifício [Pa] em absoluto
    pm -> peso molecular do gás (kg/kmol)

    Retorna a velocidade do gás na linha a montante do orifício [m/s].
    """
    #return (33257.2 * w * z * t) / (math.pi * math.pow(d, 2) * p1 * pm)
    return w / (calcular_area_interna_tubulacao(d) * calcular_rho(pm, p1, z, R, t))

def velocidade_do_som_no_gas_a_montante(k, t, pm):
    """
    Params:
    t -> temperatura do gás a montante do orifício (K)
    pm -> peso molecular do gás (kg/kmol)
    k -> coeficiente isentrópico do gás

    Retorna a velocidade do som no gás a montante do orifício [m/s].
    """
    return math.sqrt(R * (k * t) / pm)


### Task Airflow

def transform(parametros, id):
    
    pressoes_montante = parametros['pressao_montante']
    pressoes_jusante = parametros['pressao_jusante']
    pressoes_atmosferica = parametros['pressao_atmosferica']
    temperaturas = parametros['temperatura']

    tags_escrita = {'custoPorHora': parametros['custoPorHora'], 
                    'vazaoMassica': parametros['vazaoMassica'], 
                    'vazaoMassicaPorHora': parametros['vazaoMassicaPorHora'], 
                    'vazaoVolumetrica': parametros['vazaoVolumetrica'], 
                    'vazaoVolumetricaPorHora': parametros['vazaoVolumetricaPorHora']}

    reference_length = len(pressoes_montante)

    if (len(pressoes_montante) == 0) : raise ValueError('Não existem registros de pressão a montante no período avaliado.')

    if ( isinstance(pressoes_jusante, list) ) :
        if (len(pressoes_jusante) == 0) : raise ValueError('Não existem registros de pressão a jusante no período avaliado.')
        pressoes_jusante = resize_records(pressoes_jusante, reference_length, ['value', 'timestamp'])
    else :
        pressoes_jusante = [{"value" : pressoes_jusante}] * reference_length

    if ( isinstance(pressoes_atmosferica, list) ) :
        if (len(pressoes_atmosferica) == 0) : raise ValueError('Não existem registros de pressão atmosférica no período avaliado.')
        pressoes_atmosferica = resize_records(pressoes_atmosferica, reference_length, ['value', 'timestamp'])
    else :
        pressoes_atmosferica = [{"value" : pressoes_atmosferica}] * reference_length
    
    if ( isinstance(temperaturas, list) ) :
        if (len(temperaturas) == 0) : raise ValueError('Não existem registros de temperatura no período avaliado.')
        temperaturas = resize_records(temperaturas, reference_length, ['value', 'timestamp'])
    else :
        temperaturas = [{"value" : temperaturas}] * reference_length

    unidades_transmissores = {
        'pressao_atmosferica' : parametros['pressao_atmosferica_unidade'],
        'pressao_montante' : parametros['pressao_montante_unidade'],
        'pressao_jusante' : parametros['pressao_jusante_unidade'],
        'temperatura' : parametros['temperatura_unidade']
    }

    resultado = calcular_vazoes_elementoprimariovazao(pressoes_montante=pressoes_montante, 
                                                      pressoes_jusante=pressoes_jusante,
                                                      pressoes_atmosferica=pressoes_atmosferica,
                                                      temperaturas=temperaturas, 
                                                      unidades_transmissores=unidades_transmissores,
                                                      estado_fluido=parametros['estado'], 
                                                      tipo_elemento=parametros['tipo'], 
                                                      beta=parametros['beta'], 
                                                      material_tubulacao=parametros['material_tubulacao'],
                                                      material_elemento=parametros['material_elemento'],
                                                      diametro_interno=parametros['diametro'], 
                                                      coef_isentropico=parametros['k'], 
                                                      peso_molecular=parametros['mw'], 
                                                      fator_compressibilidade=parametros['z'], 
                                                      viscosidade=parametros['viscosidade'], 
                                                      preco_fluido_usd_por_mmbtu=parametros['preco_fluido_usd_por_mmbtu'])

    resultado['tags_escrita'] = tags_escrita
    resultado['timestamp_media'] = parametros['timestamp_media']

    return resultado