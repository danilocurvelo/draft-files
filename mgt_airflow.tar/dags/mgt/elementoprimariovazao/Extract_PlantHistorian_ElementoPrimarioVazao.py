from common.UnidadeBase import *
from mgt.elementoprimariovazao.Modelo_ElementoPrimarioVazao import *

from common.PlantHistorian import *

from airflow.models import Variable

def extract_data_from_planthistorian(inference_metadata):
    client = connect_to_historian(Variable.get("PLANTHISTORIAN_HOST"), Variable.get("PLANTHISTORIAN_PORT"))
    parameters = get_constant_data(inference_metadata)
    data = get_variable_data_from_historian(client, inference_metadata)
    parameters.update(data) # merge data.
    return parameters

def get_constant_data(inference_metadata):

    parameters = {'id_ativo' : inference_metadata["elementoPrimarioVazao"]["id"],
                  'tag_ativo' : inference_metadata["elementoPrimarioVazao"]["tag"],
                  'tipo' : inference_metadata["elementoPrimarioVazao"]["tipoDoElemento"],
                  'estado' : inference_metadata["fluido"]["tipoFluido"],
                  'beta' : inference_metadata["elementoPrimarioVazao"]["beta"], 
                  'material_tubulacao' : inference_metadata["elementoPrimarioVazao"]["material"], 
                  'material_elemento' : inference_metadata["elementoPrimarioVazao"]["materialDoElemento"],
                  'diametro' : inference_metadata["elementoPrimarioVazao"]["diametroInterno"],
                  'k' : inference_metadata["coeficienteIsentropico"], 
                  'z' : inference_metadata["fatorCompressibilidade"], 
                  'mw' : inference_metadata.get('pesoMolecular', 1),
                  'viscosidade' : inference_metadata.get("viscosidade", 0.01),
                  #'preco_fluido_usd_por_mmbtu' : _get_fluid_price(inference_metadata['fluido']),

                  'custoPorHora' : inference_metadata["custoPorHora"], 
                  'vazaoMassica' : inference_metadata["vazaoMassica"],
                  'vazaoMassicaPorHora' : inference_metadata["vazaoMassicaPorHora"],
                  'vazaoVolumetrica' : inference_metadata["vazaoVolumetrica"],
                  'vazaoVolumetricaPorHora' : inference_metadata["vazaoVolumetricaPorHora"]
                }

    return parameters

def get_variable_data_from_historian(client, inference_metadata):
    
    # Timezone
    tz_utc_minus_3 = timedelta(hours=3)
    
    # Janela de tempo = 1h
    now = datetime.now() + tz_utc_minus_3 # Transformando em UTC

    # Início da janela com hora inteira (Ex: 16:03 => 16:00)
    window_end = now.replace(minute=0, second=0, microsecond=0)

    timestamp_fim = Timestamp()
    timestamp_fim.FromDatetime(window_end)
    timestamp_inicio = Timestamp()
    timestamp_inicio.FromDatetime(window_end - timedelta(hours=1))  

    # valores dos transmissores e suas unidades
    pressao_montante = None
    pressao_montante_unidade = UNIDADE_PRESSAO_CONSTANTE
    pressao_jusante = None
    pressao_jusante_unidade = UNIDADE_PRESSAO_CONSTANTE
    pressao_atmosferica = None
    pressao_atmosferica_unidade = UNIDADE_PRESSAO_CONSTANTE
    temperatura = None
    temperatura_unidade = UNIDADE_TEMPERATURA_CONSTANTE

    # pressaoMontante
    if (_is_property_constant(inference_metadata, "pressaoMontante")):
        pressao_montante = inference_metadata["pressaoMontante"]["constante"]
    else :
        pressao_montante = get_data_from_historian(client, inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["tag"], timestamp_inicio, timestamp_fim)
        pressao_montante_unidade = inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]

    # pressaoJusante
    if (_is_property_constant(inference_metadata, "pressaoJusante")):
        pressao_jusante = inference_metadata["pressaoJusante"]["constante"]
    else :
        pressao_jusante = get_data_from_historian(client, inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["tag"], timestamp_inicio, timestamp_fim)
        pressao_jusante_unidade = inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]

    # pressaoAtmosferica
    if (_is_property_constant(inference_metadata, "pressaoAtmosferica")):
        pressao_atmosferica = inference_metadata["pressaoAtmosferica"]["constante"]
    else :
        pressao_atmosferica = get_data_from_historian(client, inference_metadata["pressaoAtmosferica"]["transmissor"]["leituraValorHistorico"]["tag"], timestamp_inicio, timestamp_fim)
        pressao_atmosferica_unidade = inference_metadata["pressaoAtmosferica"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]

    # temperaturaMontante
    if (_is_property_constant(inference_metadata, "temperaturaMontante")):
        temperatura = inference_metadata["temperaturaMontante"]["constante"]
    else :
        temperatura = get_data_from_historian(client, inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["tag"], timestamp_inicio, timestamp_fim)
        temperatura_unidade = inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]

    # preço do fluido USD por MMBTU
    if (not inference_metadata['fluido']['calculoHabilitado']) : # Totalização monetária desativada
        preco_fluido_usd_por_mmbtu = 0
    else :    
        preco_fluido_usd_por_mmbtu = _get_fluid_price(inference_metadata['fluido'])

    if (preco_fluido_usd_por_mmbtu == -1) : # preço snapshot no historiador
        preco_fluido_usd_por_mmbtu = get_snapshot_from_historian(client, inference_metadata["fluido"]['leituraFluido']['leituraValor']['tag'])
        preco_fluido_usd_por_mmbtu = 0 if (len(preco_fluido_usd_por_mmbtu) == 0) else preco_fluido_usd_por_mmbtu[0]['value']
    
    # Timestamp em segundos com GMT-3 para inserir na média.
    window_end = window_end - timedelta(hours=3)
    timestamp_media = int(window_end.timestamp())
    
    data = {'pressao_atmosferica' : pressao_atmosferica,
            'pressao_atmosferica_unidade' : pressao_atmosferica_unidade,
            'pressao_montante' : pressao_montante,
            'pressao_montante_unidade' : pressao_montante_unidade,
            'pressao_jusante' : pressao_jusante,
            'pressao_jusante_unidade' : pressao_jusante_unidade,
            'temperatura' : temperatura,
            'temperatura_unidade' : temperatura_unidade,
            'timestamp_media' : timestamp_media,
            'preco_fluido_usd_por_mmbtu' : preco_fluido_usd_por_mmbtu
    } 

    return data

def _is_property_constant(inference_metadata, property):
    if (inference_metadata[property]["tipoLeitura"] == "CONSTANTE"):
        return True

def _get_fluid_price(fluido) :
    if (fluido['leituraFluido']['tipoLeitura'] == "FATOR") : # Fator
        return fluido['leituraFluido']['fator'] * _get_fluid_price(fluido['leituraFluido']['fluido'])
    elif (fluido['leituraFluido']['tipoLeitura'] == "LEITURA_VALOR") :
        if (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "CONSTANTE") : # Constante
            return float(fluido['leituraFluido']['leituraValor']['valor'])
        elif (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "TAG_OPC") : # Tag historiada
            return -1
    else :
        return 0
