from common.PlantExpert import PlantExpert
from airflow.models import Variable

def extract_data_from_plantexpert(id):
    return get_inference_data_from_id(id)

def get_inference_data_from_id(id):
    pe = PlantExpert(Variable.get("PLANTEXPERT_HOST"), Variable.get("PLANTEXPERT_USER"), Variable.get("PLANTEXPERT_PASSWD"))
    ativo = pe.get_flow_inference_data_from_id(id)

    return ativo
