from mgt.valvulacontrole.Modelo_ValvulaControle import *
from common.UnidadeBase import *

from google.protobuf.timestamp_pb2 import Timestamp
from datetime import datetime, timedelta

from historian_grpc_client.generated.api_pb2 import ListData, Data, Metadata, Record, TagRegex, DataRequest
from historian_grpc_client.api import HistorianGrpcClient, HistorianError
from airflow.models import Variable

def extract_data_from_planthistorian(inference_metadata):
    client = connect_to_historian()
    parameters = get_constant_data(inference_metadata)
    data = get_variable_data_from_historian(client, inference_metadata)
    parameters.update(data) # merge data.
    return parameters

def connect_to_historian():
    return HistorianGrpcClient(Variable.get("PLANTHISTORIAN_HOST"), Variable.get("PLANTHISTORIAN_PORT"))

def get_constant_data(inference_metadata):

    parameters = {'id_ativo' : inference_metadata["valvulaControle"]["id"],
                  'tag_ativo' : inference_metadata["valvulaControle"]["tag"],
                  'caracteristica_vazao' : inference_metadata["valvulaControle"]["caracteristicaVazao"],
                  'estado' : inference_metadata["fluido"]["tipoFluido"],
                  'cv' : inference_metadata["valvulaControle"].get("cv", 1),
                  'fl' : inference_metadata["valvulaControle"].get("fl", 1),
                  'xt' : inference_metadata["valvulaControle"].get("xt", 1),
                  'rho' : inference_metadata.get('massaEspecifica', 1),
                  'p_vap' : inference_metadata.get('pressaoVapor', 1),
                  'p_crit' : inference_metadata.get('pressaoCritica', 1),
                  'cpcv' : inference_metadata.get('cpcv', 1),
                  'z' : inference_metadata.get('fatorCompressibilidade', 1),
                  'mw' : inference_metadata.get('pesoMolecular', 1),
                  'offset_posicao' : inference_metadata['valvulaControle'].get('offsetPosicao', 0),
                  #'preco_fluido_usd_por_mmbtu' : _get_fluid_price(inference_metadata['fluido']),

                  'custoPorHora' : inference_metadata["custoPorHora"], 
                  'vazaoMassica' : inference_metadata["vazaoMassica"],
                  'vazaoMassicaPorHora' : inference_metadata["vazaoMassicaPorHora"],
                  'vazaoVolumetrica' : inference_metadata["vazaoVolumetrica"],
                  'vazaoVolumetricaPorHora' : inference_metadata["vazaoVolumetricaPorHora"]
                
    }

    return parameters


def get_variable_data_from_historian(client, inference_metadata):

    # Timezone
    tz_utc_minus_3 = timedelta(hours=3) 
    
    # Janela de tempo = 1h
    now = datetime.now() + tz_utc_minus_3 # Transformando em UTC

    # Início da janela com hora inteira (Ex: 16:03 => 16:00)
    window_end = now.replace(minute=0, second=0, microsecond=0)

    timestamp_fim = Timestamp()
    timestamp_fim.FromDatetime(window_end)
    timestamp_inicio = Timestamp()
    timestamp_inicio.FromDatetime(window_end - timedelta(hours=1))  

    # abertura da válvula de controle
    abertura = get_data_from_historian(client, inference_metadata["valvulaControle"]["tagAberturaHistorica"]["tag"], timestamp_inicio, timestamp_fim)

    # valores dos transmissores e suas unidades
    pressao_montante = None
    pressao_montante_unidade = UNIDADE_PRESSAO_CONSTANTE
    pressao_jusante = None
    pressao_jusante_unidade = UNIDADE_PRESSAO_CONSTANTE
    temperatura = None
    temperatura_unidade = UNIDADE_TEMPERATURA_CONSTANTE

    # pressaoMontante
    if (_is_property_constant(inference_metadata, "pressaoMontante")):
        pressao_montante = inference_metadata["pressaoMontante"]["constante"]
    else :
        pressao_montante = get_data_from_historian(client, inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["tag"], timestamp_inicio, timestamp_fim)
        pressao_montante_unidade = inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]

    # pressaoJusante
    if (_is_property_constant(inference_metadata, "pressaoJusante")):
        pressao_jusante = inference_metadata["pressaoJusante"]["constante"]
    else :
        pressao_jusante = get_data_from_historian(client, inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["tag"], timestamp_inicio, timestamp_fim)
        pressao_jusante_unidade = inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]

    # temperaturaMontante
    if (_is_property_constant(inference_metadata, "temperaturaMontante")):
        temperatura = inference_metadata["temperaturaMontante"]["constante"]
    else :
        temperatura = get_data_from_historian(client, inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["tag"], timestamp_inicio, timestamp_fim)
        temperatura_unidade = inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]

    # preço do fluido USD por MMBTU
    preco_fluido_usd_por_mmbtu = _get_fluid_price(inference_metadata['fluido'])
    if (preco_fluido_usd_por_mmbtu == -1) : # preço no historiador
        preco_fluido_usd_por_mmbtu = get_data_from_historian(client, inference_metadata["fluido"]['leituraFluido']['leituraValor']['tag'], timestamp_inicio, timestamp_fim)
        preco_fluido_usd_por_mmbtu = 0 if (len(preco_fluido_usd_por_mmbtu) == 0) else preco_fluido_usd_por_mmbtu[0]['value']

    # Timestamp em segundos com GMT-3 para inserir na média.
    window_end = window_end - timedelta(hours=3)
    timestamp_media = int(window_end.timestamp())
    
    data = {'abertura' : abertura,
            'pressao_montante' : pressao_montante,
            'pressao_montante_unidade' : pressao_montante_unidade,
            'pressao_jusante' : pressao_jusante,
            'pressao_jusante_unidade' : pressao_jusante_unidade,
            'temperatura' : temperatura,
            'temperatura_unidade' : temperatura_unidade,
            'timestamp_media' : timestamp_media,
            'preco_fluido_usd_por_mmbtu' : preco_fluido_usd_por_mmbtu
    } 

    return data

def _is_property_constant(inference_metadata, property):
    if (inference_metadata[property]["tipoLeitura"] == "CONSTANTE"):
        return True

def _get_fluid_price(fluido) :
    if (fluido['leituraFluido']['tipoLeitura'] == "FATOR") : # Fator
        return fluido['leituraFluido']['fator'] * _get_fluid_price(fluido['leituraFluido']['fluido'])
    elif (fluido['leituraFluido']['tipoLeitura'] == "LEITURA_VALOR") :
        if (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "CONSTANTE") : # Constante
            return float(fluido['leituraFluido']['leituraValor']['valor'])
        elif (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "TAG_OPC") : # Tag historiada
            return -1
    else :
        return 0

def get_data_from_historian(historian, tag, data_inicio, data_fim):
    tag_regex = TagRegex(valor=tag)
    tags_metadata = historian.find_tags(tag_regex).listMetadata

    timestamp_fim = data_fim
    timestamp_inicio = data_inicio

    data_request = DataRequest(listMetaData=tags_metadata,
                                startDate=timestamp_inicio,
                                finalDate=timestamp_fim)
    retrieved_data = historian.find(data_request).listData

    return _single_var_protobuf_to_list(retrieved_data)

def _single_var_protobuf_to_list(protobuf_obj,
                                timestamp_col: str = "timestamp",
                                value_col: str = "value",
                                tag_col: str = "tag"):

    data_list = []
    for data_tag in protobuf_obj:
        metadata = data_tag.metadata
        tag_name = metadata.name
        records = data_tag.records

        for r in records:
            record = {tag_col: tag_name,
                        timestamp_col: r.timestamp.seconds,
                        value_col: float(r.value)}
            data_list.append(record)
    return data_list
