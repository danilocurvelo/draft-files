from common.UnidadeBase import *
from mgt.valvulacontrole.Modelo_ValvulaControle import *

from common.PlantHistorian import *

from airflow.models import Variable

def extract_data_from_planthistorian(inference_metadata):
    client = connect_to_historian(Variable.get("PLANTHISTORIAN_HOST"), Variable.get("PLANTHISTORIAN_PORT"))
    parameters = get_constant_data(inference_metadata)
    data = get_variable_data_from_historian(client, inference_metadata)
    parameters.update(data) # merge data.
    return parameters

def get_constant_data(inference_metadata):

    parameters = {'id_ativo' : inference_metadata["valvulaControle"]["id"],
                  'tag_ativo' : inference_metadata["valvulaControle"]["tag"],
                  'caracteristica_vazao' : inference_metadata["valvulaControle"]["caracteristicaVazao"],
                  'estado' : inference_metadata["fluido"]["tipoFluido"],
                  'cv' : inference_metadata["valvulaControle"].get("cv", 1),
                  'fl' : inference_metadata["valvulaControle"].get("fl", 1),
                  'xt' : inference_metadata["valvulaControle"].get("xt", 1),
                  'rho' : inference_metadata.get('massaEspecifica', 1),
                  'p_vap' : inference_metadata.get('pressaoVapor', 1),
                  'p_crit' : inference_metadata.get('pressaoCritica', 1),
                  'cpcv' : inference_metadata.get('cpcv', 1),
                  'z' : inference_metadata.get('fatorCompressibilidade', 1),
                  'mw' : inference_metadata.get('pesoMolecular', 1),
                  'offset_posicao' : inference_metadata['valvulaControle'].get('offsetPosicao', 0),
                  #'preco_fluido_usd_por_mmbtu' : _get_fluid_price(inference_metadata['fluido']),

                  'custoPorHora' : inference_metadata["custoPorHora"], 
                  'vazaoMassica' : inference_metadata["vazaoMassica"],
                  'vazaoMassicaPorHora' : inference_metadata["vazaoMassicaPorHora"],
                  'vazaoVolumetrica' : inference_metadata["vazaoVolumetrica"],
                  'vazaoVolumetricaPorHora' : inference_metadata["vazaoVolumetricaPorHora"]
                
    }

    return parameters


def get_variable_data_from_historian(client, inference_metadata):

    # Timezone
    tz_utc_minus_3 = timedelta(hours=3) 
    
    # Janela de tempo = 1h
    now = datetime.now() + tz_utc_minus_3 # Transformando em UTC

    # Início da janela com hora inteira (Ex: 16:03 => 16:00)
    window_end = now.replace(minute=0, second=0, microsecond=0)

    timestamp_fim = Timestamp()
    timestamp_fim.FromDatetime(window_end)
    timestamp_inicio = Timestamp()
    timestamp_inicio.FromDatetime(window_end - timedelta(hours=1))  

    # abertura da válvula de controle
    tag_abertura = inference_metadata["valvulaControle"]["tagAberturaHistorica"]["tag"]
    abertura = get_data_from_historian(client, tag_abertura, timestamp_inicio, timestamp_fim)
    if (len(abertura) == 0) : raise ValueError('Não existem registros de abertura (' + str(tag_abertura) + ') no período avaliado: ' + str(timestamp_inicio) + " - " + str(timestamp_fim))

    # valores dos transmissores e suas unidades
    pressao_montante = None
    pressao_montante_unidade = UNIDADE_PRESSAO_CONSTANTE
    pressao_jusante = None
    pressao_jusante_unidade = UNIDADE_PRESSAO_CONSTANTE
    temperatura = None
    temperatura_unidade = UNIDADE_TEMPERATURA_CONSTANTE

    # pressaoMontante
    if (_is_property_constant(inference_metadata, "pressaoMontante")):
        pressao_montante = inference_metadata["pressaoMontante"]["constante"]
    else :
        tag_pressao_montante = inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["tag"]
        pressao_montante = get_data_from_historian(client, tag_pressao_montante, timestamp_inicio, timestamp_fim)
        pressao_montante_unidade = inference_metadata["pressaoMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]
        if (len(pressao_montante) == 0) : raise ValueError('Não existem registros de pressão a montante (' + str(tag_pressao_montante) + ') no período avaliado: ' + str(timestamp_inicio) + " - " + str(timestamp_fim))

    # pressaoJusante
    if (_is_property_constant(inference_metadata, "pressaoJusante")):
        pressao_jusante = inference_metadata["pressaoJusante"]["constante"]
    else :
        tag_pressao_jusante = inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["tag"]
        pressao_jusante = get_data_from_historian(client, tag_pressao_jusante, timestamp_inicio, timestamp_fim)
        pressao_jusante_unidade = inference_metadata["pressaoJusante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]
        if (len(pressao_jusante) == 0) : raise ValueError('Não existem registros de pressão a jusante (' + str(tag_pressao_jusante) + ') no período avaliado: ' + str(timestamp_inicio) + " - " + str(timestamp_fim))

    # temperaturaMontante
    if (_is_property_constant(inference_metadata, "temperaturaMontante")):
        temperatura = inference_metadata["temperaturaMontante"]["constante"]
    else :
        tag_temperatura = inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["tag"]
        temperatura = get_data_from_historian(client, tag_temperatura, timestamp_inicio, timestamp_fim)
        temperatura_unidade = inference_metadata["temperaturaMontante"]["transmissor"]["leituraValorHistorico"]["unidadeEngenharia"]
        if (len(temperatura) == 0) : raise ValueError('Não existem registros de temperatura a montante (' + str(tag_temperatura) + ') no período avaliado: ' + str(timestamp_inicio) + " - " + str(timestamp_fim))

    # preço do fluido USD por MMBTU
    if (not inference_metadata['fluido']['calculoHabilitado']) : # Totalização monetária desativada
        preco_fluido_usd_por_mmbtu = 0
    else :    
        preco_fluido_usd_por_mmbtu = _get_fluid_price(inference_metadata['fluido'])

    if (preco_fluido_usd_por_mmbtu == -1) : # preço snapshot no historiador
        preco_fluido_usd_por_mmbtu = get_snapshot_from_historian(client, inference_metadata["fluido"]['leituraFluido']['leituraValor']['tag'])
        preco_fluido_usd_por_mmbtu = 0 if (len(preco_fluido_usd_por_mmbtu) == 0) else preco_fluido_usd_por_mmbtu[0]['value']

    # Timestamp em segundos com GMT-3 para inserir na média.
    window_end = window_end - timedelta(hours=3)
    timestamp_media = int(window_end.timestamp())
    
    data = {'abertura' : abertura,
            'pressao_montante' : pressao_montante,
            'pressao_montante_unidade' : pressao_montante_unidade,
            'pressao_jusante' : pressao_jusante,
            'pressao_jusante_unidade' : pressao_jusante_unidade,
            'temperatura' : temperatura,
            'temperatura_unidade' : temperatura_unidade,
            'timestamp_media' : timestamp_media,
            'preco_fluido_usd_por_mmbtu' : preco_fluido_usd_por_mmbtu
    } 

    return data

def _is_property_constant(inference_metadata, property):
    if (inference_metadata[property]["tipoLeitura"] == "CONSTANTE"):
        return True

def _get_fluid_price(fluido) :
    if (fluido['leituraFluido']['tipoLeitura'] == "FATOR") : # Fator
        return fluido['leituraFluido']['fator'] * _get_fluid_price(fluido['leituraFluido']['fluido'])
    elif (fluido['leituraFluido']['tipoLeitura'] == "LEITURA_VALOR") :
        if (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "CONSTANTE") : # Constante
            return float(fluido['leituraFluido']['leituraValor']['valor'])
        elif (fluido['leituraFluido']['leituraValor']['tipoLeitura'] == "TAG_OPC") : # Tag historiada
            return -1
    else :
        return 0
