# Identificação do estado
class Estado():
    GAS = "Gas"
    VAPOR = "Vapor"
    LIQUIDO = "Liquido"

# Tipo de válvula de segurança
class TipoValvula():
    BALANCEADA = "Balanceada"
    CONVENCIONAL = "Convencional"
    PILOTO_OPERADA = "Piloto operada"

# Tipos de Válvula de Controle
class CaracteristicaVazao():
    LINEAR = "LINEAR"
    PORCENTAGEM = "PORCENTAGEM"
    PARABOLICA = "PARABOLICA"
    RAPIDA = "RAPIDA"
    BORBOLETA = "BORBOLETA"

# Guarda todas as variáveis para o cálculo de vazão
class ValvulaControle():
    def __init__(self, id_ativo: int, tag_ativo: str, tipo_valv: str,
                 estado: str, cvespec: float, fl: float,xt: float, abertura: float,
                 p_mon: float, p_jus: float, ro: float, p_vap: float, p_crit: float, 
                 cpcv: float, mw: float, t: float, z: float):
        self.id_ativo = id_ativo
        self.tag_ativo = tag_ativo
        self.tipo_valv = tipo_valv
        self.estado = estado
        self.cvespec = cvespec
        self.fl = fl
        self.xt = xt
        self.abertura = abertura
        self.p_mon = p_mon
        self.p_jus = p_jus
        self.ro = ro
        self.p_vap = p_vap
        self.p_crit = p_crit
        self.cpcv = cpcv
        self.mw = mw
        self.t = t
        self.z = z
