import math

from mgt.valvulacontrole.Modelo_ValvulaControle import *
from common.UnidadeBase import *
from common.ConversaoUnidades import *
from common.DataInterpolation import *
from common.VaporAgua import *

PRESSAO_EM_CONDICAO_NORMAL = 101325
R = 8314.46 # Constante universal dos gases
TOLERANCIA_ABERTURA = 0 # A partir de quanto é para considerar parcialmente aberta.

def calcular_vazoes_valvulacontrole(aberturas, pressoes_montante, pressoes_jusante, temperaturas, unidades_transmissores, estado_fluido, caracteristica_vazao, cv_especifico, xt, cpcv, peso_molecular, fator_compressibilidade, offset_posicao, preco_fluido_usd_por_mmbtu) :

    vazoes_massicas_instantaneas = []
    vazoes_volumetricas_instantaneas = []
    registros_vazao_massica = []
    registros_vazao_volumetrica = []

    for (abertura, p_montante, p_jusante, t) in zip(aberturas, pressoes_montante, pressoes_jusante, temperaturas) :

        if (cpcv == 0 or xt == 0 or fator_compressibilidade == 0 or peso_molecular == 0) : continue # Condições para evitar divisão por zero

        ## Conversão de unidades dos transmissores
        pressao_montante = p_montante['value']
        pressao_montante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_montante'])(pressao_montante)
        pressao_montante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_VALVULACONTROLE_BASE)(pressao_montante)
        if (pressao_montante <= 0) : continue # Caso a pressão a montante seja zero ou negativa.

        pressao_jusante = p_jusante['value']
        pressao_jusante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_jusante'])(pressao_jusante)
        pressao_jusante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_VALVULACONTROLE_BASE)(pressao_jusante)

        temperatura = t['value']
        temperatura = ConversaoUnidades.TEMPERATURA_PARA_KELVIN_DE.get(unidades_transmissores['temperatura'])(temperatura)
        temperatura = ConversaoUnidades.TEMPERATURA_DE_KELVIN_PARA.get(UNIDADE_TEMPERATURA_VALVULACONTROLE_BASE)(temperatura)
        # Caso a temperatura absoluta (K) seja menor ou igual a zero, ignora a amostra (erro de leitura do sensor)
        if (UNIDADE_TEMPERATURA_ELEMENTOPRIMARIOVAZAO_BASE == UnidadeEngenharia.KELVIN and temperatura <= 0) : continue 

        abertura_real = abertura['value'] - offset_posicao
        abertura_real = abertura_real if abertura_real >= TOLERANCIA_ABERTURA else 0

        vazao_instantanea = calcular_vazao_instantanea(estado_fluido, caracteristica_vazao, abertura_real, pressao_montante, pressao_jusante, temperatura, cv_especifico, xt, cpcv, peso_molecular, fator_compressibilidade)

        vazoes_massicas_instantaneas.append(vazao_instantanea['vazaoMassica'])
        registros_vazao_massica.append({'timestamp' : abertura['timestamp'], 'value' : vazao_instantanea['vazaoMassica']})
        
        vazoes_volumetricas_instantaneas.append(vazao_instantanea['vazaoVolumetrica'])
        registros_vazao_volumetrica.append({'timestamp' : abertura['timestamp'], 'value' : vazao_instantanea['vazaoVolumetrica']})

    vazao_massica_media = (sum(vazoes_massicas_instantaneas)/len(vazoes_massicas_instantaneas)) if (len(vazoes_massicas_instantaneas) > 0) else 0
    vazao_volumetrica_media = (sum(vazoes_volumetricas_instantaneas)/len(vazoes_volumetricas_instantaneas)) if (len(vazoes_volumetricas_instantaneas) > 0) else 0

    custo_por_hora = ConversaoUnidades.M3_PARA_MMBTU(vazao_volumetrica_media) * preco_fluido_usd_por_mmbtu

    return {'vazoes_massica': registros_vazao_massica, 'vazao_massica_media' : vazao_massica_media,
            'vazoes_volumetrica': registros_vazao_volumetrica, 'vazao_volumetrica_media' : vazao_volumetrica_media,
            'custo_por_hora' : custo_por_hora }

def calcular_vazao_instantanea(estado_fluido, caracteristica_vazao, abertura, p_montante, p_jusante, temperatura, cv_especifico, xt, cpcv, peso_molecular, fator_compressibilidade) :
    vazao_massica = 0
    vazao_volumetrica = 0

    if Estado.GAS.lower() == estado_fluido.lower() :
        vazao_massica = calcular_vazao_massica_gas(caracteristica_vazao, abertura, p_montante, p_jusante, temperatura, cv_especifico, xt, cpcv, peso_molecular, fator_compressibilidade)
        vazao_volumetrica = calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade, temperatura)
    elif Estado.VAPOR.lower() == estado_fluido.lower() :
        vazao_massica = calcular_vazao_massica_gas(caracteristica_vazao, abertura, p_montante, p_jusante, temperatura, cv_especifico, xt, CPCV_VAPOR, PESO_MOLECULAR_VAPOR, FATOR_COMPRESSIBILIDADE_VAPOR)
        vazao_volumetrica = calcular_vazao_volumetrica_gas(vazao_massica, PESO_MOLECULAR_VAPOR, FATOR_COMPRESSIBILIDADE_VAPOR, temperatura)

    return {'vazaoMassica' : vazao_massica, 'vazaoVolumetrica' : vazao_volumetrica}

def calcular_vazao_massica_gas(caracteristica_vazao, abertura, p_montante, p_jusante, temperatura, cv_especifico, xt, cpcv, peso_molecular, fator_compressibilidade) :
    diferenca_pressao = p_montante - p_jusante
    fator_expansao = diferenca_pressao / p_montante
    fk = cpcv / 1.4
    if (fator_expansao > fk * xt) :
        fator_expansao = fk * xt

    fator_y = 1 - fator_expansao / (3 * fk * xt) 
    cv = _cv_atual(caracteristica_vazao, abertura, cv_especifico)
    massa_especifica = (p_montante * peso_molecular) / (R * fator_compressibilidade * temperatura)

    w_massica = cv * (2.73 / (3600 * math.sqrt(1000))) * fator_y * math.sqrt(fator_expansao * p_montante * massa_especifica)    

    return w_massica

def calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade, temperatura) :
    rho = _calcular_rho(peso_molecular, PRESSAO_EM_CONDICAO_NORMAL, fator_compressibilidade, R, temperatura)
    return vazao_massica / rho

def _calcular_rho(peso_molecular, pressao, fator_compressibilidade, r, temperatura) :
    return (peso_molecular * pressao) / (fator_compressibilidade * r * temperatura)

calcular_r = {
    CaracteristicaVazao.LINEAR : lambda abertura : abertura,
    CaracteristicaVazao.PARABOLICA : lambda abertura : (-1.205 * math.pow(abertura, 4) + 1.4341 * math.pow(abertura, 3) + 0.6389 * math.pow(abertura, 2) + 0.1237 * abertura + 0.0086),
    CaracteristicaVazao.PORCENTAGEM : lambda abertura : (3.2304 * math.pow(abertura, 4) - 4.6571 * math.pow(abertura, 3) + 2.7465 * math.pow(abertura, 2) - 0.3441 * abertura + 0.0127),
    CaracteristicaVazao.RAPIDA : lambda abertura : (1.4141 * math.pow(abertura, 4) - 3.3271 * math.pow(abertura, 3) + 1.775 * math.pow(abertura, 2) + 1.1167 * abertura + 0.0158),
    CaracteristicaVazao.BORBOLETA : lambda abertura : (-13.16 * math.pow(abertura, 5) + 26.374 * math.pow(abertura, 4) - 16.681 * math.pow(abertura, 3) + 4.7319 * math.pow(abertura, 2) - 0.2673 * abertura + 0.0097) if (abertura < 0.9) else 1
}

def _cv_atual(caracteristica_vazao : CaracteristicaVazao, abertura, cv_especifico) :
    r = 0.0
    if (abertura > 0) :
        r = calcular_r.get(caracteristica_vazao)(abertura)
    
    return r * cv_especifico

def transform(parametros, id):
    aberturas = parametros['abertura']
    pressoes_montante = parametros['pressao_montante']
    pressoes_jusante = parametros['pressao_jusante']
    temperaturas = parametros['temperatura']

    tags_escrita = {'custoPorHora': parametros['custoPorHora'], 
                    'vazaoMassica': parametros['vazaoMassica'], 
                    'vazaoMassicaPorHora': parametros['vazaoMassicaPorHora'], 
                    'vazaoVolumetrica': parametros['vazaoVolumetrica'], 
                    'vazaoVolumetricaPorHora': parametros['vazaoVolumetricaPorHora']}

    reference_length = len(aberturas)
    
    if ( isinstance(pressoes_montante, list) ) :
        pressoes_montante = resize_records(pressoes_montante, reference_length, ['value', 'timestamp'])
    else :
        pressoes_montante = [{"value" : pressoes_montante}] * reference_length

    if ( isinstance(pressoes_jusante, list) ) :
        pressoes_jusante = resize_records(pressoes_jusante, reference_length, ['value', 'timestamp'])
    else :
        pressoes_jusante = [{"value" : pressoes_jusante}] * reference_length

    if ( isinstance(temperaturas, list) ) :
        temperaturas = resize_records(temperaturas, reference_length, ['value', 'timestamp'])
    else :
        temperaturas = [{"value" : temperaturas}] * reference_length

    unidades_transmissores = {
        'pressao_montante' : parametros['pressao_montante_unidade'],
        'pressao_jusante' : parametros['pressao_jusante_unidade'],
        'temperatura' : parametros['temperatura_unidade']
    }

    resultado = calcular_vazoes_valvulacontrole(aberturas=aberturas,
                                                pressoes_montante=pressoes_montante,
                                                pressoes_jusante=pressoes_jusante,
                                                temperaturas=temperaturas,
                                                unidades_transmissores=unidades_transmissores,
                                                estado_fluido=parametros['estado'],
                                                caracteristica_vazao=parametros['caracteristica_vazao'],
                                                cv_especifico=parametros['cv'],
                                                xt=parametros['xt'],
                                                cpcv=parametros['cpcv'],
                                                peso_molecular=parametros['mw'],
                                                fator_compressibilidade=parametros['z'],
                                                offset_posicao=parametros['offset_posicao'],
                                                preco_fluido_usd_por_mmbtu=parametros['preco_fluido_usd_por_mmbtu'])

    resultado['tags_escrita'] = tags_escrita
    resultado['timestamp_media'] = parametros['timestamp_media']

    return resultado

