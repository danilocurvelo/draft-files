# Identificação do estado
class Estado():
    GAS = "Gas"
    VAPOR = "Vapor"
    LIQUIDO = "Liquido"

# Tipo de válvula de segurança
class TipoValvula():
    BALANCEADA = "Balanceada"
    CONVENCIONAL = "Convencional"
    PILOTO_OPERADA = "Piloto operada"

# Guarda todas as variáveis para o cálculo de vazão
class PSV():
    def __init__(self, id_ativo: int, tag_ativo: str, estado: str, tipo: str, area: float, p_set: float, blowdown: float,
                 kd: float, kb: float, kc: float, kw: float, kn: float, p_mon: float, p_jus: float,
                 p_atm: float, ro: float, visc: float, cpcv: float, mw: float, t: float, z: float, coeficientesAPI: bool, p_vap: float, p_crit: float):
        """
        SI units
        Estado - estado do fluído (gasoso, líquido ou vapor)
        Tipo - tipo da válvula (balanceada, convencional ou piloto operada)
        Area - area do orificio da PSV (mm2)
        Pset - pressao de set da PSV
        Kd - coeficiente de descarga da PSV (adimensional)
        Kb - coeficiente de correcao de contrapressao (adimensional)
        Kw - coeficiente de correcao de contrapressao (adimensional)
        Kc - correcao de disco de ruptura (1.0 - sem correcao; 0.9 - com correcao)
        Kn - fator de correcao de Napier (adimensional)
        PMON - pressao a montante kPag	
        PJUS - pressao a montante kPag
        ro - massa especifica kg/m3
        Visc - viscosidade em cp
        T - temperatura a montante C
        Z - fator de compressibilidade
        MW - peso molecular kg-kmol
        cp/cv - razao entre calores especificos
        """
        self.id_ativo = id_ativo
        self.tag_ativo = tag_ativo
        self.estado = estado
        self.tipo = tipo
        self.area = area
        self.p_set = p_set
        self.blowdown = blowdown
        self.kc = kc
        self.kd = kd
        self.kb = kb
        self.kw = kw
        self.kn = kn
        self.p_mon = p_mon
        self.p_jus = p_jus
        self.p_atm = p_atm
        self.ro = ro
        self.visc = visc
        self.cpcv = cpcv
        self.mw = mw
        self.t = t
        self.z = z
        self.coeficientesAPI = coeficientesAPI
        self.p_vap = p_vap
        self.p_crit = p_crit
