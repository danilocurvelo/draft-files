import math

from mgt.psv.Modelo_PSV import *
from common.UnidadeBase import *
from common.ConversaoUnidades import *
from common.DataInterpolation import *
from common.VaporAgua import *
from airflow.models import Variable

K_DEFAULT_API = 1.0
RAZAO_PRESSAO_SATURADA = 50.0
PRESSAO_EM_CONDICAO_NORMAL = 101325
R = 8314.46 # Constante universal dos gases

class Posicao_PSV:
    ABERTO = 1.0
    FECHADO = 0.0

def calcular_vazoes_psv(estado_fluido, tipo_psv, area_do_orificio, pressoes_montante, pressoes_jusante, p_set, pressoes_atmosferica, temperaturas, unidades_transmissores, blowdown, fator_ajuste,
                        contrapressao_maxima, coeficientesAPI, kb, kd, kw, kc, cpcv, peso_molecular, fator_compressibilidade, id_ativo, preco_fluido_usd_por_mmbtu) :
    
    ## Conversão de unidades dos parâmetros constantes
    area_psv = area_do_orificio['constante']
    area_psv = ConversaoUnidades.AREA_PARA_MM2_DE.get(area_do_orificio['unidadeEngenharia'])(area_psv)
    area_psv = ConversaoUnidades.AREA_DE_MM2_PARA.get(UNIDADE_AREA_PSV_BASE)(area_psv)

    contrapressao_max = contrapressao_maxima['constante']
    contrapressao_max = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(contrapressao_maxima['unidadeEngenharia'])(contrapressao_max)
    contrapressao_max = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(contrapressao_max)

    pressao_set = p_set['constante']
    pressao_set = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(p_set['unidadeEngenharia'])(pressao_set)
    pressao_set = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(pressao_set)
    
    aberturas = inferidor_abertura(tipo_psv, pressoes_montante, pressoes_jusante, unidades_transmissores, pressao_set, blowdown, contrapressao_max, fator_ajuste, id_ativo)
    
    vazoes_massicas_instantaneas = []
    vazoes_volumetricas_instantaneas = []
    registros_vazao_massica = []
    registros_vazao_volumetrica = []

    for (abertura, p_montante, p_jusante, p_atmosferica, t) in zip(aberturas, pressoes_montante, pressoes_jusante, pressoes_atmosferica, temperaturas) :

        ## Conversão de unidades dos transmissores
        pressao_montante = p_montante['value']
        pressao_montante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_montante'])(pressao_montante)
        pressao_montante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(pressao_montante)

        pressao_jusante = p_jusante['value']
        pressao_jusante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_jusante'])(pressao_jusante)
        pressao_jusante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(pressao_jusante)

        pressao_atmosferica = p_atmosferica['value']
        pressao_atmosferica = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_atmosferica'])(pressao_atmosferica)
        pressao_atmosferica = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(pressao_atmosferica)

        temperatura = t['value']
        temperatura = ConversaoUnidades.TEMPERATURA_PARA_KELVIN_DE.get(unidades_transmissores['temperatura'])(temperatura)
        temperatura = ConversaoUnidades.TEMPERATURA_DE_KELVIN_PARA.get(UNIDADE_TEMPERATURA_PSV_BASE)(temperatura)

        ## Cálculo da vazão instantânea
        vazao_instantanea = calcular_vazao_instantanea(estado_fluido, tipo_psv, abertura, area_psv, pressao_montante, pressao_jusante, pressao_set,
                                                        pressao_atmosferica, temperatura, coeficientesAPI, kb, kd, kw, kc, cpcv, peso_molecular, fator_compressibilidade)
        
        vazoes_massicas_instantaneas.append(vazao_instantanea['vazaoMassica'])
        registros_vazao_massica.append({'timestamp' : p_montante['timestamp'], 'value' : vazao_instantanea['vazaoMassica']})
        
        vazoes_volumetricas_instantaneas.append(vazao_instantanea['vazaoVolumetrica'])
        registros_vazao_volumetrica.append({'timestamp' : p_montante['timestamp'], 'value' : vazao_instantanea['vazaoVolumetrica']})

    vazao_massica_media = (sum(vazoes_massicas_instantaneas)/len(vazoes_massicas_instantaneas)) if (len(vazoes_massicas_instantaneas) > 0) else 0
    vazao_volumetrica_media = (sum(vazoes_volumetricas_instantaneas)/len(vazoes_volumetricas_instantaneas)) if (len(vazoes_volumetricas_instantaneas) > 0) else 0

    custo_por_hora = ConversaoUnidades.M3_PARA_MMBTU(vazao_volumetrica_media) * preco_fluido_usd_por_mmbtu

    return {'vazoes_massica': registros_vazao_massica, 'vazao_massica_media' : vazao_massica_media,
            'vazoes_volumetrica': registros_vazao_volumetrica, 'vazao_volumetrica_media' : vazao_volumetrica_media,
            'custo_por_hora' : custo_por_hora }


def calcular_vazao_instantanea(estado_fluido, tipo_psv, abertura, area_do_orificio, p_montante, p_jusante, p_set, p_atmosferica, temperatura, 
                                coeficientesAPI, kb, kd, kw, kc, cpcv, peso_molecular, fator_compressibilidade) :

    if (coeficientesAPI is True):
        kb = calcular_kb_API(estado_fluido, tipo_psv, p_jusante, p_set)
        kd = calcular_kd_API(estado_fluido)
        kw = calcular_kw_API(estado_fluido, tipo_psv, p_jusante, p_set)

    vazao_massica = 0
    vazao_volumetrica = 0

    if Estado.GAS.lower() == estado_fluido.lower() :
        vazao_massica = calcular_vazao_massica_gas(tipo_psv, abertura, p_montante, p_jusante, p_atmosferica, temperatura, area_do_orificio, 
                                                    cpcv, kd, kb, kc, peso_molecular, fator_compressibilidade)
        vazao_volumetrica = calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade, temperatura)

    elif Estado.VAPOR.lower() == estado_fluido.lower() :
        vazao_massica = calcular_vazao_massica_vapor(estado_fluido, p_montante, temperatura, area_do_orificio, kb, kc, kd)
        vazao_volumetrica = calcular_vazao_volumetrica_vapor(vazao_massica, temperatura)

    return {'vazaoMassica' : vazao_massica, 'vazaoVolumetrica' : vazao_volumetrica}

def inferidor_abertura(tipo_psv, pressoes, contrapressoes, unidades_transmissores, pressao_set, blowdown, contrapressao_maxima, fator, id_ativo):

    aberturas = []
    posicao_anterior = Posicao_PSV.FECHADO

    try:
        posicao_anterior = Variable.get("ultima_posicao_psv_"+str(id_ativo))    
    except KeyError:
        pass

    if (TipoValvula.CONVENCIONAL.lower() == tipo_psv.lower()) : # PSV do tipo Convencional
        for (pressao, contrapressao) in zip(pressoes, contrapressoes) : 

            pressao_montante = pressao['value']
            pressao_montante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_montante'])(pressao_montante)
            pressao_montante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(pressao_montante)

            pressao_jusante = contrapressao['value']
            pressao_jusante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_jusante'])(pressao_jusante)
            pressao_jusante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(pressao_jusante)

            pressao_abertura = pressao_set - (fator * (contrapressao_maxima - pressao_jusante))
            pressao_reassentamento = pressao_abertura - (pressao_abertura * blowdown)
            if (pressao_montante > pressao_abertura) :
                aberturas.append(1.0)
                posicao_anterior = Posicao_PSV.ABERTO
            elif (pressao_montante <= pressao_abertura and pressao_montante > pressao_reassentamento) :
                aberturas.append(posicao_anterior)
            else :
                aberturas.append(0.0)
                posicao_anterior = Posicao_PSV.FECHADO

    else : # PSV's dos tipos Balanceada e Piloto Operada
        pressao_reassentamento = pressao_set - (pressao_set * blowdown)
        for pressao in pressoes : 

            pressao_montante = pressao['value']
            pressao_montante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_montante'])(pressao_montante)
            pressao_montante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UNIDADE_PRESSAO_PSV_BASE)(pressao_montante)

            if (pressao_montante > pressao_set) :
                aberturas.append(1.0)
                posicao_anterior = Posicao_PSV.ABERTO
            elif (pressao_montante <= pressao_set and pressao_montante > pressao_reassentamento) :
                aberturas.append(posicao_anterior)
            else :
                aberturas.append(0.0)
                posicao_anterior = Posicao_PSV.FECHADO
    
    Variable.set("ultima_posicao_psv_"+str(id_ativo), posicao_anterior)
    return aberturas

def calcular_vazao_massica_gas(tipo_psv, abertura, p_montante, p_jusante, p_atmosferica, temperatura, area_do_orificio, cpcv, kd, kb, kc, peso_molecular, fator_compressibilidade) :
    
    p_montante = p_montante + p_atmosferica
    p_jusante = p_jusante + p_atmosferica

    vazao_massica = 0

    if (TipoValvula.BALANCEADA.lower() == tipo_psv.lower()) : # PSV do tipo Balanceada
        vazao_massica = _calculo_entre_gases(area_do_orificio, cpcv, p_montante, temperatura, kd, kb, kc, peso_molecular, fator_compressibilidade)
    else : # PSV's dos tipos Convencional e Piloto Operada
        if (_verifica_fluxo_critico(p_montante, p_jusante, cpcv)) :
            vazao_massica = _fluxo_critico(area_do_orificio, cpcv, p_montante, temperatura, kd, kc, peso_molecular, fator_compressibilidade)
        else :
            fluxo = _coeficiente_fluxo_critico(p_montante, p_jusante, cpcv)
            vazao_massica = _fluxo_subcritico(area_do_orificio, p_montante, p_jusante, fluxo, temperatura, kd, kc, peso_molecular, fator_compressibilidade) 

    return vazao_massica * abertura

def calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade, temperatura) :
    rho = _calcular_rho(peso_molecular, PRESSAO_EM_CONDICAO_NORMAL, fator_compressibilidade, R, temperatura)
    return vazao_massica / rho

def calcular_vazao_massica_vapor(estado_fluido, p_montante, t_montante, area_do_orificio, kb, kc, kd) :
    ksh = calcular_ksh_API(estado_fluido, p_montante, t_montante)
    kn = calcular_kn_API(p_montante)
    vazao_massica = area_do_orificio * p_montante * kb * kc * kd * kn * ksh / 190.5

    return vazao_massica

def calcular_vazao_volumetrica_vapor(vazao_massica, temperatura) :
    rho = _calcular_rho(PESO_MOLECULAR_VAPOR, PRESSAO_EM_CONDICAO_NORMAL, FATOR_COMPRESSIBILIDADE_VAPOR, R, temperatura)
    return vazao_massica / rho

def _calcular_rho(peso_molecular, pressao, fator_compressibilidade, r, temperatura) :
    return (peso_molecular * pressao) / (fator_compressibilidade * r * temperatura)

def _verifica_fluxo_critico(p_montante, p_jusante, cpcv) :
    fluxo_critico = False
    pressao_fluxo_critico = p_montante * math.pow((2.0 / (cpcv + 1.0)), (cpcv / (cpcv - 1.0)))

    if p_jusante <= pressao_fluxo_critico:
        fluxo_critico = True

    return fluxo_critico

def _coeficiente_fluxo_critico(p_montante, p_jusante, cpcv) :
    f2 = 1.0
    razao_pressao = p_jusante / p_montante

    f2 = math.sqrt((cpcv / (cpcv - 1.0)) * math.pow(razao_pressao, 2.0 / cpcv) *
                   ((1.0 - math.pow(razao_pressao, (cpcv - 1) / cpcv)) / (1.0 - razao_pressao)))

    return f2

def _calculo_gases_ideais(cpcv) :
    return 0.03948 * math.sqrt(cpcv * math.pow(2.0 / (cpcv + 1.0), (cpcv + 1.0) / (cpcv - 1.0)))

def _calculo_entre_gases(area_do_orificio, cpcv, p_montante, temperatura, kd, kb, kc, peso_molecular, fator_compressibilidade) :
    gases_ideais = _calculo_gases_ideais(cpcv)
    return area_do_orificio * gases_ideais * kd * p_montante * kb * kc * math.sqrt(peso_molecular / (temperatura * fator_compressibilidade))

def _fluxo_critico(area_do_orificio, cpcv, p_montante, temperatura, kd, kc, peso_molecular, fator_compressibilidade) :
    gases_ideais = _calculo_gases_ideais(cpcv)
    return area_do_orificio * gases_ideais * kd * p_montante * kc * math.sqrt(peso_molecular / (temperatura * fator_compressibilidade))

def _fluxo_subcritico(area_do_orificio, p_montante, p_jusante, fluxo, temperatura, kd, kc, peso_molecular, fator_compressibilidade) :
     return (1.0 / 17.9) * area_do_orificio * fluxo * kd * kc * math.sqrt(peso_molecular * p_montante * (p_montante - p_jusante) / (temperatura * fator_compressibilidade))

### Cálculo de coeficientes (Kd, Kb, Kn, Kw, Ksh)

def calcular_kd_API(estado_fluido) :
    kd = 0.975
    if (Estado.LIQUIDO.lower() == estado_fluido.lower()) :
        kd = 0.65

    return kd

def calcular_kb_API(estado_fluido, tipo_psv, p_jusante, p_set) :
    kb = K_DEFAULT_API
    razao_pressao = RAZAO_PRESSAO_SATURADA

    if (Estado.LIQUIDO.lower() != estado_fluido.lower() and TipoValvula.BALANCEADA.lower() == tipo_psv.lower()) :
        if (p_jusante > 0.0) :
            razao_pressao = 100 * p_jusante / p_set
            if razao_pressao > RAZAO_PRESSAO_SATURADA:
                razao_pressao = RAZAO_PRESSAO_SATURADA

        if (razao_pressao < 30.0) :
            kb = K_DEFAULT_API
        else :
            kb = 1.48 - 0.016 * razao_pressao

    return kb

def calcular_kw_API(estado_fluido, tipo_psv, p_jusante, p_set) :
    kw = K_DEFAULT_API

    if (Estado.LIQUIDO.lower() == estado_fluido.lower() and TipoValvula.BALANCEADA.lower() == tipo_psv.lower()) : 
        razao_pressao = 100 * p_jusante / p_set
        kw = 0.67
        if (razao_pressao < 15.0) :
            kw = K_DEFAULT_API
        elif (15.0 <= razao_pressao < 20.0) :
            kw = 1.0 - 0.006 * (razao_pressao - 15.0)
        elif (20.0 <= razao_pressao <= 50.0) :
            kw = 0.97 - 0.01 * (razao_pressao - 20.0)

    return kw

def calcular_kn_API(p_montante) :
    if (p_montante <= 10339) :
        kn = 1.0
    elif (p_montante > 10339 and p_montante <= 22057) :
        kn = (0.02764 * p_montante - 1000.00) / (0.03324 * p_montante - 1061.00)
    else :
        kn = (0.02764 * 22057.00 - 1000.00) / (0.03324 * 22057.00 - 1061.00)
    
    return kn

def calcular_ksh_API(estado_fluido, p_montante, t_montante):
    t_lim = [-300, 149, 204, 260, 316, 371, 427, 482, 538, 593, 649]

    coef = [
        [2.57671126537800e-31, -1.03916858138469e-26, 1.30871639670795e-22,
        -5.54758167527658e-19, 1.00000000000000],
        
        [2.57671126537800e-31, -1.03916858138469e-26, 1.30871639670795e-22,
         -5.54758167527658e-19, 1.00000000000000],
          
        [-2.23422632336579e-18, 1.04612632459837e-13, -1.64146130313629e-09,
         9.76828840552288e-06, 0.983064756936870],
        
        [5.60046787544481e-19, 5.80139254028355e-15, -9.71440207325386e-10,
         1.62645691518112e-05, 0.925854770503131],
        
        [3.40127880904705e-18, -1.42960940403030e-13, 1.40436766164572e-09,
         7.85427629509709e-06, 0.879192607883118],
        
        [4.29034654700419e-18, -1.66608841789261e-13, 1.90191667038977e-09,
         1.58087824571703e-06, 0.841471247357850],
        
        [7.11642584872598e-19, -5.43555089614988e-14, 7.45304621224220e-10,
         2.22507976148712e-06, 0.805736885574551],
    
        [-9.75106154334029e-19, 1.29174325090792e-14, -1.10663313731102e-10, 
         3.80684424487258e-06, 0.771866578465241],
        
        [9.43976793595383e-19, -6.12259839623772e-14, 7.16812272138808e-10,
         2.59178248160509e-07, 0.746319669844413],
        
        [2.43918890188196e-18, -1.15163960610844e-13, 1.26469020608333e-09,
         -1.87731221003818e-06, 0.720403038605840],
        
        [2.17652180787147e-18, -1.06304779806496e-13, 1.23600083924433e-09,
         -3.29659698975386e-06, 0.701628789201060],]

    ksh_min = 0.0
    ksh_max = 0.0
    ksh = 0.7

    contr = True
    k = 1 

    if Estado.VAPOR.lower() == estado_fluido.lower():
        while (contr and k < 11):
            if t_montante <= t_lim[k]:
              for i in range(5):
                    ksh_min = coef[k - 1][4 - i] * math.pow(p_montante, i) + ksh_min
                    ksh_max = coef[k][4 - i] * math.pow(p_montante, i) + ksh_max

              m = (ksh_max - ksh_min) / (t_lim[k] - t_lim[k - 1])
              ksh = ksh_min + m * (t - t_lim[k - 1])
              contr = False
            k += 1
    return ksh

### Task Airflow

def transform(parametros, id):

    pressoes_montante = parametros['pressao_montante']
    pressoes_jusante = parametros['pressao_jusante']
    pressoes_atmosferica = parametros['pressao_atmosferica']
    temperaturas = parametros['temperatura']

    tags_escrita = {'custoPorHora': parametros['custoPorHora'], 
                    'vazaoMassica': parametros['vazaoMassica'], 
                    'vazaoMassicaPorHora': parametros['vazaoMassicaPorHora'], 
                    'vazaoVolumetrica': parametros['vazaoVolumetrica'], 
                    'vazaoVolumetricaPorHora': parametros['vazaoVolumetricaPorHora']}

    reference_length = len(pressoes_montante)
    
    if ( isinstance(pressoes_atmosferica, list) ) :
        pressoes_atmosferica = resize_records(pressoes_atmosferica, reference_length, ['value', 'timestamp'])
    else :
        pressoes_atmosferica = [{"value" : pressoes_atmosferica}] * reference_length

    if ( isinstance(pressoes_jusante, list) ) :
        pressoes_jusante = resize_records(pressoes_jusante, reference_length, ['value', 'timestamp'])
    else :
        pressoes_jusante = [{"value" : pressoes_jusante}] * reference_length

    if ( isinstance(temperaturas, list) ) :
        temperaturas = resize_records(temperaturas, reference_length, ['value', 'timestamp'])
    else :
        temperaturas = [{"value" : temperaturas}] * reference_length

    unidades_transmissores = {
        'pressao_atmosferica' : parametros['pressao_atmosferica_unidade'],
        'pressao_montante' : parametros['pressao_montante_unidade'],
        'pressao_jusante' : parametros['pressao_jusante_unidade'],
        'temperatura' : parametros['temperatura_unidade']
    }

    resultado = calcular_vazoes_psv(estado_fluido=parametros['estado'],
                                    tipo_psv=parametros['tipo_valv'],
                                    area_do_orificio=parametros['area'],
                                    pressoes_montante=pressoes_montante,
                                    pressoes_jusante=pressoes_jusante,
                                    p_set=parametros['setPsv'],
                                    pressoes_atmosferica=pressoes_atmosferica,
                                    temperaturas=temperaturas,
                                    unidades_transmissores=unidades_transmissores,
                                    blowdown=parametros['blowdown'],
                                    fator_ajuste=parametros['fator'],
                                    contrapressao_maxima=parametros['contrapressao_maxima'],
                                    coeficientesAPI=parametros['coeficientesAPI520'],
                                    kb=parametros['kb'],
                                    kd=parametros['kd'],
                                    kw=parametros['kw'],
                                    kc=parametros['kc'],
                                    cpcv=parametros['cpcv'],
                                    peso_molecular=parametros['mw'],
                                    fator_compressibilidade=parametros['z'],
                                    id_ativo=parametros['id_ativo'],
                                    preco_fluido_usd_por_mmbtu=parametros['preco_fluido_usd_por_mmbtu'])

    resultado['tags_escrita'] = tags_escrita
    resultado['timestamp_media'] = parametros['timestamp_media']

    return resultado

