from airflow.decorators import dag, task
from airflow.utils.dates import days_ago
from airflow.operators.python import task, get_current_context
from airflow.utils.db import provide_session
from airflow.models import XCom

from mgt.psv import Extract_PlantExpert_PSV
from mgt.psv import Extract_PlantHistorian_PSV
from mgt.psv import Transform_PSV
from mgt.psv import Load_PSV

default_args = {
    'owner': 'lii'
}

dag_name = 'mgt_psv_'+str(PLANT_EXPERT_INFERENCE_ID)
interval = str(MINUTO_ALVO_EXECUCAO)+" * * * *"

@dag(dag_name, default_args=default_args, schedule_interval=interval, start_date=days_ago(0), tags=['mgt', 'psv'], catchup=False)
def mgt_psv():
    """
    ### Fluxo para cálculo da inferência de vazão mássica do ativo 'PSV'
    """

    @task(multiple_outputs=True)
    def leitura_dados_plant(id):
        """
        #### Tarefa: Obtenção de dados do BR-PlantExpert e BR-Historian.
        """

        ativo = Extract_PlantExpert_PSV.extract_data_from_plantexpert(id)

        return ativo

    @task(multiple_outputs=True)
    def leitura_dados_historiador(ativo):
        """
        #### Tarefa: Obtenção de dados do BR-PlantExpert e BR-Historian.
        """

        dados = Extract_PlantHistorian_PSV.extract_data_from_planthistorian(ativo)

        return dados

    @task(multiple_outputs=True)
    def inferencia_vazao(dados, id):
        """
        #### Tarefa: Execução do algoritmo para inferência de vazão.
        """

        return Transform_PSV.transform(dados, id)


    @task()
    @provide_session
    def escrita_dados(resultado, session=None):
        """
        #### Tarefa: Escrita dos resultados no BR-Historin.
        """

        Load_PSV.persistir_dados_no_historian(resultado)

        # Removendo todos os XComs dessa DAG:
        context = get_current_context()
        dag = context["dag"]
        dag_id = dag._dag_id
        session.query(XCom).filter(XCom.dag_id == dag_id).delete()

    parameters = leitura_dados_plant(PLANT_EXPERT_INFERENCE_ID)
    data = leitura_dados_historiador(parameters)
    flow = inferencia_vazao(data, PLANT_EXPERT_INFERENCE_ID)
    escrita_dados(flow)

mgt  = mgt_psv()
