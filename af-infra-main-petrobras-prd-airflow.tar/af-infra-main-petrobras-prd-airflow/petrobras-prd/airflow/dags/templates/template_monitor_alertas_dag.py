from datetime import timedelta, datetime
import logging

from alertas.AlertRule import AlertRule, RuleOperator
from alertas.AlertMonitor import AlertMonitor
from alertas.processador_regras import processador
from alertas.plant_api import *

from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.exceptions import AirflowSkipException

default_args = {
    'owner': 'lii',
    'retries': int(Variable.get("ALERTAS_RETENTATIVAS")),
    'retry_delay': timedelta(minutes=int(Variable.get("ALERTAS_DELAY_RETENTATIVAS"))),
}

dag_id = 'alertas_'+str(ALERT_MONITOR_ID)
schedule_interval = str(MINUTO_ALVO_EXECUCAO)+" * * * *"

@dag(dag_id, default_args=default_args, schedule_interval=schedule_interval, start_date=datetime(2022, 1, 1, 0, 0), tags=['alertas'], catchup=False)
def dag_processador_alertas():
    """
    ### Fluxo para processamento de alertas de automação.
    """

    @task(multiple_outputs=True)
    def leitura_dados_plant(id):
        """
        #### Tarefa: Obtenção de dados e regras de alertas do BR-PlantExpert.
        """

        api_url = Variable.get("ALERTAS_API_URL")
        api_login = Variable.get("ALERTAS_API_LOGIN")
        api_passwd = Variable.get("ALERTAS_API_PASSWORD")
        api_org = Variable.get("ALERTAS_API_ORG")
        access_token = get_token(api_url, api_login, api_passwd, api_org)

        alert_monitor = get_alert_monitor(api_url, access_token, id)

        if not alert_monitor['enabled']:
            logging.warning(f">>> MONITORAMENTO DESABILITADO: {alert_monitor['asset']['tag']} - {alert_monitor['name']}")
            raise AirflowSkipException

        return alert_monitor


    @task(multiple_outputs=True)
    def processador_alertas_online(alert_monitor_parameters, id):
        """
        #### Tarefa: Execução do processamento online (última hora) das regras para geração de alertas. 
        """

        # Modelo AlertMonitor
        alert_monitor = create_alert_monitor(alert_monitor_parameters)

        # Timezone
        tz_utc_minus_3 = timedelta(hours=3)

        # Janela de tempo = 1h
        now = datetime.now() + tz_utc_minus_3 # Transformando em UTC

        # Início da janela com hora inteira (Ex: 16:03 => 16:00)
        window_end = now.replace(minute=0, second=0, microsecond=0)

        timestamp_fim = Timestamp()
        timestamp_fim.FromDatetime(window_end)
        timestamp_inicio = Timestamp()
        timestamp_inicio.FromDatetime(window_end - timedelta(hours=1))  

        return {'events' : processador(alert_monitor, timestamp_inicio, timestamp_fim), 'last_processed_timestamp' : window_end.isoformat(), 'initial_processed_timestamp' : (window_end - timedelta(hours=1)).isoformat()}

    @task(multiple_outputs=True)
    def processador_alertas(alert_monitor_parameters, id):
        """
        #### Tarefa: Execução do processamento das regras para geração de alertas. Esta rotina leva em consideração o starting_time e o lote de execução histórica máxima.
        """

        # Modelo AlertMonitor
        alert_monitor = create_alert_monitor(alert_monitor_parameters)

        max_processing_batch_in_hours = int(Variable.get("ALERTAS_MAX_PROCESSING_BATCH_IN_HOURS", default_var=12))
        starting_time = alert_monitor.start_processing

        # Timezone
        tz_utc_minus_3 = timedelta(hours=3)

        # Janela de tempo = 1h
        now = datetime.now() + tz_utc_minus_3 # Transformando em UTC

        # Início da janela com hora inteira (Ex: 16:03 => 16:00)
        window_end = now.replace(minute=0, second=0, microsecond=0)

        # Processamento histórico - timestamps em UTC
        batch_start = datetime.fromisoformat(Variable.get(f"ALERTAS_{str(id)}_ULTIMO_PROCESSAMENTO", default_var=starting_time[:-1])).replace(minute=0, second=0, microsecond=0)

        batch_end = batch_start + timedelta(hours=max_processing_batch_in_hours) 
        batch_end = window_end if (batch_end > window_end) else batch_end

        if (batch_start == batch_end): 
            logging.warning(f">>> Período atual ({batch_end.isoformat()}Z) já processado anteriormente.")
            raise AirflowSkipException

        timestamp_fim = Timestamp()
        timestamp_fim.FromDatetime(batch_end)
        timestamp_inicio = Timestamp()
        timestamp_inicio.FromDatetime(batch_start)  

        events, last_valid_sample_timestamp = processador(alert_monitor, timestamp_inicio, timestamp_fim)

        return {'events' : events, 'last_valid_sample_timestamp' : last_valid_sample_timestamp, 'last_processed_timestamp' : batch_end.isoformat(), 'initial_processed_timestamp' : batch_start.isoformat()}

    @task
    def escrita_alertas(eventos, id):
        """
        #### Tarefa: Escrita dos resultados no módulo de alertas do BR-PlantExpert.
        """

        inicio_processamento = eventos['initial_processed_timestamp']
        ultimo_processamento = eventos['last_processed_timestamp']
        last_valid_sample_timestamp = eventos['last_valid_sample_timestamp']
        eventos = eventos['events']

        logging.warning(f">>> Foram identificados {len(eventos)} eventos durante o período processado [{inicio_processamento}Z - {ultimo_processamento}Z].")

        api_url = Variable.get("ALERTAS_API_URL")
        api_login = Variable.get("ALERTAS_API_LOGIN")
        api_passwd = Variable.get("ALERTAS_API_PASSWORD")
        api_org = Variable.get("ALERTAS_API_ORG")
        access_token = get_token(api_url, api_login, api_passwd, api_org)

        write_enabled = Variable.get("ALERTAS_ESCRITA_ATIVA", default_var="True")
        logging.warning('Flag ALERTAS_ESCRITA_ATIVA == ' + str(write_enabled))
        for evento in eventos:
            if (write_enabled.lower() == "true"):
                post_alert_event(api_url, access_token, evento)
            logging.warning('[EVENTO DE ALERTA] ' + str(evento))

        Variable.set(f"ALERTAS_{str(id)}_ULTIMO_PROCESSAMENTO", ultimo_processamento)

        if not (last_valid_sample_timestamp is None):
            logging.warning(post_update_last_data_date(api_url, access_token, id, last_valid_sample_timestamp))
            logging.warning('[ÚLTIMO DADO VÁLIDO] ' + str(last_valid_sample_timestamp))

    alert_monitor = leitura_dados_plant(ALERT_MONITOR_ID)
    eventos = processador_alertas(alert_monitor, ALERT_MONITOR_ID)
    escrita_alertas(eventos, ALERT_MONITOR_ID)

alertas = dag_processador_alertas()

## AUXILIAR

def create_alert_monitor(parameters) -> AlertMonitor:

    ruleon = parameters['ruleOn']
    rule_on_model = AlertRule(id=ruleon['id'],
                              name=ruleon['name'],
                              operator=(None if ruleon['operator'] is None else getattr(RuleOperator, ruleon['operator'])),
                              value=ruleon['value'],
                              input_function=ruleon['inputFunction'],
                              parameters=ruleon['parameters'],
                              isAdvancedRule=ruleon.get('isAdvancedRule', False),
                              advancedRule=ruleon.get('advancedRule', '')
                              )
    ruleoff = parameters['ruleOff']
    rule_off_model = AlertRule(id=ruleoff['id'],
                              name=ruleoff['name'],
                              operator=(None if ruleoff['operator'] is None else getattr(RuleOperator, ruleoff['operator'])),
                              value=ruleoff['value'],
                              input_function=ruleoff['inputFunction'],
                              parameters=ruleoff['parameters'],
                              isAdvancedRule=ruleoff.get('isAdvancedRule', False),
                              advancedRule=ruleoff.get('advancedRule', '')
                              )

    return AlertMonitor(id=parameters['id'],
                        enabled=parameters['enabled'],
                        name=parameters['name'],
                        priority=parameters['priority'],
                        asset=parameters['asset'],
                        server=parameters['server'],
                        start_processing=parameters['startProcessing'],
                        rule_on=rule_on_model,
                        rule_off=rule_off_model,
                        manufacturer_fault_code=parameters['manufacturerFaultCode'],
                        additional_information=parameters['additionalInformation'],
                        )

##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################