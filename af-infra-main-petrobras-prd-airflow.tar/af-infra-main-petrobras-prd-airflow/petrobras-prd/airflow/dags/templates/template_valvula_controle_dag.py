from airflow.decorators import dag, task
from airflow.operators.python import get_current_context
from airflow.utils.db import provide_session
from airflow.models import XCom

from mgt.valvulacontrole import Extract_PlantHistorian_ValvulaControle
from mgt.valvulacontrole import Extract_PlantExpert_ValvulaControle
from mgt.valvulacontrole import Transform_ValvulaControle
from mgt.valvulacontrole import Load_ValvulaControle

from datetime import timedelta, datetime

default_args = {
    'owner': 'lii',
    'retries': RETENTATIVAS,
    'retry_delay': timedelta(minutes=DELAY_RETENTATIVAS),
    # 'email': [EMAIL],
    # 'email_on_failure': NOTIFICACAO_HABILITADA
}

dag_name = 'mgt_valvula_controle_'+str(PLANT_EXPERT_INFERENCE_ID)
interval = str(MINUTO_ALVO_EXECUCAO)+" * * * *"

@dag(dag_name, default_args=default_args, schedule_interval=interval, start_date=datetime(2022, 1, 1, 0, 0), tags=['mgt', 'valvula de controle'], catchup=False)
def mgt_valvula_controle():
    """
    ### Fluxo para cálculo da inferência de vazão mássica do ativo 'Válvula de Controle'
    """

    @task(multiple_outputs=True)
    def leitura_dados_plant(id):
        """
        #### Tarefa: Obtenção de dados do BR-PlantExpert e BR-Historian.
        """

        ativo = Extract_PlantExpert_ValvulaControle.extract_data_from_plantexpert(id)

        return ativo

    @task(multiple_outputs=True)
    def leitura_dados_historiador(ativo):
        """
        #### Tarefa: Obtenção de dados do BR-PlantExpert e BR-Historian.
        """

        dados = Extract_PlantHistorian_ValvulaControle.extract_data_from_planthistorian(ativo)

        context = get_current_context()
        configs = context['dag_run'].conf 

        if 'timestamp_alvo' in configs :
            ativo['timestamp_alvo'] = configs['timestamp_alvo']

        return dados

    @task(multiple_outputs=True)
    def inferencia_vazao(dados, id):
        """
        #### Tarefa: Execução do algoritmo para inferência de vazão.
        """

        return Transform_ValvulaControle.transform(dados, id)


    @task()
    @provide_session
    def escrita_dados(resultado, session=None):
        """
        #### Tarefa: Escrita dos resultados no BR-Historin.
        """

        Load_ValvulaControle.persistir_dados_no_historian(resultado)
        
        # Removendo todos os XComs dessa DAG:
        context = get_current_context()
        dag = context["dag"]
        dag_id = dag._dag_id
        session.query(XCom).filter(XCom.dag_id == dag_id).delete()

    
    parameters = leitura_dados_plant(PLANT_EXPERT_INFERENCE_ID)
    data = leitura_dados_historiador(parameters)
    flow = inferencia_vazao(data, PLANT_EXPERT_INFERENCE_ID)
    escrita_dados(flow)

mgt  = mgt_valvula_controle()

##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################