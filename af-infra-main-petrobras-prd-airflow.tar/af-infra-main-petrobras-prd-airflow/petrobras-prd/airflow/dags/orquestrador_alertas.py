AIRFLOW_DAG_FOLDER = "/opt/airflow/dags/"
ALERT_CONFIG_FILE = "config-alertas.yml"

import glob, os, yaml, random, logging
from shutil import copyfile
from datetime import datetime

from alertas.plant_api import *

from airflow.decorators import dag, task
from airflow.models import Variable

default_args = {
    'owner': 'lii'
}

@dag("Orquestrador_Alertas", default_args=default_args, schedule_interval="*/5 * * * *", start_date=datetime(2022, 1, 1, 0, 0), tags=['alertas', 'orquestrador'], catchup=False)
def orquestrador_alertas():
    """
    ### Orquestrador Alertas
    DAG principal para criação de novos DAGs dinamicamente de acordo com sua configuração no BR-PlantExpert.
    O padrão de criação do arquivo é `<ID>_<ATIVO>_alertas_dag.py`
    """

    @task()
    def inicializacao_configuracoes_airflow():
        """
        #### Tarefa: Ler os dados de configuração do arquivo de configuração.
        """

        return load_configuration_file()

    @task()
    def leitura_monitores_alertas(status):
        """
        #### Tarefa: Obtenção de todas os monitores de alerta cadastradas no BR-PlantExpert.
        """

        return extract_data_from_plant()

    @task()
    def criacao_novos_dags(alert_monitors):
        """
        #### Tarefa: Criação de novos dags dinamicamente.
        """
        create_new_inference_dags(alert_monitors)


    status = inicializacao_configuracoes_airflow()
    dados = leitura_monitores_alertas(status)
    criacao_novos_dags(dados)

alertas = orquestrador_alertas()

## AUXILIAR

def load_configuration_file() :
    with open(AIRFLOW_DAG_FOLDER + ALERT_CONFIG_FILE, "r") as yamlfile: 
        config_parameters = yaml.load(yamlfile, Loader=yaml.FullLoader)

    # Parâmetros das DAGs
    Variable.set("ALERTAS_JANELA_EXECUCAO_DAG", config_parameters['dags']['janela_execucao_dag_minutos'])
    Variable.set("ALERTAS_DELAY_EXECUCAO_DAG", config_parameters['dags']['delay_execucao_dag_minutos'])
    Variable.set("ALERTAS_RETENTATIVAS", config_parameters['dags']['retentativas_apos_erro'])
    Variable.set("ALERTAS_DELAY_RETENTATIVAS", config_parameters['dags']['delay_entre_retentativas_minutos'])
    Variable.set("ALERTAS_MAX_PROCESSING_BATCH_IN_HOURS", config_parameters['dags']['janela_processamento_retroativo_horas'])
    
    # Parâmetros da API Alertas
    Variable.set("ALERTAS_API_URL", config_parameters['api-alertas']['url'])
    Variable.set("ALERTAS_API_LOGIN", config_parameters['api-alertas']['login'])
    Variable.set("ALERTAS_API_PASSWORD", config_parameters['api-alertas']['password'])
    Variable.set("ALERTAS_API_ORG", config_parameters['api-alertas']['organization'])

    # Parâmetros do Collector Bridge gRPC
    Variable.set("ALERTAS_COLLECTOR_GRPC_HOST", config_parameters['collector-grpc']['host'])
    Variable.set("ALERTAS_COLLECTOR_GRPC_PORT", config_parameters['collector-grpc']['port'])

    return True

def extract_data_from_plant():
    api_url = Variable.get("ALERTAS_API_URL")
    api_login = Variable.get("ALERTAS_API_LOGIN")
    api_passwd = Variable.get("ALERTAS_API_PASSWORD")
    api_org = Variable.get("ALERTAS_API_ORG")
    access_token = get_token(api_url, api_login, api_passwd, api_org)
    return get_all_alert_monitors_ids(api_url, access_token)

def get_current_dags():
    files = [f for f in os.listdir(AIRFLOW_DAG_FOLDER) if os.path.isfile(os.path.join(AIRFLOW_DAG_FOLDER, f))]
    dag_ids = []
    for file in files :
        if (file.endswith("alertas_dag.py")):
            id = file.split('_')[0]
            dag_ids.append(id)
    return dag_ids

def create_new_inference_dags(alert_monitors):
    files = get_current_dags()
    dags = []
    for alert_monitor in alert_monitors:
        dags.append(str(alert_monitor['id']))
        if not str(alert_monitor['id']) in files :
            create_dag(alert_monitor["id"])
            files.append(str(alert_monitor["id"]))
    remove_deleted_dags(list(set(files) - set(dags)))
    logging.warning(f"Removendo as DAGs com ID: {list(set(files) - set(dags))}.")

def remove_deleted_dags(deleted_dags):
    for dag_id in deleted_dags :
        for file_to_delete in glob.glob(AIRFLOW_DAG_FOLDER + str(dag_id)+ "_*"):
            os.remove(file_to_delete)

def create_dag(id):
    src = AIRFLOW_DAG_FOLDER + "templates/template_monitor_alertas_dag.py"
    dst = AIRFLOW_DAG_FOLDER + str(id) + "_alertas_dag.py"
    if not os.path.exists(dst):
        copyfile(src, dst)
    
        # Delay entre as retentativas em minutos
        line_prepender(dst, "DELAY_RETENTATIVAS="+str(Variable.get("ALERTAS_DELAY_RETENTATIVAS")))
        # Quantidade de retentativas após erro
        line_prepender(dst, "RETENTATIVAS="+str(Variable.get("ALERTAS_RETENTATIVAS")))
        # Balanceamento de carga na janela.
        minuto_alvo = int(Variable.get("ALERTAS_DELAY_EXECUCAO_DAG"))
        if (int(Variable.get("ALERTAS_JANELA_EXECUCAO_DAG"))) > 0 :
            minuto_alvo += random.randrange(1, int(Variable.get("ALERTAS_JANELA_EXECUCAO_DAG"))+1)
        line_prepender(dst, "MINUTO_ALVO_EXECUCAO="+str(minuto_alvo))
        # ID da inferência cadastrada no BR-PlantExpert.
        line_prepender(dst, "ALERT_MONITOR_ID='"+str(id)+"'")
    logging.warning(f"Criada DAG com ID: {id}.")

def line_prepender(filename, line):
    with open(filename, 'r+') as f:
        content = f.read()
        f.seek(0, 0)
        f.write(line.rstrip('\r\n') + '\n' + content)