#!/bin/bash

# Incluir no arquivo /etc/crontab (todo dia as 23:50):
# 50 23 * * * airflow /home/airflow/dags/af-report-sys-stats.sh > /home/airflow/dags/af-report-sys-stats.${HOSTNAME}.log 2>/dev/null

# Coletar a média de uso das CPUs desde 00:00 (100 - %idle)
sar -u | grep 'Average' | awk '{print 100-$8}'

# Coletar a média de RAM disponível desde 00:00 (sar -r) e total de RAM (free) (kb)
# kbmemavail = kbmemfree ($2) + kbbuffers ($5) + kbcached ($6)
sar -r | grep 'Average' | awk '{print ($2+$5+$6)}'
free | grep 'Mem:' | awk '{print $2}'

# Utilização de disco (kb) onde a partição /home/airflow está montada
df /home/airflow | grep '/' | awk '{print $3}'
df /home/airflow | grep '/' | awk '{print $2}'

# Utilização de disco (kb) onde a partição /var está montada
df /var | grep '/' | awk '{print $3}'
df /var | grep '/' | awk '{print $2}'

# Timestamp de atualização do arquivo
# date '+%d-%m-%Y %H:%M:%S'
date '+%s'