import math, logging

from mgt.elementoprimariovazao.ParametrosElementoPrimarioVazao import TipoElementoPrimarioVazao, ConstantesElementoPrimarioVazao
from common.UnidadeCalculo import UnidadeCalculo
from common.EstadoFluido import EstadoFluido
from common.Material import *
from common.ConversaoUnidades import *
from common.DataInterpolation import *
from common import Constante
from common.CalculoAcumulado import *

from airflow.models import Variable

DEBUG_MODE = Variable.get("MGT_DEBUG", default_var=False)

LIMITE_CONVERGENCIA = 1e-4
MAXIMO_ITERACOES = 100

def calcular_vazoes_elementoprimariovazao(pressoes_montante, pressoes_jusante, pressoes_atmosferica, temperaturas, unidades_transmissores, estado_fluido, tipo_elemento, beta, material_tubulacao, material_elemento, diametro_interno, coef_isentropico, peso_molecular, fator_compressibilidade, viscosidade, preco_fluido_usd_por_mmbtu, estados_valvula_onoff) :

    vazoes_massicas_instantaneas = []
    vazoes_volumetricas_instantaneas = []
    registros_vazao_massica = []
    registros_vazao_volumetrica = []

    registros_validos = 0

    for (p_montante, p_jusante, p_atmosferica, t, estado_valvula_onoff) in zip(pressoes_montante, pressoes_jusante, pressoes_atmosferica, temperaturas, estados_valvula_onoff) :

        if (coef_isentropico == 0 or coef_isentropico == 1 or fator_compressibilidade == 0 or peso_molecular == 0 or viscosidade == 0) : continue # Condições para evitar divisão por zero
        
        ## Conversão de unidades dos transmissores
        pressao_atmosferica = p_atmosferica['value']
        pressao_atmosferica = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_atmosferica'])(pressao_atmosferica)
        pressao_atmosferica = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UnidadeCalculo.ElementoPrimarioVazao.PRESSAO)(pressao_atmosferica)
        if (pressao_atmosferica <= 0) : continue # Caso a pressão atmosférica seja zero ou negativa.

        pressao_montante = p_montante['value']
        pressao_montante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_montante'])(pressao_montante)
        pressao_montante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UnidadeCalculo.ElementoPrimarioVazao.PRESSAO)(pressao_montante)
        if (pressao_montante + pressao_atmosferica <= 0) : continue # Caso a pressão a montante absoluta seja zero ou negativa.

        pressao_jusante = p_jusante['value']
        pressao_jusante = ConversaoUnidades.PRESSAO_PARA_PA_DE.get(unidades_transmissores['pressao_jusante'])(pressao_jusante)
        pressao_jusante = ConversaoUnidades.PRESSAO_DE_PA_PARA.get(UnidadeCalculo.ElementoPrimarioVazao.PRESSAO)(pressao_jusante)
        if (pressao_jusante + pressao_atmosferica <= 0) : continue # Caso a pressão a jusante absoluta seja zero ou negativa.

        temperatura = t['value']
        temperatura = ConversaoUnidades.TEMPERATURA_PARA_KELVIN_DE.get(unidades_transmissores['temperatura'])(temperatura)
        temperatura = ConversaoUnidades.TEMPERATURA_DE_KELVIN_PARA.get(UnidadeCalculo.ElementoPrimarioVazao.TEMPERATURA)(temperatura)
        # Caso a temperatura absoluta (K) seja menor ou igual a zero, ignora a amostra (erro de leitura do sensor)
        if (UnidadeCalculo.ElementoPrimarioVazao.TEMPERATURA == UnidadeEngenharia.KELVIN and temperatura <= 0) : continue 

        pressao_montante_abs = pressao_montante + pressao_atmosferica

        ## Verificação se o fluxo é crítico, caso contrário não realiza inferência de vazão.
        escoamento_critico = (pressao_montante - pressao_jusante) >= diferencial_pressao_critico(coef_isentropico, pressao_montante_abs)

        if ((not estado_valvula_onoff) or (not escoamento_critico)) : # Caso on/off fechada ou fluxo sub-crítico, a vazão é zero, pula para a próxima iteração.
            vazoes_massicas_instantaneas.append(0.0)
            registros_vazao_massica.append({'timestamp' : p_montante['timestamp'], 'value' : 0.0})
            vazoes_volumetricas_instantaneas.append(0.0)
            registros_vazao_volumetrica.append({'timestamp' : p_montante['timestamp'], 'value' : 0.0})
            continue 

        ## Cálculo dos diâmetros do orifício, tubulação e beta na temperatura de operação, considerando a dilatação térmica
        diametro_orificio = diametro_interno * beta
        if (diametro_orificio == 0) : continue # Tubulação ou orifício com diâmetro zero
        diametro_tubulacao_t_operacao = calcular_dilatacao_termica_linear(diametro_interno, COEFICIENTES_DILATACAO[material_tubulacao](temperatura), temperatura)
        diametro_orificio_t_operacao = calcular_dilatacao_termica_linear(diametro_orificio, COEFICIENTES_DILATACAO[material_elemento](temperatura), temperatura)
        beta_t_operacao = diametro_orificio_t_operacao / diametro_tubulacao_t_operacao

        ## Cálculo das vazões instantâneas
        vazao_instantanea = None
        vazao_massica_instantanea_anterior = None # Comentar caso queria usar a vazão do instante anterior.
        vazao_massica_instantanea_anterior = calcular_vazao_instantanea(estado_fluido, tipo_elemento, beta_t_operacao, diametro_tubulacao_t_operacao, coef_isentropico, pressao_montante_abs, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_massica_instantanea_anterior)['vazaoMassica']
        for i in range(MAXIMO_ITERACOES) :
            vazao_instantanea = calcular_vazao_instantanea(estado_fluido, tipo_elemento, beta_t_operacao, diametro_tubulacao_t_operacao, coef_isentropico, pressao_montante_abs, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_massica_instantanea_anterior) 
            if (abs(vazao_instantanea['vazaoMassica'] - vazao_massica_instantanea_anterior) < LIMITE_CONVERGENCIA) :
                break # Convergência atingida.
            vazao_massica_instantanea_anterior = vazao_instantanea['vazaoMassica']

        # Conversão de vazão por segundo para vazão por hora
        vazao_instantanea['vazaoMassica'] = ConversaoUnidades.VAZAO_POR_SEGUNDO_PARA_VAZAO_POR_HORA(vazao_instantanea['vazaoMassica'])
        vazao_instantanea['vazaoVolumetrica'] = ConversaoUnidades.VAZAO_POR_SEGUNDO_PARA_VAZAO_POR_HORA(vazao_instantanea['vazaoVolumetrica'])
        
        vazoes_massicas_instantaneas.append(vazao_instantanea['vazaoMassica'])
        registros_vazao_massica.append({'timestamp' : p_montante['timestamp'], 'value' : vazao_instantanea['vazaoMassica']})
        
        vazoes_volumetricas_instantaneas.append(vazao_instantanea['vazaoVolumetrica'])
        registros_vazao_volumetrica.append({'timestamp' : p_montante['timestamp'], 'value' : vazao_instantanea['vazaoVolumetrica']})

        registros_validos = registros_validos + 1
        if (DEBUG_MODE):
            logging.warn(f"Timestamp: {p_montante['timestamp']} - Pm: {pressao_montante} - Pj: {pressao_jusante} - T: {temperatura} - W: {vazao_instantanea['vazaoMassica']} - Q: {vazao_instantanea['vazaoVolumetrica']}")

    # vazao_massica_media = (sum(vazoes_massicas_instantaneas)/len(vazoes_massicas_instantaneas)) if (len(vazoes_massicas_instantaneas) > 0) else 0
    # vazao_volumetrica_media = (sum(vazoes_volumetricas_instantaneas)/len(vazoes_volumetricas_instantaneas)) if (len(vazoes_volumetricas_instantaneas) > 0) else 0
    vazao_massica_media = calcular_massa_acumulada(registros_vazao_massica)
    vazao_volumetrica_media = calcular_volume_acumulado(registros_vazao_volumetrica)

    custo_por_hora = ConversaoUnidades.M3_PARA_MMBTU(vazao_volumetrica_media) * preco_fluido_usd_por_mmbtu
    custo_por_hora = custo_por_hora if custo_por_hora > 0 else 0

    logging.warn(f">>> Registros calculados: {registros_validos} - W_MEDIA: {vazao_massica_media} - Q_MEDIA: {vazao_volumetrica_media}")

    return {'vazoes_massica': registros_vazao_massica, 'vazao_massica_media' : vazao_massica_media,
            'vazoes_volumetrica': registros_vazao_volumetrica, 'vazao_volumetrica_media' : vazao_volumetrica_media,
            'custo_por_hora' : custo_por_hora }

def calcular_vazao_instantanea(estado_fluido, tipo_elemento, beta, diametro_interno, coef_isentropico, pressao_montante_abs, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_instantanea_anterior=None) :
    ''' Retorna vazão instantanea massica e volumetrica em kg/s e m3/s '''
    
    vazao_massica = calcular_vazao_massica_gas(tipo_elemento, beta, diametro_interno, coef_isentropico, pressao_montante_abs, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_instantanea_anterior)
    vazao_volumetrica = calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade)
    
    vazao_massica = vazao_massica if vazao_massica >= 0 else 0
    vazao_volumetrica = vazao_volumetrica if vazao_volumetrica >= 0 else 0

    return {'vazaoMassica' : vazao_massica, 'vazaoVolumetrica' : vazao_volumetrica}

def calcular_vazao_massica_gas(tipo_elemento, beta, diametro_interno, coef_isentropico, pressao_montante_abs, peso_molecular, fator_compressibilidade, viscosidade, temperatura, vazao_instantanea_anterior=None) :
    """
    Params:
    tipo_elemento -> Tipo do elemento primário
    beta -> Beta do orifício a temperatura de operação
    diametro_interno -> diâmetro interno da tubulação
    coef_isentropico -> Coeficiente isentrópico do gás
    pressao_montante -> Pressão a montante do orifício [Pa], em absoluto
    peso_molecular -> Peso molecular do gás [kg/kmol]
    fator_compressibilidade -> Fator de compressibilidade do gás
    viscosidade -> Viscosidade do fluido em cP
    temperatura -> Temperatura do gás a montante do orifício [K]
    w_0 -> Valor da anterior usado no cálculo de v1. Inicial = 0.5 (Número de Mach)
    vazao_instantanea_anterior -> Valor da vazão instantanea no instante anterior

    Retorna a vazão mássica, em [kg/s] calculada com os parâmetros
    """

    diametro_interno_em_m = diametro_interno / 1000

    c = coeficiente_de_descarga(tipo_elemento, vazao_instantanea_anterior, viscosidade, diametro_interno_em_m)

    p1_t = pressao_montante_abs # inicializa-se a pressão de estagnação (P1)t = P1

    if vazao_instantanea_anterior is not None: # Verificando se não é a primeira iteração...
        v1 = velocidade_do_gas_a_montante(vazao_instantanea_anterior, fator_compressibilidade, temperatura, diametro_interno_em_m, pressao_montante_abs, peso_molecular)
        vs = velocidade_do_som_no_gas_a_montante(coef_isentropico, temperatura, peso_molecular)
        m = numero_de_mach(v1, vs)
        p1_t = pressao_total_de_estagnacao_a_montante(pressao_montante_abs, m, coef_isentropico)

    y = coeficiente_de_escoamento_critico_isentropico(coef_isentropico) 
    
    return c * math.pow(beta, 2) * ((math.pi * math.pow(diametro_interno_em_m, 2)) / 4) * y * p1_t * math.sqrt(peso_molecular / (Constante.R * fator_compressibilidade * temperatura))

def calcular_vazao_volumetrica_gas(vazao_massica, peso_molecular, fator_compressibilidade) :
    rho = calcular_rho(peso_molecular, Constante.PRESSAO_EM_CONDICAO_NORMAL, 1.0, Constante.R, Constante.TEMPERATURA_EM_CONDICAO_NORMAL);
    return vazao_massica / rho

def calcular_rho(peso_molecular, pressao, fator_compressibilidade, r, temperatura) :
    """
    Determina a massa específica.
    """
    return (peso_molecular * pressao) / (fator_compressibilidade * r * temperatura)

def coeficiente_de_descarga_para_reynolds_infinito(tipo_elemento) :
    if (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_TOROIDAL) :
        return 0.9935
    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_CILINDRICA) :
        return 1.0
    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_ASME) :
        return 1.0
    else : # Placa de orifício de bordo reto
        return 0.83932

def coeficiente_de_descarga(tipo_elemento, vazao_anterior, viscosidade, diametro_interno) :
    c_inf = coeficiente_de_descarga_para_reynolds_infinito(tipo_elemento)

    if (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_TOROIDAL) :
        reynolds = calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno)
        return c_inf - 1.525 * math.pow(reynolds, -0.5)

    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_VENTURI_CILINDRICA) :
        reynolds = calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno)
        if (reynolds < (3.5e+5)) : # Re fora da faixa
            return 0.9887
        elif (reynolds < (2.5e+6)) :
            return 0.9887
        elif (reynolds <= (2.0e+7)) :
            return c_inf - 0.2165 * math.pow(reynolds, -0.2)
        else :
            return c_inf - 0.2165 * math.pow(reynolds, -0.2) # Re fora da faixa

    elif (tipo_elemento == TipoElementoPrimarioVazao.BOCAL_ASME) :
        reynolds = calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno)
        if (reynolds < (1.0e+4)) : # Re fora da faixa
            return c_inf - 7.21 * math.pow(reynolds, -0.5)
        elif (reynolds < (4.0e+5)) : 
            return c_inf - 7.21 * math.pow(reynolds, -0.5)
        elif (reynolds < (2.8e+6)) : 
            return 0.9886
        elif (reynolds <= (2.0e+7)) : 
            return c_inf - 0.222 * math.pow(reynolds, -0.2)
        else :
            return c_inf - 0.222 * math.pow(reynolds, -0.2) # Re fora da faixa
    
    else : # Placa de orifício de bordo reto
        return c_inf

def calcular_numero_reynolds(vazao_anterior, viscosidade, diametro_interno) :
    if (vazao_anterior is None) : return 1e100 # Reynolds infinito

    viscosidade_em_ns_m2 = ConversaoUnidades.CP_PARA_NS_M2(viscosidade)

    return (4 * vazao_anterior) / (math.pi * viscosidade_em_ns_m2 * diametro_interno)

def calcular_area_interna_tubulacao(diametro) :
    """
    Param: diametro -> diametro interno da tubulação

    Determina a área interna da tubulação.
    """
    return math.pi * (math.pow(diametro, 2.0) / 4.0)

def calcular_dilatacao_termica_linear(comprimento, coef_dilatacao, temperatura) :
    """
    Param: comprimento -> comprimento em 20C
    Param: coef_dilatacao -> coeficiente de dilatação térmica
    Param: temperatura -> temperatura de operação em K

    Determina dilatação térmica linear (20C para T de operação).
    """
    return comprimento * (1 + coef_dilatacao * (temperatura - 293.15))

def diferencial_pressao_critico(k, p1) :
    """
    Param: k -> coeficiente isentrópico do gás
    Param: p1 -> pressão a montante absoluta (p + patm)

    Identifica se o fluxo é crítico ou sub-crítico.
    """
    return p1 * (1 - math.pow((2 / (k + 1)), (k / (k - 1))))

def coeficiente_de_escoamento_critico_isentropico(k) :
    """
    Param: k -> coeficiente isentrópico do gás
    Param: z -> fator de compressilidade do gás

    Recebe k e retorna coeficiente de escoamento crítico isentrópico (Y).
    """
    return math.sqrt(k * math.pow( 2 / (k + 1), (k + 1) / (k - 1)))

def pressao_total_de_estagnacao_a_montante(p1, m, k):
    """
    Params: 
    k -> coeficiente isentrópico do gás
    p1 -> pressão a montante do orifício [Pa] em absoluto.
    m -> Número de Mach

    Retorna a pressão total de estagnação a montante do oríficio.
    """
    return p1 * math.pow(1 + ((k - 1) / 2) * math.pow(m, 2), k / (k - 1))

def numero_de_mach(v1, vs):
    """
    Params: 
    v1 -> velocidade do gás na linha a montante do orifício (m/s)
    vs -> velocidade do som no gás a montante do orifício (m/s)

    Retorna o cálculo do número de Mach.
    """
    return v1 / vs 

def velocidade_do_gas_a_montante(w, z, t, d, p1, pm):
    """
    Params:
    w -> vazão mássica (kg/s)
    z -> fator de compressibilidade do gás
    t -> temperatura do gás a montante do orifício (K)
    d -> diâmetro interno da tubulação (m)
    p1 -> pressão a montante do orifício [Pa] em absoluto
    pm -> peso molecular do gás (kg/kmol)

    Retorna a velocidade do gás na linha a montante do orifício [m/s].
    """
    #return (33257.2 * w * z * t) / (math.pi * math.pow(d, 2) * p1 * pm)
    return w / (calcular_area_interna_tubulacao(d) * calcular_rho(pm, p1, z, Constante.R, t))

def velocidade_do_som_no_gas_a_montante(k, t, pm):
    """
    Params:
    t -> temperatura do gás a montante do orifício (K)
    pm -> peso molecular do gás (kg/kmol)
    k -> coeficiente isentrópico do gás

    Retorna a velocidade do som no gás a montante do orifício [m/s].
    """
    return math.sqrt(Constante.R * (k * t) / pm)

def _avaliar_regra_comando_abertura_valvula_onoff(valvula_onoff) :
    estado_valvula_onoff = []
    operando_2 = valvula_onoff['regra']['valor_comparacao']

    for amostra in valvula_onoff['valor'] :
        operando_1 = amostra['value']
        operacao = {
            "MAIOR": operando_1 > operando_2,
            "MAIOR_IGUAL": operando_1 >= operando_2,
            "MENOR": operando_1 < operando_2,
            "MENOR_IGUAL": operando_1 <= operando_2,
            "IGUAL": operando_1 == operando_2
        }
        estado_valvula_onoff.append(operacao.get(valvula_onoff['regra']['operador'], True))

    return estado_valvula_onoff

### Task Airflow

def transform(parametros, id):

    logging.warn(">>> INFERÊNCIA DO ATIVO ELEMENTO PRIMÁRIO DE VAZÃO: {}".format(parametros['tag_ativo']))
    
    pressoes_montante = parametros['pressao_montante']
    pressoes_jusante = parametros['pressao_jusante']
    pressoes_atmosferica = parametros['pressao_atmosferica']
    temperaturas = parametros['temperatura']
    valvula_onoff = parametros['valvula_onoff']

    tags_escrita = {'custoPorHora': parametros['custoPorHora'], 
                    'vazaoMassica': parametros['vazaoMassica'], 
                    'vazaoMassicaPorHora': parametros['vazaoMassicaPorHora'], 
                    'vazaoVolumetrica': parametros['vazaoVolumetrica'], 
                    'vazaoVolumetricaPorHora': parametros['vazaoVolumetricaPorHora']}

    reference_length = 1

    if ( isinstance(pressoes_montante, list) ) :
        reference_length = len(pressoes_montante)
    else :
        pressoes_montante = [{"value" : pressoes_montante, "timestamp" : parametros['timestamp_media']}] 

    if ( isinstance(pressoes_jusante, list) ) :
        pressoes_jusante = resize_records(pressoes_jusante, reference_length, ['value', 'timestamp'])
    else :
        pressoes_jusante = [{"value" : pressoes_jusante}] * reference_length

    if ( isinstance(pressoes_atmosferica, list) ) :
        pressoes_atmosferica = resize_records(pressoes_atmosferica, reference_length, ['value', 'timestamp'])
    else :
        pressoes_atmosferica = [{"value" : pressoes_atmosferica}] * reference_length
    
    if ( isinstance(temperaturas, list) ) :
        temperaturas = resize_records(temperaturas, reference_length, ['value', 'timestamp'])
    else :
        temperaturas = [{"value" : temperaturas}] * reference_length

    unidades_transmissores = {
        'pressao_atmosferica' : parametros['pressao_atmosferica_unidade'],
        'pressao_montante' : parametros['pressao_montante_unidade'],
        'pressao_jusante' : parametros['pressao_jusante_unidade'],
        'temperatura' : parametros['temperatura_unidade']
    }

    estado_valvula_onoff = []
    if (valvula_onoff['habilitada']) :
        valvula_onoff['valor'] = resize_records(valvula_onoff['valor'], reference_length, ['value', 'timestamp'])
        estado_valvula_onoff = _avaliar_regra_comando_abertura_valvula_onoff(valvula_onoff)
    else :
        estado_valvula_onoff = [True] * reference_length # Caso não exista válvula on/off, assumir sempre aberta.

    resultado = calcular_vazoes_elementoprimariovazao(pressoes_montante=pressoes_montante, 
                                                      pressoes_jusante=pressoes_jusante,
                                                      pressoes_atmosferica=pressoes_atmosferica,
                                                      temperaturas=temperaturas, 
                                                      unidades_transmissores=unidades_transmissores,
                                                      estado_fluido=parametros['estado'], 
                                                      tipo_elemento=parametros['tipo'], 
                                                      beta=parametros['beta'], 
                                                      material_tubulacao=parametros['material_tubulacao'],
                                                      material_elemento=parametros['material_elemento'],
                                                      diametro_interno=parametros['diametro'], 
                                                      coef_isentropico=parametros['k'], 
                                                      peso_molecular=parametros['mw'], 
                                                      fator_compressibilidade=parametros['z'], 
                                                      viscosidade=parametros['viscosidade'], 
                                                      preco_fluido_usd_por_mmbtu=parametros['preco_fluido_usd_por_mmbtu'],
                                                      estados_valvula_onoff=estado_valvula_onoff
                                                      )

    resultado['tags_escrita'] = tags_escrita
    resultado['timestamp_media'] = parametros['timestamp_media']
    resultado['tag_ativo'] = parametros['tag_ativo']

    return resultado