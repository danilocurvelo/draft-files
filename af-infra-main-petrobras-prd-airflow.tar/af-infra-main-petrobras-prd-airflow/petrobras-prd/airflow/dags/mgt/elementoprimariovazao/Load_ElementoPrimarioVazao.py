from google.protobuf.timestamp_pb2 import Timestamp
from common.historian_grpc_client.generated.api_pb2 import Metadata, ListMetadata, TagRegex, Record, Data, ListData
from common.historian_api import HistorianGrpcClient, HistorianError
from airflow.models import Variable
import logging

def persistir_dados_no_historian(dados) :

    media_massica_hora = dados['vazao_massica_media']
    vazoes_massica_instantaneas = dados['vazoes_massica']
    media_volumetrica_hora = dados['vazao_volumetrica_media']
    vazoes_volumetrica_instantaneas = dados['vazoes_volumetrica']
    custo_por_hora = dados['custo_por_hora']
    tags_escrita = dados['tags_escrita']

    tag_vazao_massica = tags_escrita['vazaoMassica']
    tag_vazao_massica_por_hora = tags_escrita['vazaoMassicaPorHora']
    tag_vazao_volumetrica = tags_escrita['vazaoVolumetrica']
    tag_vazao_volumetrica_por_hora = tags_escrita['vazaoVolumetricaPorHora']
    tag_custo_por_hora = tags_escrita['custoPorHora']

    logging.warn(">>> INFERÊNCIA DO ATIVO ELEMENTO PRIMÁRIO DE VAZÃO: {}".format(dados['tag_ativo']))
    logging.warn("\n[PONTOS GERADOS PARA {}] \n    Custo por hora: {} \n    Vazão mássica instantânea: {} \n    Vazão mássica por hora: {} \n    Vazão volumétrica instantânea: {} \n    Vazão volumétrica por hora: {}".format(dados['tag_ativo'], 1, len(vazoes_massica_instantaneas), 1, len(vazoes_volumetrica_instantaneas), 1))
    if len(vazoes_massica_instantaneas) == 0 : raise ValueError('Sem amostras de vazão válidas no período calculado.')

    quality_enum = getattr(Record, 'Quality')   
    valores_massica = []
    valores_volumetrica = []
    timestamp = Timestamp() 
    for vazao_massica, vazao_volumetrica in zip(vazoes_massica_instantaneas, vazoes_volumetrica_instantaneas) :
        timestamp.FromSeconds(vazao_massica['timestamp'])
        record_massica = Record(value=str(vazao_massica['value']), timestamp=timestamp, quality=getattr(quality_enum, 'GOOD'))
        record_volumetrica = Record(value=str(vazao_volumetrica['value']), timestamp=timestamp, quality=getattr(quality_enum, 'GOOD'))
        valores_massica.append(record_massica)
        valores_volumetrica.append(record_volumetrica)

    timestamp.FromSeconds(dados['timestamp_media'])
    media_massica_hora_record = [ Record(value=str(media_massica_hora), timestamp=timestamp, quality=getattr(quality_enum, 'GOOD')) ]
    media_volumetrica_hora_record = [ Record(value=str(media_volumetrica_hora), timestamp=timestamp, quality=getattr(quality_enum, 'GOOD')) ]
    custo_por_hora_record = [ Record(value=str(custo_por_hora), timestamp=timestamp, quality=getattr(quality_enum, 'GOOD')) ]

    write_enabled = Variable.get("MGT_ESCRITA_ATIVA", default_var="True")
    logging.warning('>>> Flag MGT_ESCRITA_ATIVA == ' + str(write_enabled))
    if (write_enabled.lower() == "true"):

        cliente = HistorianGrpcClient(Variable.get("PLANTHISTORIAN_HOST"), Variable.get("PLANTHISTORIAN_PORT"))

        # Criação/verificação das tags no historiador
        criar_tags(cliente, tag_vazao_massica, tag_vazao_volumetrica, tag_vazao_massica_por_hora, tag_vazao_volumetrica_por_hora, tag_custo_por_hora)

        # Vazão mássica instantânea
        salvar_dados_na_tag(cliente, tag_vazao_massica, valores_massica)

        # Vazão volumétrica instantânea
        salvar_dados_na_tag(cliente, tag_vazao_volumetrica, valores_volumetrica)

        # Vazão mássica média por hora
        salvar_dados_na_tag(cliente, tag_vazao_massica_por_hora, media_massica_hora_record)

        # Vazão volumétrica média por hora
        salvar_dados_na_tag(cliente, tag_vazao_volumetrica_por_hora, media_volumetrica_hora_record)

        # Custo por hora
        salvar_dados_na_tag(cliente, tag_custo_por_hora, custo_por_hora_record)

        logging.warn(f"Registros escritos no Historian: {len(valores_massica)}")

    else :
        logging.warn(f"Escrita no Historian desabilitada. Registros calculados: {len(valores_massica)}")

def verificar_tag(cliente, tag) :
    type_enum = getattr(Metadata, 'Type')
    tag_type_enum = getattr(Metadata, 'TagType')

    if not (cliente.find_tags(TagRegex(valor=tag)).listMetadata) : # Tag não existe no historiador
        nova_tag = Metadata(
            identifier=tag,
            name=tag,
            area='ELEMENTO_PRIMARIO_VAZAO',
            infinite_period_value=True,
            type=getattr(type_enum, 'DOUBLE64'),
            tagType=getattr(tag_type_enum, 'CONTINUOUS'),
            mode=1,
            historize_value=True
        )
        requisicao = ListMetadata()
        requisicao.listMetadata.extend([nova_tag])
        
        cliente.save_tags(requisicao)

def salvar_dados_na_tag(cliente, tag, valores):
    # tag_type_enum = getattr(Metadata, 'TagType')
    type_enum = getattr(Metadata, 'Type')

    tag_e_dados = Data(
        metadata=Metadata(
            name=tag,
            type=getattr(type_enum, 'DOUBLE64')
        )
    )

    tag_e_dados.records.extend(valores)

    requisicao = ListData()
    requisicao.listData.extend([tag_e_dados])

    try:
        cliente.save(requisicao)
    except HistorianError as e:
        logging.error("Um problema ocorreu ao salvar novos registros no historiador: " + tag)
        raise

def criar_tags(cliente, *tags):

    erro_criacao = None

    for tag in tags :
        try:
            verificar_tag(cliente, tag)
        except HistorianError as e:
            logging.error("Um problema ocorreu ao criar uma nova tag no historiador: " + tag)
            erro_criacao = e

    if erro_criacao : raise erro_criacao
            