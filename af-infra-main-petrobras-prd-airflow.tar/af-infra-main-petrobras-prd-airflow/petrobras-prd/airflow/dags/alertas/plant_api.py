import requests

from google.protobuf.timestamp_pb2 import Timestamp
from datetime import datetime, timedelta

ENDPOINTS = {
    "login" : "/login",
    "alert-monitor" : "/alert-monitor",
    "all-alert-monitors-ids" : "/alert-monitor/ids",
    "create-event" : "/event",
    "update-date" : "/alert-monitor/update-last-data-date"
}

OPTIONS = "?page=0&size=9999&sort=id,asc"

def get_token(url, login, password, organization):
    payload = {"login": login, "password": password, "organizationId": organization}
    response = requests.post(url + ENDPOINTS['login'], json=payload, verify = False)
    return response.text

def get_all_alert_monitors(url, access_token):
    my_headers = {'Authorization' : f'Bearer {access_token}', 'Content-Type': 'application/json'}
    response = requests.get(url + ENDPOINTS['alert-monitor'] + OPTIONS, headers=my_headers, verify = False)
    return response.json()['content']

def get_alert_monitor(url, access_token, id):
    my_headers = {'Authorization' : f'Bearer {access_token}', 'Content-Type': 'application/json'}
    response = requests.get(url + ENDPOINTS['alert-monitor'] + f'/{id}', headers=my_headers, verify = False)
    return response.json()

# def get_all_alert_monitors_ids(url, access_token):
#     my_headers = {'Authorization' : f'Bearer {access_token}', 'Content-Type': 'application/json'}
#     response = requests.get(url + ENDPOINTS['all-alert-monitors-ids'] + OPTIONS, headers=my_headers, verify = False)
#     return response.json()['content']

def get_all_alert_monitors_ids(url, access_token):
    alert_monitors = []
    my_headers = {'Authorization' : f'Bearer {access_token}', 'Content-Type': 'application/json'}
    response = requests.get(url + ENDPOINTS['all-alert-monitors-ids'] + OPTIONS, headers=my_headers, verify = False)
    alert_monitors.extend(response.json()['content'])
    totalPages = response.json().get('totalPages', 1)
    for page in range(1, totalPages):
        response = requests.get(url + ENDPOINTS['all-alert-monitors-ids'] + f"?page={page}&size=9999&sort=id,asc", headers=my_headers, verify = False)
        alert_monitors.extend(response.json()['content'])

    return alert_monitors

def post_alert_event(url, access_token, event):
    my_headers = {'Authorization' : f'Bearer {access_token}', 'Content-Type': 'application/json'}
    response = requests.post(url + ENDPOINTS['create-event'], json=event, headers=my_headers, verify = False)
    return response.status_code, response.text

def post_update_last_data_date(url, access_token, id, date):
    my_headers = {'Authorization' : f'Bearer {access_token}', 'Content-Type': 'application/json'}
    response = requests.post(url + ENDPOINTS['update-date'], json={"id" : str(id), "lastDate" : str(date)}, headers=my_headers, verify = False)
    return response.status_code, response.text