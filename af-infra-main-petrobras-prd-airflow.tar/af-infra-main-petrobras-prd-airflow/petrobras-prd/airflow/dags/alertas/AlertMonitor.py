from alertas.AlertRule import AlertRule

class AlertMonitor :
    def __init__(self, id: str, enabled: bool, name: str, asset, priority, server, start_processing: str, rule_on: AlertRule, rule_off: AlertRule, manufacturer_fault_code, additional_information):
        self.id = id
        self.enabled = enabled
        self.name = name
        self.asset = asset
        self.priority = priority
        self.server = server
        self.start_processing = start_processing
        self.rule_on = rule_on
        self.rule_off = rule_off
        self.manufacturer_fault_code = manufacturer_fault_code
        self.additional_information = additional_information