from alertas.AlertMonitor import AlertMonitor
from alertas.AlertRule import AlertRule, InputFunction, RuleOperator
from common.collector_historian_pb2 import RequestCollector, Connection, RequestTagSearch
from common.CollectorHistorianClient import CollectorHistorianClient, CollectorError
from alertas.plant_api import *

import logging, re

from airflow.models import Variable

class State:
    OFF = "OFF"
    ON = "ON"

def processador(alert_monitor: AlertMonitor, timestamp_inicio, timestamp_fim) -> list:

    events = []

    collector_client, collector_conn = connect_to_collector(*get_server_info(alert_monitor.server))

    tag_on = None
    tag_off = None

    if (alert_monitor.rule_on.isAdvancedRule):
        tags_on = get_tags_from_advanced_rule(alert_monitor.rule_on.advancedRule)
        if (check_if_single_tag(tags_on)):
            tag_on = tags_on[0]
    else : 
        tag_on = alert_monitor.rule_on.parameters['tag']

    if (alert_monitor.rule_off.isAdvancedRule):
        tags_off = get_tags_from_advanced_rule(alert_monitor.rule_off.advancedRule)
        if (check_if_single_tag(tags_off)):
            tag_off = tags_off[0]
    else :
        tag_off = alert_monitor.rule_off.parameters['tag']

    if (tag_on is None or tag_off is None):
        logging.error("Múltiplas tags identificadas em uma regra avançada. Opção não suportada.")
        raise Exception("Múltiplas tags identificadas em uma regra avançada. Opção não suportada.")
        
    values_rule_on = get_data_from_collector(collector_client, collector_conn, tag_on, timestamp_inicio, timestamp_fim)
    values_rule_off = get_data_from_collector(collector_client, collector_conn, tag_off, timestamp_inicio, timestamp_fim)

    collector_client.disconnect(collector_conn)
    collector_client.shutdown()

    current_state = Variable.get(f"ALERTAS_{str(alert_monitor.id)}_ULTIMO_ESTADO", default_var=State.OFF)

    last_valid_sample_timestamp = None

    DEBUG_MODE = Variable.get("ALERTAS_DEBUG", default_var=False)

    logging.warning(f"Ativo: {alert_monitor.asset} | Alerta: {alert_monitor.name}")

    for value_on, value_off in zip(values_rule_on, values_rule_off) :
        status = False
        timestamp = 100
        
        if (current_state == State.OFF):
            if (is_valid_sample(value_on.value)):
                # processa regra de ON
                status = avalia_regra(alert_monitor.rule_on, value_on.value)
                timestamp = value_on.instant.seconds
                current_state = State.ON if status else current_state
                last_valid_sample_timestamp = timestamp
                if (DEBUG_MODE):
                    log_results("REGRA DE ON", value_on.value, alert_monitor.rule_on, status) 
            else:
                logging.warning(f"Valor não numérico: {value_on.value}")

        elif (current_state == State.ON):
            if (is_valid_sample(value_off.value)):
                # processa regra de OFF
                status = avalia_regra(alert_monitor.rule_off, value_off.value)
                timestamp = value_off.instant.seconds
                current_state = State.OFF if status else current_state
                last_valid_sample_timestamp = timestamp
                if (DEBUG_MODE):
                    log_results("REGRA DE OFF", value_off.value, alert_monitor.rule_off, status) 
            else:
                logging.warning(f"Valor não numérico: {value_off.value}")

        if (status): # novo evento
            events.append({"alertMonitorId": alert_monitor.id, "timestamp": datetime.fromtimestamp(timestamp/1000).isoformat()+'-03:00', "newState": current_state})

    Variable.set(f"ALERTAS_{str(alert_monitor.id)}_ULTIMO_ESTADO", current_state)
    if not (last_valid_sample_timestamp is None):
        last_valid_sample_timestamp = datetime.fromtimestamp(last_valid_sample_timestamp/1000).isoformat()+'-03:00'
    return events, last_valid_sample_timestamp

def get_tags_from_advanced_rule(advanced_rule: str):
    tags = re.findall(r"\".*?\"", advanced_rule)
    tags = map(lambda x: x.replace("\"", ""), tags)
    return list(tags)

def check_if_single_tag(tag_list):
    return len(set(tag_list)) == 1

def format_advanced_rule(advanced_rule: str, tag, value):
    tag = "\"" + tag + "\""
    return advanced_rule.replace(tag, str(value))

def bitCheck(value, bit):
    return (int(float(value)) & (1 << int(float(bit)))) >> int(float(bit))

def valueNumber(value):
    return value

def is_valid_sample(value) -> bool:
    return str(value).isdigit()

def avalia_regra(rule: AlertRule, value) -> bool:
    if (rule.isAdvancedRule):
        return eval(format_advanced_rule(rule.advancedRule, get_tags_from_advanced_rule(rule.advancedRule)[0], value))
    else:
        left_hand_side = input_function.get(rule.input_function)(rule.parameters, value)
        right_hand_side = rule.value
        return eval(str(left_hand_side) + rule.operator + str(right_hand_side))

input_function = {
    InputFunction.BITCHECK : lambda parameters, value: bool(int(float(value)) & (1 << int(float(parameters['bit'])))),
    InputFunction.VAL : lambda parameters, value: value
}

def connect_to_collector(host, port, group, id):
    try :
        collector_grpc_host = Variable.get("ALERTAS_COLLECTOR_GRPC_HOST")
        collector_grpc_port = Variable.get("ALERTAS_COLLECTOR_GRPC_PORT")
        client = CollectorHistorianClient(collector_grpc_host, collector_grpc_port)
        request = RequestCollector(host=host,
                                port=port,
                                group=group,
                                id=id)
        conn = client.connect(request)
        return client, conn
    except CollectorError as e:
        logging.error('Falha ao se conectar ao Collector Bridge.\n' + str(e.original))

def get_data_from_collector(client: CollectorHistorianClient, conn: Connection, tag: str, timestamp_inicio, timestamp_fim):
    dados = client.read_historical_value(RequestTagSearch(conn=conn, 
                                tag=tag,
                                startInstant=timestamp_inicio,
                                endInstant=timestamp_fim,
                                numPoints=3600))
    return dados.values

def get_server_info(server):
    return server["host"], server["port"], server["group"], server["brCollectorId"]

def log_results(prefix, value, rule, status):
    if (rule.isAdvancedRule):
        logging.warning(f"{prefix}) Valor lido: {value} | Regra avançada: {rule.advancedRule} | Resultado: {status}")
    else:
        logging.warning(f"{prefix}) Valor lido: {value} | Regra básica: [{rule.input_function}, {rule.parameters}] {rule.operator} {rule.value} | Resultado: {status}")
    