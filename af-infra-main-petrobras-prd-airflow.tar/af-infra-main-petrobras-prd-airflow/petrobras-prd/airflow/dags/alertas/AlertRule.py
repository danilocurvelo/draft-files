class RuleOperator:
    EQUAL = "=="
    NOT_EQUAL = "!="
    LESS_THAN = "<"
    LESS_THAN_OR_EQUAL = "<="
    GREATER_THAN = ">"
    GREATER_THAN_OR_EQUAL = ">="

class InputFunction:
    VAL = "VAL"
    BITCHECK = "BITCHECK"

class AlertRule:
    def __init__(self, id: str, name: str, operator: RuleOperator, value: str, input_function, parameters, isAdvancedRule: bool, advancedRule: str):
        self.id = id
        self.name = name
        self.operator = operator
        self.value = value
        self.input_function = input_function
        self.parameters = parameters
        self.isAdvancedRule = isAdvancedRule
        self.advancedRule = advancedRule
