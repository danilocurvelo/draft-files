#!/bin/bash

find /home/airflow/logs -type d -mtime +30 -exec rm -rf {} \; > /dev/null 2>&1