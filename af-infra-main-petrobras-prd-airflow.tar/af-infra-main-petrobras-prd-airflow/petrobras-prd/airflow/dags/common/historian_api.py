import struct

import grpc

from common.historian_grpc_client.generated.api_pb2 import DataRequest, ListData, Status, ListMetadata, TagRegex
from common.historian_grpc_client.generated.api_pb2_grpc import APIHistorianServerStub

TAMANHO_MAXIMO_MENSAGEM = 2 ** (struct.Struct('i').size * 8 - 1) - 1
DURACAO_TIMEOUT = 20


class HistorianError(Exception):
    original: grpc.RpcError = None

    def __init__(self, original: grpc.RpcError, *args: object) -> None:
        self.original = original
        super().__init__(*args)


class HistorianGrpcClient(object):
    channel: grpc.Channel = None
    stub: APIHistorianServerStub = None
    timeout: int = DURACAO_TIMEOUT

    def __init__(self, host: str, porta: int, timeout_em_segundos: int = DURACAO_TIMEOUT) -> None:
        self.channel = grpc.insecure_channel('{}:{}'.format(host, porta), options=[
            ('grpc.max_send_message_length', TAMANHO_MAXIMO_MENSAGEM),
            ('grpc.max_receive_message_length', TAMANHO_MAXIMO_MENSAGEM),
        ])
        self.stub = APIHistorianServerStub(self.channel)
        self.timeout = timeout_em_segundos

    def ack(self) -> bool:
        try:
            return self.stub.ack(Status(status=True)).status
        except grpc.RpcError as e:
            raise HistorianError(e)

    def find(self, request: DataRequest) -> ListData:
        try:
            return self.stub.find(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise HistorianError(e)

    def find_snapshot(self, metadata: ListMetadata) -> ListData:
        try:
            return self.stub.findSnapshot(metadata, timeout=self.timeout)
        except grpc.RpcError as e:
            raise HistorianError(e)

    def find_tags(self, regex: TagRegex) -> ListMetadata:
        try:
            return self.stub.findTags(regex, timeout=self.timeout)
        except grpc.RpcError as e:
            raise HistorianError(e)

    def save(self, data: ListData) -> Status:
        try:
            return self.stub.save(data, timeout=self.timeout)
        except grpc.RpcError as e:
            raise HistorianError(e)

    def save_tags(self, data: ListMetadata) -> Status:
        try:
            return self.stub.saveTags(data, timeout=self.timeout)
        except grpc.RpcError as e:
            raise HistorianError(e)

    def shutdown(self):
        self.channel.close()
