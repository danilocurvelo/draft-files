# Definição de valores constantes utilizados pelo módulo MGT

R = 8314.46261815324 # Constante universal dos gases m3.Pa.K^−1.kmol^-1

PRESSAO_EM_CONDICAO_NORMAL = 101325
TEMPERATURA_EM_CONDICAO_NORMAL = 293.15 # 20C

PRESSAO_ATMOSFERICA = 101325

# Valores default do vapor de água.
class VaporAgua :
    PESO_MOLECULAR_VAPOR_DAGUA = 18.016
    FATOR_COMPRESSIBILIDADE_VAPOR_DAGUA = 1
    CPCV_VAPOR_DAGUA = 1.33
    VISCOSIDADE_VAPOR_DAGUA = 0.01