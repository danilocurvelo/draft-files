from common.collector_historian_pb2_grpc import CollectorHistorianStub
from common.collector_historian_pb2 import *
import grpc
import struct

TAMANHO_MAXIMO_MENSAGEM = 2 ** (struct.Struct('i').size * 8 - 1) - 1
DURACAO_TIMEOUT = 20

class CollectorError(Exception):
    original: grpc.RpcError = None

    def __init__(self, original: grpc.RpcError, *args: object) -> None:
        self.original = original
        super().__init__(*args)

class CollectorHistorianClient(object):
    channel: grpc.Channel = None
    stub: CollectorHistorianStub = None
    timeout: int = DURACAO_TIMEOUT
    
    def __init__(self, host: str, porta: int, timeout_em_segundos: int = DURACAO_TIMEOUT) -> None:
        self.channel = grpc.insecure_channel(f"{host}:{porta}", options=[
            ('grpc.max_send_message_length', TAMANHO_MAXIMO_MENSAGEM),
            ('grpc.max_receive_message_length', TAMANHO_MAXIMO_MENSAGEM)
        ])
        self.stub = CollectorHistorianStub(self.channel)
        self.timeout = timeout_em_segundos
    
    def connect(self, request: RequestCollector) -> Connection:
        try:
            return self.stub.connect(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
    
    def disconnect(self, request: Connection) -> Bool:
        try:
            return self.stub.disconnect(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
        
    def search_tags(self, request: RequestMask) -> Tags:
        try:
            return self.stub.searchTags(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)

    def search_tags_by_description(self, request: RequestMask) -> Tags:
        try:
            return self.stub.searchTagsByDescription(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)

    def get_tag_infos(self, request: RequestTag) -> TagInfo:
        try:
            return self.stub.getTagInfos(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
        
    def read_current_value(self, request: RequestTag) -> SingleValue:
        try:
            return self.stub.readCurrentValue(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
    
    def read_current_values(self, request: RequestTags) -> SingleValues:
        try:
            return self.stub.readCurrentValues(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
    
    def read_historical_value(self, request: RequestTagSearch) -> Value:
        try:
            return self.stub.readHistoricalValue(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
        
    def read_historical_values(self, request: RequestTagsSearch) -> Values:
        try:
            return self.stub.readHistoricalValues(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
    
    def read_historical_interpolated_value(self, request: RequestTagSearch) -> Value:
        try:
            return self.stub.readHistoricalInterpolatedValue(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
    
    def read_historical_interpolated_values(self, request: RequestTagsSearch) -> Values:
        try:
            return self.stub.readHistoricalInterpolatedValues(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)
        
    def write_value(self, request: RequestTagValue) -> Bool:
        try:
            return self.stub.writeValue(request, timeout=self.timeout)
        except grpc.RpcError as e:
            raise CollectorError(e)

    def shutdown(self):
        self.channel.close()