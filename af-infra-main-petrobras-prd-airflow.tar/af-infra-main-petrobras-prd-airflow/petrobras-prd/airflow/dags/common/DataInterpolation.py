import numpy as np
# import scipy.interpolate as interp

def resize_records(records, new_length, fields) :
    if (new_length == 0) : return []
    #if (new_length == 1) : return [records[0]]
    if (len(records) == 0) : 
        tmp = {}
        for field in fields :
            tmp[field] = [1] * new_length
            tmp[field] = [1] * new_length
        return convert_lists_to_records(tmp)

    values = []
    timestamps = []
    lists = {}
    for field in fields :
        lists[field] = []

    for record in records : 
        for field in fields :
            lists[field].append(record[field])

    arrays = {}
    results = {}
    for field in fields :

        lists[field] = lists[field] if (len(lists[field]) > 1) else lists[field]*2
        arrays[field] = np.array(lists[field])

        # numpy - preferência
        results[field] = np.interp(np.linspace(0,arrays[field].size-1, new_length), np.arange(arrays[field].size), arrays[field])

        # legacy scipy
        # interpolation = interp.interp1d(np.arange(arrays[field].size), arrays[field])
        # results[field] = (interpolation(np.linspace(0,arrays[field].size-1, new_length))).tolist()
    
    return convert_lists_to_records(results)

def convert_lists_to_records(lists):
    records = []
    for (value, timestamp) in zip(lists['value'], lists['timestamp']):
        records.append({'value' : value, 'timestamp' : int(timestamp)})

    return records

# print(resize_records([{'value': 1, 'timestamp': 1}, {'value': 1, 'timestamp': 1}, {'value': 10, 'timestamp': 1}, {'value': 10, 'timestamp': 1}], 5, ['value', 'timestamp']))
# print(resize_records([{'value': 1, 'timestamp': 1}], 1, ['value', 'timestamp']))
# print(resize_records([{'value': 1, 'timestamp': 1}], 2, ['value', 'timestamp']))