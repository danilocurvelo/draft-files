class EstadoFluido():
    GAS = "Gas"
    VAPOR_DAGUA = "Vapor"
    LIQUIDO = "Liquido"