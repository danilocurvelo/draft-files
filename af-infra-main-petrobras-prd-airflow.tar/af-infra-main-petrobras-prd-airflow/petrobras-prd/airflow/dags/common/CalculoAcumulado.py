from datetime import datetime
from common.PlantHistorian import *

def calcular_volume_acumulado(registros_vazao):
    return _calcular_acumulado(registros_vazao)


def calcular_massa_acumulada(registros_vazao):
    return _calcular_acumulado(registros_vazao)

def _calcular_acumulado(registros_vazao):
    '''
    Calcula a integral da vazão (em /HORA) usando o timestamp (em segundos).
    '''
    acumulado_por_hora = 0
    last_sample_instant = 0
    for registro in registros_vazao:
        seconds_since_last_hour = (_seconds_since_last_hour(registro["timestamp"]) / 3600)
        if (seconds_since_last_hour - last_sample_instant) < 0 : continue
        acumulado_por_hora = acumulado_por_hora + registro["value"] * (seconds_since_last_hour - last_sample_instant)
        last_sample_instant = seconds_since_last_hour
    return acumulado_por_hora

def _seconds_since_last_hour(timestamp):
    instant = datetime.fromtimestamp(timestamp)
    last_hour = instant.replace(minute=0, second=0, microsecond=0)
    return (instant - last_hour).seconds


# teste = [{'timestamp' : 0, 'value' : 0 },
#         {'timestamp' : 600, 'value' : 0 },
#         {'timestamp' : 660, 'value' : 0 },
#         {'timestamp' : 720, 'value' : 0 },
#         {'timestamp' : 780, 'value' : 0 },
#         {'timestamp' : 840, 'value' : 0 },
#         {'timestamp' : 900, 'value' : 39.2 },
#         {'timestamp' : 1200, 'value' : 39.2 },
#         {'timestamp' : 1800, 'value' : 38.1 },
#         {'timestamp' : 2400, 'value' : 38.9 },
#         {'timestamp' : 3000, 'value' : 38.1 },
#         {'timestamp' : 3600, 'value' : 39.3 },
#         ]

# print(_calcular_acumulado_teste(teste))
