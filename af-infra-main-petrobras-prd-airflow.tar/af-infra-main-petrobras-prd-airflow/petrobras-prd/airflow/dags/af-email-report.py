"""
### DAG de envio de relatório diário de execução do Airflow.
#### v0.0.3 - 07-05-2024

Variáveis a definir no ambiente do Airflow:

- `REPORT__CLUSTER_MAIN_NODE`: IP do nó principal (main/master) do cluster Airflow a ser monitorado. Formato: 10.10.10.1
- `REPORT__CLUSTER_WORKER_NODES`: Lista de IPs dos nós secundários/workers do cluster Airflow a ser monitorado. Formato: ["10.10.10.2", "10.10.10.3"].
- `REPORT__CLUSTER_API_AUTH`: Senha para autenticação do usuário `airflow` na API do Airflow. Valor padrão: `"airflow"`.

- `REPORT__THRESHOLD_CPU`: Limite percentual de uso de CPU para considerar o nó como saudável [0-1]. Valor padrão: 0.8.
- `REPORT__THRESHOLD_MEMORY`: Limite percentual de uso de memória para considerar o nó como saudável [0-1]. Valor padrão: 0.8.
- `REPORT__THRESHOLD_DISK`: Limite percentual de uso de disco para considerar o nó como saudável [0-1]. Valor padrão: 0.8.
- `REPORT__THRESHOLD_ERRORS`: Limite percentual de erros na execução de DAGs para considerar o nó como saudável [0-1]. Valor padrão: 0.05.

- `REPORT__EMAIL_RECIPIENTS`: Lista de e-mails para receber o relatório. Separar por vírgula. 
- `REPORT__EMAIL_SENDER`: Email remetente dos relatórios. Valor padrão: `naoresponda@petrobras.com.br`.
- `REPORT__EMAIL_SMTP_SERVER`: Endereço do servidor SMTP. Valor padrão: `smtp.petrobras.com.br`.
- `REPORT__EMAIL_SMTP_PORT`: Porta do servidor SMTP. Valor padrão: 25.
- `REPORT__EMAIL_SMTP_SSL`: Se `True`, usa SSL para conexão com o servidor SMTP. Valor padrão: `False`.
- `REPORT__EMAIL_SENDER_PSWD`: Senha do e-mail remetente. Obrigatório caso `REPORT__EMAIL_SMTP_SSL` seja `True`.
- `REPORT__EMAIL_SCHEDULE_INTERVAL`: Periodicidade (em dias) do envio de e-mails de report. Valor padrão: 1.
- `REPORT__EMAIL_WHEN_WARNING`: Se `True`, obrigatoriamente envia e-mail quando algum nó estiver com algum problema naquele dia (ex: threshold atingido), independente de REPORT__EMAIL_SCHEDULE_INTERVAL. Valor padrão: `True`.

- `REPORT__HISTORIAN_MONITORED_TAGS`: Lista de tags a serem monitoradas no formato de lista. Valor padrão: `[]`
- `REPORT__HISTORIAN_GRPC_HOST`: Host do servidor gRPC do Historian.
- `REPORT__HISTORIAN_GRPC_PORT`: Porta do servidor gRPC do Historian.
"""

from datetime import datetime, timedelta
from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.exceptions import AirflowSkipException
import requests, logging, glob
import smtplib, ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

MAIN_NODE_HOST = Variable.get("REPORT__CLUSTER_MAIN_NODE", default_var="") 
WORKER_NODES_HOSTS = Variable.get("REPORT__CLUSTER_WORKER_NODES", deserialize_json=True, default_var=[]) 
API_AUTH = ("airflow", Variable.get("REPORT__CLUSTER_API_AUTH", default_var="airflow"))
API_URL = f"http://{MAIN_NODE_HOST}:8080/api/v1"
FLOWER_API_URL = f"http://{MAIN_NODE_HOST}:5555/api"

THRESHOLD_CPU = float(Variable.get("REPORT__THRESHOLD_CPU", default_var=0.8))
THRESHOLD_MEMORY = float(Variable.get("REPORT__THRESHOLD_MEMORY", default_var=0.8))
THRESHOLD_DISK = float(Variable.get("REPORT__THRESHOLD_DISK", default_var=0.8))
THRESHOLD_ERRORS = float(Variable.get("REPORT__THRESHOLD_ERRORS", default_var=0.05))

EMAIL_SCHEDULE_INTERVAL = int(Variable.get("REPORT__EMAIL_SCHEDULE_INTERVAL", default_var=1))
EMAIL_WHEN_WARNING = Variable.get("REPORT__EMAIL_WHEN_WARNING", default_var=True)

SMTP_SERVER = Variable.get("REPORT__EMAIL_SMTP_SERVER", default_var="smtp.petrobras.com.br") 
SMTP_PORT = int(Variable.get("REPORT__EMAIL_SMTP_PORT", default_var=25))
SMTP_SSL = Variable.get("REPORT__EMAIL_SMTP_SSL", default_var="False")

EMAIL_RECIPIENTS = Variable.get("REPORT__EMAIL_RECIPIENTS", default_var="") 
EMAIL_SENDER = Variable.get("REPORT__EMAIL_SENDER", default_var="naoresponda@petrobras.com.br") 
EMAIL_SENDER_PSWD = Variable.get("REPORT__EMAIL_SENDER_PSWD", default_var="")
EMAIL_SUBJECT = "[airflow] Relatório diário de execução"

HEALTHY_MSG = "<strong style='color: green'>⬤</strong>"
UNHEALTHY_MSG = "<strong style='color: red'>⬤</strong>"
API_UNAVAILABLE_MSG = "API indisponível. Verifique o status do Airflow Webserver."

default_args = {
  'owner': 'lii',
  'start_date': datetime(2023, 1, 1, 0, 0),
  'retries': 3,
  'retry_delay': timedelta(minutes=5),
}

@dag(
    dag_id="airflow-email-report",
    schedule_interval="55 23 * * *",
    default_args=default_args,
    catchup=False,
    tags=["report"],
)
def airflow_email_report():
    
    @task()
    def connect_to_airflow_api():
      """Inicializa a rotina de criação de relatório do Airflow."""
      if not MAIN_NODE_HOST:
        raise AirflowSkipException("Nó principal não configurado.")
      

      return True
     
    @task() 
    def check_scheduler_health(status):
      """Verifica o status de saúde do scheduler do Airflow."""

      endpoint_url = f"{API_URL}/health"
      response = requests.get(endpoint_url, auth=API_AUTH)

      if response.status_code == 200:
        if response.json()["metadatabase"]["status"] == "healthy" and response.json()["scheduler"]["status"] == "healthy":
          return True
        else:
          return False
      else:
        return API_UNAVAILABLE_MSG
      
    @task() 
    def check_workers_health(status):
      """Verifica o status de saúde dos workers do Airflow."""

      endpoint_url = f"{FLOWER_API_URL}/workers?status=true"
      response = requests.get(endpoint_url)

      if response.status_code == 200:
        return list(response.json().values()) # {"celery@airflow-cluster-2.novalocal": true, "celery@airflow-cluster-3.novalocal": true}
      else:
        return API_UNAVAILABLE_MSG
    
    @task() 
    def check_dagbag_size(status):
      """Verifica a quantidade de DAGs carregadas no Airflow."""

      endpoint_url = f"{API_URL}/dags?limit=1"
      response = requests.get(endpoint_url, auth=API_AUTH)

      if response.status_code == 200:
        return response.json()['total_entries']
      else:
        return API_UNAVAILABLE_MSG
    
    @task() 
    def check_dagrun_errors(status):
      """Verifica a existência de execuções de DAGs que resultaram em erro na janela definida."""

      current_date = datetime.today().strftime('%Y-%m-%d')
      endpoint_url = f"{API_URL}/dags/~/dagRuns?state=failed&execution_date_gte={current_date}&limit=1"
      response = requests.get(endpoint_url, auth=API_AUTH)

      if response.status_code == 200:
        return response.json()['total_entries']
      else:
        return API_UNAVAILABLE_MSG
      
    @task() 
    def check_dagrun_executions(status):
      """Verifica a existência de execuções de DAGs que resultaram em erro na janela definida."""

      current_date = datetime.today().strftime('%Y-%m-%d')
      endpoint_url = f"{API_URL}/dags/~/dagRuns?execution_date_gte={current_date}&limit=1"
      response = requests.get(endpoint_url, auth=API_AUTH)

      if response.status_code == 200:
        return response.json()['total_entries']
      else:
        return API_UNAVAILABLE_MSG
      
    @task() 
    def check_import_errors(status):
      """Verifica a existência de erros de importação nos arquivos das DAGs."""

      endpoint_url = f"{API_URL}/importErrors"
      response = requests.get(endpoint_url, auth=API_AUTH)

      if response.status_code == 200:
        return response.json()['total_entries']
      else:
        return API_UNAVAILABLE_MSG
    
    @task(multiple_outputs=True)
    def check_cluster_load(status):
      """Verifica as estatísticas de uso de recursos das máquinas do cluster do Airflow. """
      cluster_stats = {}
      for filename in glob.glob("./dags/af-report-sys-stats.*.log"):
        node_hostname = filename.split(".")[2]
        cluster_stats[node_hostname] = []
        with open(filename, 'r', encoding="utf-8") as f:
          for line in f:
            cluster_stats[node_hostname].append(float(line.replace("\n", "")))

      return cluster_stats
    
    @task() 
    def check_collector_variables(status):
      """Verifica a atividade de variáveis de coleta no Historiador."""
      return "to be implemented."
    
    @task()
    def format_report(scheduler_health, workers_health, dagbag_size, dagrun_errors, dagrun_executions, import_errors, cluster_load, collector_variables):

      report_date = datetime.today().strftime('%d/%m/%Y')

      dagrun_error_percentage = (dagrun_errors / dagrun_executions) * 100 if dagrun_executions > 0 else 0

      nodes_info = ""
      nodes_ips = [MAIN_NODE_HOST]
      nodes_ips.extend(WORKER_NODES_HOSTS)
      nodes_health = [scheduler_health]
      nodes_health.extend(workers_health)
      logging.warning(f"nodes_ips: {nodes_ips}, nodes_health: {nodes_health}")
      nodes_hosts = list(cluster_load.keys())
      nodes_hosts.sort()
      for node_idx, node in enumerate(nodes_hosts):
        nodes_info += print_node_info(node_idx, node, nodes_ips[node_idx], nodes_health[node_idx], cluster_load[node], True if node_idx == 0 else False)

      cluster_status_html_msg = f'''\
      <html>
        <head></head>
        <body>
          <h2>Relatório Apache Airflow - {report_date}</h2>
          <h3>Status do cluster ({len(nodes_ips)} nós):</h3>
          <ol>
            {nodes_info}
          </ol>
          <h3>Status das DAGs:</h3>
          <ul>
            <li>Quantidade de DAGs: {dagbag_size}</li>
            <li>Quantidade de execuções de DAGs no período: {dagrun_executions}</li>
            <li>Quantidade de execuções de DAGs com erro no período: {dagrun_errors}</li>
            <li {"style='color: red'" if (dagrun_error_percentage >= THRESHOLD_ERRORS*100) else ""}>Percentual de execuções de DAGs com erro no período: {dagrun_error_percentage:.2f}%</li>
            <li>Erros de importação de arquivos de DAG: {import_errors}</li>
          </ul>
        </body>
      </html>
      '''

      logging.warning(cluster_status_html_msg.strip().replace('\n', ''))

      days_since_last_email_report = int(Variable.get('REPORT__DAYS_SINCE_LAST_EMAIL_REPORT', default_var=0))
      if (EMAIL_WHEN_WARNING.lower() == 'true' and 'red' in cluster_status_html_msg) or (days_since_last_email_report >= EMAIL_SCHEDULE_INTERVAL - 1):
          return cluster_status_html_msg.strip().replace('\n', '')
      else:
        Variable.set('REPORT__DAYS_SINCE_LAST_EMAIL_REPORT', days_since_last_email_report + 1)
        return ""
    
    @task()
    def send_report(report):

      if not report:
        logging.warning(f"Envio do e-mail de hoje não atende os critérios definidos nas configurações. Ver EMAIL_SCHEDULE_INTERVAL.")
        raise AirflowSkipException

      email_from = EMAIL_SENDER
      email_to = EMAIL_RECIPIENTS.strip().replace(' ', '')
      date_str = datetime.today().strftime('%d/%m/%Y')

      email_message = MIMEMultipart()
      email_message['From'] = email_from
      email_message['To'] = email_to
      email_message['Subject'] = f'{EMAIL_SUBJECT} - {date_str}'

      email_message.attach(MIMEText(report, "html"))
      email_string = email_message.as_string()

      if SMTP_SSL.lower() == 'true':
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
            server.login(email_from, EMAIL_SENDER_PSWD)
            server.sendmail(email_from, email_to.split(','), email_string.encode('utf-8'))
      else:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
          server.sendmail(email_from, email_to.split(','), email_string)

      Variable.set('REPORT__DAYS_SINCE_LAST_EMAIL_REPORT', 0)

      return True
    
    def print_node_info(node_idx, node_host, node_ip, node_health, node_load, is_main=False):
      node_name = 'af-main' if is_main else 'af-worker-0'+str(node_idx)

      return f'''\
        <li><span><strong>{node_host} ({node_name}):</strong> {HEALTHY_MSG if node_health else UNHEALTHY_MSG}</span>
          {print_node_status(node_health, node_load, node_ip, is_main)}
        </li>
      '''

    def print_node_status(node_status, node_load, node_ip, is_main=False):
      CPU_USAGE = 0
      RAM_AVAILABLE = 1
      RAM_TOTAL = 2
      DISK_USAGE_HOME = 3
      DISK_TOTAL_HOME = 4
      DISK_USAGE_VAR = 5
      DISK_TOTAL_VAR = 6
      LAST_UPDATE_TIMESTAMP = 7

      services = 'scheduler, webserver, flower' if is_main else 'worker'

      if node_status:
        return f'''\
          <ul>
            <li><span>IP: {node_ip}</span></li>
            <li><span>Serviços: <em>{services}</em></span></li>
            <li><span>Utilização de recursos <small>[{datetime.utcfromtimestamp(node_load[LAST_UPDATE_TIMESTAMP]).strftime( "%d-%m-%Y %H:%M:%S" ) if (len(node_load) > LAST_UPDATE_TIMESTAMP) else ""}]</small>:</span></li>
            <ul>
            <li {"style='color: red'" if (node_load[CPU_USAGE] >= THRESHOLD_CPU*100) else ""}><span>Utilização média de CPUs: {node_load[CPU_USAGE]}%</span></li>
            <li {"style='color: red'" if ((node_load[RAM_TOTAL] - node_load[RAM_AVAILABLE])/(node_load[RAM_TOTAL]) >= THRESHOLD_MEMORY) else ""}><span>Utilização média de RAM: {((node_load[RAM_TOTAL] - node_load[RAM_AVAILABLE])/1024/1024):.1f}G/{(node_load[RAM_TOTAL]/1024/1024):.1f}G ({((node_load[RAM_TOTAL] - node_load[RAM_AVAILABLE])/(node_load[RAM_TOTAL])*100):.2f}%)</span></li>
            <li {"style='color: red'" if (node_load[DISK_USAGE_HOME]/node_load[DISK_TOTAL_HOME] >= THRESHOLD_DISK) else ""}><span>Utilização de disco (<em>/home/airflow</em>): {(node_load[DISK_USAGE_HOME]/1024/1024):.1f}G/{(node_load[DISK_TOTAL_HOME]/1024/1024):.1f}G ({(node_load[DISK_USAGE_HOME]/node_load[DISK_TOTAL_HOME]*100):.2f}%)</span></li>
            <li {"style='color: red'" if (node_load[DISK_USAGE_VAR]/node_load[DISK_TOTAL_VAR] >= THRESHOLD_DISK) else ""}><span>Utilização de disco (<em>/var</em>): {(node_load[DISK_USAGE_VAR]/1024/1024):.1f}G/{(node_load[DISK_TOTAL_VAR]/1024/1024):.1f}G ({(node_load[DISK_USAGE_VAR]/node_load[DISK_TOTAL_VAR]*100):.2f}%)</span></li>
            </ul>
          </ul>
        '''
      else:
        return f'''\
        <ul>
          <li><span>Nó indisponível.</span></li>
        </ul>
      '''

    status = connect_to_airflow_api()
    scheduler_health = check_scheduler_health(status)
    workers_health = check_workers_health(status)
    dagbag_size = check_dagbag_size(status)
    dagrun_errors = check_dagrun_errors(status)
    dagrun_executions = check_dagrun_executions(status)
    import_errors = check_import_errors(status)
    cluster_load = check_cluster_load(status)
    collector_variables = check_collector_variables(status)
    report = format_report(scheduler_health, workers_health, dagbag_size, dagrun_errors, dagrun_executions, import_errors, cluster_load, collector_variables)
    success = send_report(report)

report_dag = airflow_email_report()
